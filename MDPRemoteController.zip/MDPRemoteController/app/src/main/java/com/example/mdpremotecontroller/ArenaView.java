package com.example.mdpremotecontroller;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class ArenaView extends View {

    private static final int DEFAULT_GRID = 12;
    private static final float LABEL_GAP_DP = 24f;

    private int arenaWidth = DEFAULT_GRID;
    private int arenaHeight = DEFAULT_GRID;
    private int robotSize = 1;
    private int defaultObstacleSize = 1;
    private int robotX = 0;
    private int robotY = 0;
    private int robotDir = 0;
    private final List<Obstacle> obstacles = new ArrayList<>();
    private final AtomicInteger obstacleIdGen = new AtomicInteger(1);
    private int movingObstacleId = -1;
    private int selectedObstacleId = -1;
    private int draggingObstacleId = -1;
    private int pendingObstacleId = -1;
    private float downX;
    private float downY;
    private boolean dragStarted;
    private int touchSlop;
    private int moveOriginalX;
    private int moveOriginalY;
    private int movePendingX;
    private int movePendingY;
    private int dragOriginalX;
    private int dragOriginalY;
    private int dragPendingX;
    private int dragPendingY;
    private boolean dragOutside;

    private final Paint gridPaint = new Paint();
    private final Paint labelPaint = new Paint();
    private final Paint obstaclePaint = new Paint();
    private final Paint robotPaint = new Paint();
    private final Paint wheelPaint = new Paint();
    private final Paint dirPaint = new Paint();
    private final Paint targetPaint = new Paint();
    private final Paint selectedPaint = new Paint();
    private final Paint numberPaint = new Paint();
    private final Paint targetIdPaint = new Paint();

    private float labelGapPx;
    private ArenaListener listener;
    private float scaleFactor = 1f;
    private float offsetX = 0f;
    private float offsetY = 0f;
    private ScaleGestureDetector scaleDetector;
    private GestureDetector gestureDetector;
    private boolean obstacleEditEnabled = true;
    private boolean tapMoveEnabled = false;

    public ArenaView(Context context) {
        super(context);
        init();
    }

    public ArenaView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ArenaView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        gridPaint.setColor(0xFFB0B0B0);
        gridPaint.setStrokeWidth(2f);

        labelPaint.setColor(0xFF444444);
        labelPaint.setTextSize(28f);
        labelPaint.setAntiAlias(true);

        obstaclePaint.setColor(0xFF7A1E1E);
        obstaclePaint.setStyle(Paint.Style.FILL);

        robotPaint.setColor(0xFF2F80ED);
        robotPaint.setStyle(Paint.Style.FILL);

        wheelPaint.setColor(0xFF1C1C1C);
        wheelPaint.setStyle(Paint.Style.FILL);

        dirPaint.setColor(0xFFFFFFFF);
        dirPaint.setStyle(Paint.Style.FILL);

        targetPaint.setColor(0xFFF2C94C);
        targetPaint.setStrokeWidth(6f);
        targetPaint.setStyle(Paint.Style.STROKE);

        selectedPaint.setColor(0xFF27AE60);
        selectedPaint.setStrokeWidth(6f);
        selectedPaint.setStyle(Paint.Style.STROKE);

        numberPaint.setColor(0xFFFFFFFF);
        numberPaint.setTextSize(20f);
        numberPaint.setAntiAlias(true);

        targetIdPaint.setColor(0xFFFFFFFF);
        targetIdPaint.setTextSize(34f);
        targetIdPaint.setAntiAlias(true);

        labelGapPx = LABEL_GAP_DP * getResources().getDisplayMetrics().density;
        setFocusable(true);
        setClickable(true);

        scaleDetector = new ScaleGestureDetector(getContext(), new ScaleListener());
        gestureDetector = new GestureDetector(getContext(), new PanListener());
        touchSlop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.save();
        canvas.translate(offsetX, offsetY);
        canvas.scale(scaleFactor, scaleFactor);

        float width = getWidth();
        float height = getHeight();
        float cellSize = Math.min(width - labelGapPx, height - labelGapPx) / Math.max(arenaWidth, arenaHeight);
        float startX = labelGapPx;
        float startY = labelGapPx;
        float gridWidth = cellSize * arenaWidth;
        float gridHeight = cellSize * arenaHeight;

        for (int i = 0; i <= arenaWidth; i++) {
            float x = startX + i * cellSize;
            canvas.drawLine(x, startY, x, startY + gridHeight, gridPaint);
        }
        for (int i = 0; i <= arenaHeight; i++) {
            float y = startY + i * cellSize;
            canvas.drawLine(startX, y, startX + gridWidth, y, gridPaint);
        }

        for (int i = 0; i < arenaWidth; i++) {
            float x = startX + i * cellSize + cellSize * 0.35f;
            canvas.drawText(String.valueOf(i), x, startY - 6f, labelPaint);
        }
        for (int i = 0; i < arenaHeight; i++) {
            float y = startY + gridHeight - i * cellSize - cellSize * 0.35f;
            canvas.drawText(String.valueOf(i), 4f, y, labelPaint);
        }

        for (Obstacle o : obstacles) {
            int drawX = o.x;
            int drawY = o.y;
            if (o.id == movingObstacleId) {
                drawX = movePendingX;
                drawY = movePendingY;
            } else if (o.id == draggingObstacleId) {
                drawX = dragPendingX;
                drawY = dragPendingY;
            }
            RectF r = rectForSize(drawX, drawY, o.size, cellSize, startX, startY);
            canvas.drawRect(r, obstaclePaint);
            drawTargets(canvas, r, o);
            if (o.id == selectedObstacleId) {
                canvas.drawRect(r, selectedPaint);
            }
            drawObstacleLabel(canvas, r, o);
        }

        RectF robot = rectForSize(robotX, robotY, robotSize, cellSize, startX, startY);
        drawRobot(canvas, robot);

        canvas.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        gestureDetector.onTouchEvent(event);

        if (event.getAction() == MotionEvent.ACTION_DOWN && movingObstacleId == -1 && obstacleEditEnabled) {
            int[] grid = gridFromPixel(event.getX(), event.getY());
            if (grid != null) {
                Obstacle hit = findObstacleAt(grid[0], grid[1]);
                if (hit != null) {
                    pendingObstacleId = hit.id;
                    downX = event.getX();
                    downY = event.getY();
                    dragStarted = false;
                    return true;
                }
            }
        }

        if (event.getAction() == MotionEvent.ACTION_MOVE && movingObstacleId != -1) {
            int[] grid = gridFromPixel(event.getX(), event.getY());
            if (grid != null) {
                int[] clamped = clampMovePosition(grid[0], grid[1]);
                movePendingX = clamped[0];
                movePendingY = clamped[1];
                invalidate();
            }
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_MOVE && pendingObstacleId != -1 && obstacleEditEnabled) {
            float dx = event.getX() - downX;
            float dy = event.getY() - downY;
            if (!dragStarted && (Math.abs(dx) > touchSlop || Math.abs(dy) > touchSlop)) {
                Obstacle hit = getObstacleById(pendingObstacleId);
                if (hit != null) {
                    selectedObstacleId = hit.id;
                    draggingObstacleId = hit.id;
                    dragOriginalX = hit.x;
                    dragOriginalY = hit.y;
                    dragPendingX = hit.x;
                    dragPendingY = hit.y;
                    dragOutside = false;
                    dragStarted = true;
                    invalidate();
                }
            }
            if (draggingObstacleId != -1) {
                int[] grid = gridFromPixel(event.getX(), event.getY());
                if (grid == null) {
                    dragOutside = true;
                } else {
                    dragOutside = false;
                    int[] clamped = clampDragPosition(grid[0], grid[1]);
                    dragPendingX = clamped[0];
                    dragPendingY = clamped[1];
                }
                invalidate();
            }
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_UP) {
            if (scaleDetector.isInProgress()) return true;
            int[] grid = gridFromPixel(event.getX(), event.getY());
            if (movingObstacleId != -1) {
                if (grid == null) return true;
                int[] clamped = clampMovePosition(grid[0], grid[1]);
                movePendingX = clamped[0];
                movePendingY = clamped[1];
                invalidate();
                return true;
            }
            if (draggingObstacleId != -1) {
                Obstacle o = getObstacleById(draggingObstacleId);
                int id = draggingObstacleId;
                draggingObstacleId = -1;
                pendingObstacleId = -1;
                dragStarted = false;
                if (dragOutside || grid == null) {
                    if (o != null) removeObstacle(id);
                    clearSelection();
                    return true;
                }
                if (o != null && isValidMovePosition(dragPendingX, dragPendingY, o.id)) {
                    if (o.x != dragPendingX || o.y != dragPendingY) {
                        o.x = dragPendingX;
                        o.y = dragPendingY;
                        if (listener != null) listener.onObstacleMoved(o);
                    }
                } else if (o != null) {
                    o.x = dragOriginalX;
                    o.y = dragOriginalY;
                }
                invalidate();
                clearSelection();
                return true;
            }
            if (pendingObstacleId != -1 && !dragStarted && obstacleEditEnabled) {
                Obstacle hit = getObstacleById(pendingObstacleId);
                pendingObstacleId = -1;
                if (hit != null && listener != null) {
                    selectedObstacleId = hit.id;
                    invalidate();
                    listener.onObstacleTapped(hit);
                    return true;
                }
            }
            pendingObstacleId = -1;
            if (grid == null) return true;
            if (tapMoveEnabled && listener != null) {
                listener.onCellTapped(grid[0], grid[1]);
                return true;
            }
            selectedObstacleId = -1;
            invalidate();
        }
        return true;
    }

    private int[] gridFromPixel(float touchX, float touchY) {
        float localX = (touchX - offsetX) / scaleFactor;
        float localY = (touchY - offsetY) / scaleFactor;
        float width = getWidth();
        float height = getHeight();
        float cellSize = Math.min(width - labelGapPx, height - labelGapPx) / Math.max(arenaWidth, arenaHeight);
        float startX = labelGapPx;
        float startY = labelGapPx;

        if (localX < startX || localY < startY) return null;
        if (localX > startX + cellSize * arenaWidth || localY > startY + cellSize * arenaHeight) return null;

        int gridX = (int) ((localX - startX) / cellSize);
        int gridYTop = (int) ((localY - startY) / cellSize);
        int gridY = (arenaHeight - 1) - gridYTop;

        return new int[]{gridX, gridY};
    }

    public boolean moveRobot(int dx, int dy) {
        int newX = robotX + dx;
        int newY = robotY + dy;
        if (!fitsInArena(newX, newY, robotSize, robotSize)) return false;
        if (isBlockedByObstacle(newX, newY, robotSize, robotSize, -1)) return false;
        robotX = newX;
        robotY = newY;
        invalidate();
        return true;
    }

    public boolean moveForward() {
        int[] delta = dirToDelta(robotDir, true);
        return moveRobot(delta[0], delta[1]);
    }

    public boolean moveBackward() {
        int[] delta = dirToDelta(robotDir, false);
        return moveRobot(delta[0], delta[1]);
    }

    public void rotateLeft() {
        robotDir = (robotDir + 3) % 4;
        invalidate();
    }

    public void rotateRight() {
        robotDir = (robotDir + 1) % 4;
        invalidate();
    }

    private int[] dirToDelta(int dir, boolean forward) {
        int step = forward ? 1 : -1;
        switch (dir) {
            case 0: // North
                return new int[]{0, step};
            case 1: // East
                return new int[]{step, 0};
            case 2: // South
                return new int[]{0, -step};
            case 3: // West
            default:
                return new int[]{-step, 0};
        }
    }

    public void placeObstacleAtPixel(float x, float y) {
        int[] grid = gridFromPixel(x, y);
        if (grid == null) return;
        placeObstacleAt(grid[0], grid[1]);
    }

    public void placeObstacleAt(int x, int y) {
        int size = defaultObstacleSize;
        if (!fitsInArena(x, y, size, size)) return;
        if (isBlockedByObstacle(x, y, size, size, -1)) return;
        if (rectsOverlap(x, y, size, size, robotX, robotY, robotSize, robotSize)) return;
        Obstacle o = new Obstacle(obstacleIdGen.getAndIncrement(), nextObstacleNumber(), x, y, size);
        obstacles.add(o);
        if (listener != null) listener.onObstacleAdded(o);
        invalidate();
    }

    public void removeObstacle(int obstacleId) {
        for (int i = 0; i < obstacles.size(); i++) {
            if (obstacles.get(i).id == obstacleId) {
                Obstacle removed = obstacles.remove(i);
                if (selectedObstacleId == obstacleId) selectedObstacleId = -1;
                if (listener != null) listener.onObstacleRemoved(removed);
                invalidate();
                return;
            }
        }
    }

    public void addTarget(int obstacleId, int face) {
        Obstacle o = getObstacleById(obstacleId);
        if (o == null) return;
        switch (face) {
            case 0:
                if (!o.targetNorth) o.targetNorth = true;
                break;
            case 1:
                if (!o.targetEast) o.targetEast = true;
                break;
            case 2:
                if (!o.targetSouth) o.targetSouth = true;
                break;
            case 3:
                if (!o.targetWest) o.targetWest = true;
                break;
            default:
                return;
        }
        invalidate();
        if (listener != null) listener.onTargetAdded(o, face);
    }

    public void beginMoveObstacle(int obstacleId) {
        Obstacle o = getObstacleById(obstacleId);
        if (o == null) return;
        movingObstacleId = obstacleId;
        selectedObstacleId = obstacleId;
        moveOriginalX = o.x;
        moveOriginalY = o.y;
        movePendingX = o.x;
        movePendingY = o.y;
        if (listener != null) listener.onMoveModeChanged(true);
        invalidate();
    }

    public void confirmMoveObstacle() {
        if (movingObstacleId == -1) return;
        Obstacle o = getObstacleById(movingObstacleId);
        if (o != null && isValidMovePosition(movePendingX, movePendingY, o.id)) {
            if (o.x != movePendingX || o.y != movePendingY) {
                o.x = movePendingX;
                o.y = movePendingY;
                if (listener != null) listener.onObstacleMoved(o);
            }
        } else if (o != null) {
            o.x = moveOriginalX;
            o.y = moveOriginalY;
        }
        movingObstacleId = -1;
        if (listener != null) listener.onMoveModeChanged(false);
        invalidate();
    }

    public void cancelMoveObstacle() {
        Obstacle o = getObstacleById(movingObstacleId);
        if (o != null) {
            o.x = moveOriginalX;
            o.y = moveOriginalY;
        }
        movingObstacleId = -1;
        if (listener != null) listener.onMoveModeChanged(false);
        invalidate();
    }

    public void resetArena(int width, int height, int newRobotSize) {
        arenaWidth = width;
        arenaHeight = height;
        robotSize = newRobotSize;
        defaultObstacleSize = 1;
        robotX = 0;
        robotY = 0;
        robotDir = 0;
        obstacles.clear();
        selectedObstacleId = -1;
        movingObstacleId = -1;
        invalidate();
    }

    public void resetToDefault() {
        resetArena(DEFAULT_GRID, DEFAULT_GRID, 1);
    }

    public void clearObstacles() {
        obstacles.clear();
        selectedObstacleId = -1;
        movingObstacleId = -1;
        invalidate();
    }

    public int getArenaWidth() {
        return arenaWidth;
    }

    public int getArenaHeight() {
        return arenaHeight;
    }

    public int getRobotSize() {
        return robotSize;
    }

    public int getRobotX() {
        return robotX;
    }

    public int getRobotY() {
        return robotY;
    }

    public int getRobotDir() {
        return robotDir;
    }

    public boolean isRobotPlacementValid(int x, int y) {
        if (!fitsInArena(x, y, robotSize, robotSize)) return false;
        return !isBlockedByObstacle(x, y, robotSize, robotSize, -1);
    }

    public List<Obstacle> getObstaclesSnapshot() {
        return new ArrayList<>(obstacles);
    }

    public void clearSelection() {
        selectedObstacleId = -1;
        pendingObstacleId = -1;
        dragStarted = false;
        invalidate();
    }

    public void clearTargets(int obstacleId) {
        Obstacle o = getObstacleById(obstacleId);
        if (o == null) return;
        o.targetNorth = false;
        o.targetEast = false;
        o.targetSouth = false;
        o.targetWest = false;
        invalidate();
        if (listener != null) listener.onTargetsCleared(o);
    }

    public boolean setTargetId(int obstacleId, Integer targetId) {
        Obstacle o = getObstacleById(obstacleId);
        if (o == null) return false;
        if (targetId == null || targetId <= 0) {
            o.targetId = null;
        } else {
            o.targetId = targetId;
        }
        invalidate();
        if (listener != null) listener.onTargetIdChanged(o);
        return true;
    }

    public boolean updateObstacleNumber(int obstacleId, int newNumber) {
        if (newNumber <= 0) return false;
        for (Obstacle o : obstacles) {
            if (o.id != obstacleId && o.number == newNumber) return false;
        }
        Obstacle o = getObstacleById(obstacleId);
        if (o == null) return false;
        int oldNumber = o.number;
        o.number = newNumber;
        invalidate();
        if (listener != null) listener.onObstacleNumberChanged(oldNumber, o);
        return true;
    }

    public boolean updateObstacleSize(int obstacleId, int newSize) {
        Obstacle o = getObstacleById(obstacleId);
        if (o == null) return false;
        if (!fitsInArena(o.x, o.y, newSize, newSize)) return false;
        if (isBlockedByObstacle(o.x, o.y, newSize, newSize, obstacleId)) return false;
        if (rectsOverlap(o.x, o.y, newSize, newSize, robotX, robotY, robotSize, robotSize)) return false;
        o.size = newSize;
        invalidate();
        if (listener != null) listener.onObstacleSizeChanged(o);
        return true;
    }

    public boolean addObstacleWithNumber(int number, int x, int y, int size) {
        if (number <= 0 || size <= 0) return false;
        if (getObstacleByNumber(number) != null) return false;
        if (!fitsInArena(x, y, size, size)) return false;
        if (isBlockedByObstacle(x, y, size, size, -1)) return false;
        if (rectsOverlap(x, y, size, size, robotX, robotY, robotSize, robotSize)) return false;
        Obstacle o = new Obstacle(obstacleIdGen.getAndIncrement(), number, x, y, size);
        obstacles.add(o);
        if (listener != null) listener.onObstacleAdded(o);
        invalidate();
        return true;
    }

    public boolean moveObstacleByNumber(int number, int x, int y) {
        Obstacle o = getObstacleByNumber(number);
        if (o == null) return false;
        if (!isValidMovePosition(x, y, o.id)) return false;
        if (o.x == x && o.y == y) return true;
        o.x = x;
        o.y = y;
        invalidate();
        if (listener != null) listener.onObstacleMoved(o);
        return true;
    }

    public boolean removeObstacleByNumber(int number) {
        Obstacle o = getObstacleByNumber(number);
        if (o == null) return false;
        removeObstacle(o.id);
        return true;
    }

    public boolean updateObstacleSizeByNumber(int number, int size) {
        Obstacle o = getObstacleByNumber(number);
        if (o == null) return false;
        return updateObstacleSize(o.id, size);
    }

    public boolean updateObstacleNumberByNumber(int oldNumber, int newNumber) {
        Obstacle o = getObstacleByNumber(oldNumber);
        if (o == null) return false;
        return updateObstacleNumber(o.id, newNumber);
    }

    public boolean addTargetByNumber(int number, String face) {
        Obstacle o = getObstacleByNumber(number);
        if (o == null) return false;
        int faceIdx = faceLabelToIndex(face);
        if (faceIdx < 0) return false;
        addTarget(o.id, faceIdx);
        return true;
    }

    public boolean clearTargetsByNumber(int number) {
        Obstacle o = getObstacleByNumber(number);
        if (o == null) return false;
        clearTargets(o.id);
        return true;
    }

    public boolean setTargetIdByNumber(int number, Integer targetId) {
        Obstacle o = getObstacleByNumber(number);
        if (o == null) return false;
        return setTargetId(o.id, targetId);
    }

    public boolean setRobotPose(int x, int y, int dir) {
        if (!fitsInArena(x, y, robotSize, robotSize)) return false;
        if (isBlockedByObstacle(x, y, robotSize, robotSize, -1)) return false;
        if (dir < 0 || dir > 3) return false;
        robotX = x;
        robotY = y;
        robotDir = dir;
        invalidate();
        return true;
    }

    public void setListener(ArenaListener listener) {
        this.listener = listener;
    }

    public void setObstacleEditEnabled(boolean enabled) {
        obstacleEditEnabled = enabled;
    }

    public void setTapMoveEnabled(boolean enabled) {
        tapMoveEnabled = enabled;
    }

    private Obstacle getObstacleById(int obstacleId) {
        for (Obstacle o : obstacles) {
            if (o.id == obstacleId) return o;
        }
        return null;
    }

    private Obstacle getObstacleByNumber(int number) {
        for (Obstacle o : obstacles) {
            if (o.number == number) return o;
        }
        return null;
    }

    private Obstacle findObstacleAt(int x, int y) {
        for (Obstacle o : obstacles) {
            if (x >= o.x && x < o.x + o.size
                    && y >= o.y && y < o.y + o.size) {
                return o;
            }
        }
        return null;
    }

    private int nextObstacleNumber() {
        int candidate = 1;
        while (true) {
            boolean used = false;
            for (Obstacle o : obstacles) {
                if (o.number == candidate) {
                    used = true;
                    break;
                }
            }
            if (!used) return candidate;
            candidate++;
        }
    }

    private int faceLabelToIndex(String face) {
        if (face == null) return -1;
        switch (face) {
            case "N":
                return 0;
            case "E":
                return 1;
            case "S":
                return 2;
            case "W":
                return 3;
            default:
                return -1;
        }
    }

    private boolean isValidMovePosition(int x, int y, int obstacleId) {
        Obstacle o = getObstacleById(obstacleId);
        if (o == null) return false;
        if (!fitsInArena(x, y, o.size, o.size)) return false;
        if (isBlockedByObstacle(x, y, o.size, o.size, obstacleId)) return false;
        return !rectsOverlap(x, y, o.size, o.size, robotX, robotY, robotSize, robotSize);
    }

    private int[] clampMovePosition(int x, int y) {
        Obstacle o = getObstacleById(movingObstacleId);
        int size = (o == null) ? defaultObstacleSize : o.size;
        int maxX = Math.max(0, arenaWidth - size);
        int maxY = Math.max(0, arenaHeight - size);
        int clampedX = Math.max(0, Math.min(x, maxX));
        int clampedY = Math.max(0, Math.min(y, maxY));
        return new int[]{clampedX, clampedY};
    }

    private int[] clampDragPosition(int x, int y) {
        Obstacle o = getObstacleById(draggingObstacleId);
        int size = (o == null) ? defaultObstacleSize : o.size;
        int maxX = Math.max(0, arenaWidth - size);
        int maxY = Math.max(0, arenaHeight - size);
        int clampedX = Math.max(0, Math.min(x, maxX));
        int clampedY = Math.max(0, Math.min(y, maxY));
        return new int[]{clampedX, clampedY};
    }

    private boolean isBlockedByObstacle(int x, int y, int w, int h, int ignoreId) {
        for (Obstacle o : obstacles) {
            if (o.id == ignoreId) continue;
            if (rectsOverlap(x, y, w, h, o.x, o.y, o.size, o.size)) return true;
        }
        return false;
    }

    private boolean fitsInArena(int x, int y, int w, int h) {
        return x >= 0 && y >= 0 && (x + w) <= arenaWidth && (y + h) <= arenaHeight;
    }

    private boolean rectsOverlap(int ax, int ay, int aw, int ah, int bx, int by, int bw, int bh) {
        return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
    }

    private RectF rectForSize(int x, int y, int size, float cellSize, float startX, float startY) {
        float left = startX + x * cellSize;
        float top = startY + (arenaHeight - y - size) * cellSize;
        float right = left + size * cellSize;
        float bottom = top + size * cellSize;
        return new RectF(left + 2f, top + 2f, right - 2f, bottom - 2f);
    }

    private void drawRobot(Canvas canvas, RectF cell) {
        float inset = Math.min(cell.width(), cell.height()) * 0.12f;
        RectF body = new RectF(
                cell.left + inset,
                cell.top + inset * 1.2f,
                cell.right - inset,
                cell.bottom - inset * 1.2f
        );
        float radius = Math.min(body.width(), body.height()) * 0.2f;
        canvas.drawRoundRect(body, radius, radius, robotPaint);

        float wheelRadius = Math.min(body.width(), body.height()) * 0.14f;
        float wheelOffset = wheelRadius * 1.1f;
        canvas.drawCircle(body.left + wheelOffset, body.top + wheelOffset, wheelRadius, wheelPaint);
        canvas.drawCircle(body.right - wheelOffset, body.top + wheelOffset, wheelRadius, wheelPaint);
        canvas.drawCircle(body.left + wheelOffset, body.bottom - wheelOffset, wheelRadius, wheelPaint);
        canvas.drawCircle(body.right - wheelOffset, body.bottom - wheelOffset, wheelRadius, wheelPaint);

        drawDirectionTriangle(canvas, body);
    }

    private void drawDirectionTriangle(Canvas canvas, RectF body) {
        float size = Math.min(body.width(), body.height()) * 0.35f;
        float cx = body.centerX();
        float cy = body.centerY();

        Path p = new Path();
        if (robotDir == 0) { // North
            p.moveTo(cx, cy - size);
            p.lineTo(cx - size * 0.6f, cy + size * 0.6f);
            p.lineTo(cx + size * 0.6f, cy + size * 0.6f);
        } else if (robotDir == 1) { // East
            p.moveTo(cx + size, cy);
            p.lineTo(cx - size * 0.6f, cy - size * 0.6f);
            p.lineTo(cx - size * 0.6f, cy + size * 0.6f);
        } else if (robotDir == 2) { // South
            p.moveTo(cx, cy + size);
            p.lineTo(cx - size * 0.6f, cy - size * 0.6f);
            p.lineTo(cx + size * 0.6f, cy - size * 0.6f);
        } else { // West
            p.moveTo(cx - size, cy);
            p.lineTo(cx + size * 0.6f, cy - size * 0.6f);
            p.lineTo(cx + size * 0.6f, cy + size * 0.6f);
        }
        p.close();
        canvas.drawPath(p, dirPaint);
    }

    private void drawTargets(Canvas canvas, RectF rect, Obstacle o) {
        if (o.targetNorth) {
            canvas.drawLine(rect.left, rect.top, rect.right, rect.top, targetPaint);
        }
        if (o.targetEast) {
            canvas.drawLine(rect.right, rect.top, rect.right, rect.bottom, targetPaint);
        }
        if (o.targetSouth) {
            canvas.drawLine(rect.left, rect.bottom, rect.right, rect.bottom, targetPaint);
        }
        if (o.targetWest) {
            canvas.drawLine(rect.left, rect.top, rect.left, rect.bottom, targetPaint);
        }
    }

    private void drawObstacleNumber(Canvas canvas, RectF rect, int number) {
        String text = String.valueOf(number);
        float textWidth = numberPaint.measureText(text);
        float x = rect.centerX() - textWidth / 2f;
        float y = rect.centerY() + (numberPaint.getTextSize() * 0.35f);
        canvas.drawText(text, x, y, numberPaint);
    }

    private void drawObstacleLabel(Canvas canvas, RectF rect, Obstacle o) {
        if (o.targetId != null && o.targetId > 0) {
            String text = String.valueOf(o.targetId);
            float textWidth = targetIdPaint.measureText(text);
            float x = rect.centerX() - textWidth / 2f;
            float y = rect.centerY() + (targetIdPaint.getTextSize() * 0.35f);
            canvas.drawText(text, x, y, targetIdPaint);
        } else {
            drawObstacleNumber(canvas, rect, o.number);
        }
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            float prevScale = scaleFactor;
            scaleFactor *= detector.getScaleFactor();
            scaleFactor = Math.max(0.6f, Math.min(scaleFactor, 3.0f));

            float focusX = detector.getFocusX();
            float focusY = detector.getFocusY();
            offsetX = focusX - (focusX - offsetX) * (scaleFactor / prevScale);
            offsetY = focusY - (focusY - offsetY) * (scaleFactor / prevScale);
            invalidate();
            return true;
        }
    }

    private class PanListener extends GestureDetector.SimpleOnGestureListener {
        @Override
        public boolean onDown(MotionEvent e) {
            return true;
        }

        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            if (scaleDetector.isInProgress()) return false;
            if (movingObstacleId != -1 || draggingObstacleId != -1) return false;
            offsetX -= distanceX;
            offsetY -= distanceY;
            invalidate();
            return true;
        }
    }

    public static class Obstacle {
        public final int id;
        public int number;
        public int x;
        public int y;
        public int size;
        public Integer targetId;
        public boolean targetNorth;
        public boolean targetEast;
        public boolean targetSouth;
        public boolean targetWest;

        public Obstacle(int id, int number, int x, int y, int size) {
            this.id = id;
            this.number = number;
            this.x = x;
            this.y = y;
            this.size = size;
        }
    }

    public interface ArenaListener {
        void onObstacleTapped(Obstacle obstacle);
        void onMoveModeChanged(boolean active);
        void onObstacleAdded(Obstacle obstacle);
        void onObstacleMoved(Obstacle obstacle);
        void onObstacleRemoved(Obstacle obstacle);
        void onObstacleSizeChanged(Obstacle obstacle);
        void onObstacleNumberChanged(int oldNumber, Obstacle obstacle);
        void onTargetAdded(Obstacle obstacle, int face);
        void onTargetsCleared(Obstacle obstacle);
        void onTargetIdChanged(Obstacle obstacle);
        void onCellTapped(int x, int y);
    }
}
