package com.example.mdpremotecontroller;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

public class JoystickView extends View {

    private final Paint basePaint = new Paint();
    private final Paint hatPaint = new Paint();
    private float centerX;
    private float centerY;
    private float baseRadius;
    private float hatRadius;
    private float hatX;
    private float hatY;
    private JoystickListener listener;

    public JoystickView(Context context) {
        super(context);
        init();
    }

    public JoystickView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public JoystickView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        basePaint.setColor(0xFFBDBDBD);
        basePaint.setStyle(Paint.Style.FILL);
        basePaint.setAntiAlias(true);

        hatPaint.setColor(0xFF5C6BC0);
        hatPaint.setStyle(Paint.Style.FILL);
        hatPaint.setAntiAlias(true);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        centerX = w / 2f;
        centerY = h / 2f;
        baseRadius = Math.min(w, h) * 0.38f;
        hatRadius = Math.min(w, h) * 0.18f;
        resetHat();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(centerX, centerY, baseRadius, basePaint);
        canvas.drawCircle(hatX, hatY, hatRadius, hatPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP
                || event.getAction() == MotionEvent.ACTION_CANCEL) {
            resetHat();
            if (listener != null) listener.onMove(0f, 0f, false);
            return true;
        }

        if (event.getAction() == MotionEvent.ACTION_DOWN
                || event.getAction() == MotionEvent.ACTION_MOVE) {
            float dx = event.getX() - centerX;
            float dy = event.getY() - centerY;
            float distance = (float) Math.sqrt(dx * dx + dy * dy);
            if (distance > baseRadius) {
                dx = dx * baseRadius / distance;
                dy = dy * baseRadius / distance;
            }
            hatX = centerX + dx;
            hatY = centerY + dy;
            invalidate();
            if (listener != null) {
                listener.onMove(dx / baseRadius, dy / baseRadius, true);
            }
            return true;
        }
        return false;
    }

    private void resetHat() {
        hatX = centerX;
        hatY = centerY;
        invalidate();
    }

    public void setListener(JoystickListener listener) {
        this.listener = listener;
    }

    public interface JoystickListener {
        void onMove(float normX, float normY, boolean active);
    }
}
