package com.example.mdpremotecontroller;

import android.Manifest;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.DragEvent;
import android.view.View;
import android.view.View.DragShadowBuilder;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.util.Base64;
import android.widget.Toast;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    // Standard UUID for Bluetooth Classic Serial Port Profile (SPP)
    private static final UUID SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int MAX_ARENA_SIZE = 64;
    private static final long MOVE_COOLDOWN_MS = 250;
    private static final String LAYOUT_PREFS = "arena_layouts";

    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private BluetoothServerSocket serverSocket;
    private OutputStream out;
    private Thread readerThread;
    private Thread acceptThread;
    private volatile boolean shouldAccept = true;
    private volatile boolean accepting = false;
    private boolean suppressOutbound = false;

    private TextView txtStatus, txtLog, txtRobotStatus;
    private EditText edtSend;
    private View sectionHome, sectionBluetooth, sectionArena;
    private View sectionArenaMain, sectionArenaEdit, sectionArenaMoveRobot;
    private View sectionArenaShortestPath, sectionArenaTrial;
    private View arenaCanvasContainer;
    private View sectionArenaEditSizes;
    private View moveObstacleControls;
    private FrameLayout obstaclePalette;
    private ArenaView arenaView;
    private View sectionMoveManual;
    private View sectionMoveJoystick;
    private TextView txtMoveTiltHint;
    private TextView txtMoveTapHint;
    private JoystickView joystickPad;

    private enum MoveMode { MANUAL, JOYSTICK, TILT, TAP }
    private MoveMode moveMode = MoveMode.MANUAL;
    private long lastMoveTime = 0L;
    private final Handler moveHandler = new Handler(Looper.getMainLooper());
    private boolean moveSequenceActive = false;
    private boolean joystickActive = false;
    private int joystickAction = 0;
    private boolean rotateRepeatActive = false;
    private int rotateRepeatDir = 0;
    private static final long ROTATE_REPEAT_MS = 120;
    private boolean tapMovePlaying = false;
    private List<Character> tapMoveActions = new ArrayList<>();
    private int tapMoveIndex = 0;

    private SensorManager sensorManager;
    private Sensor accelSensor;
    private SensorEventListener tiltListener;
    private int tiltAction = 0;
    private boolean tiltActive = false;
    private float tiltBaseX = 0f;
    private float tiltBaseY = 0f;
    private float lastAx = 0f;
    private float lastAy = 0f;

    private Button btnComputePath;
    private Button btnPlayPath;
    private Button btnPausePath;
    private Button btnResetPath;
    private Button btnNextStep;
    private Button btnPrevStep;
    private View rowPathStepControls;
    private TextView txtPathCost;
    private TextView txtPathProgress;
    private final Handler pathHandler = new Handler(Looper.getMainLooper());
    private List<Character> pathActions = new ArrayList<>();
    private boolean pathPlaying = false;
    private int pathIndex = 0;
    private double pathTotalTimeSec = 0.0;
    private double pathElapsedTimeSec = 0.0;
    private List<PathSegment> pathSegments = new ArrayList<>();
    private int startPoseX;
    private int startPoseY;
    private int startPoseDir;

    private Button btnTrialReset;
    private Button btnTrialStart;
    private Button btnTrialPlayOptimal;
    private TextView txtTrialActions;
    private TextView txtTrialScanned;
    private TextView txtTrialResult;
    private boolean timeTrialActive = false;
    private boolean timeTrialPlayback = false;
    private int trialActionCount = 0;
    private int trialTotalTargets = 0;
    private java.util.HashSet<String> trialScanned = new java.util.HashSet<>();
    private List<Character> trialOptimalActions = new ArrayList<>();
    private List<PathSegment> trialOptimalSegments = new ArrayList<>();
    private int trialIndex = 0;
    private int trialStartX;
    private int trialStartY;
    private int trialStartDir;
    private long trialStartMs = 0L;
    private long trialElapsedMs = 0L;
    private boolean trialTimerRunning = false;
    private final Handler trialTimerHandler = new Handler(Looper.getMainLooper());
    private final Runnable trialTimerRunnable = new Runnable() {
        @Override
        public void run() {
            if (!timeTrialActive || movementMode != MovementMode.REALISTIC || !trialTimerRunning) return;
            updateTrialTime();
            trialTimerHandler.postDelayed(this, 100);
        }
    };
    private Button btnBackFromMove;
    private Button btnSaveLayout;
    private Button btnLoadLayout;
    private Button btnExportLayout;
    private Button btnSendLayout;
    private Button btnModeSimplified;
    private Button btnModeRealistic;

    private enum MovementMode { SIMPLIFIED, REALISTIC }
    private MovementMode movementMode = MovementMode.REALISTIC;

    private final Handler simHandler = new Handler(Looper.getMainLooper());
    private boolean simRunning = false;
    private float simX;
    private float simY;
    private float simHeading;
    private float simSpeed;
    private float simThrottle;
    private float simSteer;
    private static final float SIM_DT = 0.05f;
    private static final float DEFAULT_SIM_ACCEL = 2.0f;
    private static final float SIM_BRAKE = 3.0f;
    private static final float DEFAULT_SIM_MAX_SPEED = 3.0f;
    private static final float SIM_DRAG = 1.5f;
    private static final float DEFAULT_SIM_MAX_STEER = 0.9f;
    private static final float SIM_WHEELBASE = 1.7f;
    private float simAccel = DEFAULT_SIM_ACCEL;
    private float simMaxSpeed = DEFAULT_SIM_MAX_SPEED;
    private float simMaxSteer = DEFAULT_SIM_MAX_STEER;

    private boolean actionAnimRunning = false;
    private long actionStartMs = 0L;
    private long actionDurationMs = 0L;
    private float actionStartX = 0f;
    private float actionStartY = 0f;
    private float actionStartHeading = 0f;
    private float actionTargetX = 0f;
    private float actionTargetY = 0f;
    private float actionTargetHeading = 0f;
    private Runnable actionOnDone = null;
    private boolean actionArc = false;
    private float actionArcCx = 0f;
    private float actionArcCy = 0f;
    private float actionArcStartAng = 0f;
    private float actionArcEndAng = 0f;
    private double rsTurnRadius() {
        return SIM_WHEELBASE / Math.tan(simMaxSteer);
    }

    private final ActivityResultLauncher<String[]> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                boolean ok = true;
                for (Boolean granted : result.values()) {
                    if (granted == null || !granted) ok = false;
                }
                if (!ok) {
                    setStatus("Permissions denied. Cannot use Bluetooth.");
                } else {
                    showConnectModeDialog();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adapter = BluetoothAdapter.getDefaultAdapter();

        Button btnConnect = findViewById(R.id.btnConnect);
        Button btnSend = findViewById(R.id.btnSend);
        Button btnOpenBluetooth = findViewById(R.id.btnOpenBluetooth);
        Button btnBackHome = findViewById(R.id.btnBackHome);
        Button btnOpenArena = findViewById(R.id.btnOpenArena);
        Button btnBackHomeArena = findViewById(R.id.btnBackHomeArena);
        Button btnArenaEdit = findViewById(R.id.btnArenaEdit);
        Button btnArenaMoveRobot = findViewById(R.id.btnArenaMoveRobot);
        Button btnArenaShortestPath = findViewById(R.id.btnArenaShortestPath);
        Button btnArenaTrial = findViewById(R.id.btnArenaTrial);
        btnModeSimplified = findViewById(R.id.btnModeSimplified);
        btnModeRealistic = findViewById(R.id.btnModeRealistic);
        Button btnBackArenaMainFromEdit = findViewById(R.id.btnBackArenaMainFromEdit);
        btnBackFromMove = findViewById(R.id.btnBackArenaMainFromMove);
        Button btnBackArenaMainFromShortest = findViewById(R.id.btnBackArenaMainFromShortest);
        Button btnBackArenaMainFromTrial = findViewById(R.id.btnBackArenaMainFromTrial);
        Button btnArenaEditSizes = findViewById(R.id.btnArenaEditSizes);
        Button btnBackArenaEditSizes = findViewById(R.id.btnBackArenaEditSizes);
        Button btnApplyArenaSizes = findViewById(R.id.btnApplyArenaSizes);
        Button btnArenaResetDefault = findViewById(R.id.btnArenaResetDefault);
        Button btnArenaClearObstacles = findViewById(R.id.btnArenaClearObstacles);
        btnSaveLayout = findViewById(R.id.btnSaveLayout);
        btnLoadLayout = findViewById(R.id.btnLoadLayout);
        btnExportLayout = findViewById(R.id.btnExportLayout);
        btnSendLayout = findViewById(R.id.btnSendLayout);
        EditText edtSimAccel = findViewById(R.id.edtSimAccel);
        EditText edtSimTopSpeed = findViewById(R.id.edtSimTopSpeed);
        EditText edtSimTurn = findViewById(R.id.edtSimTurn);
        Button btnMoveForward = findViewById(R.id.btnMoveForward);
        Button btnMoveBackward = findViewById(R.id.btnMoveBackward);
        Button btnRotateLeft = findViewById(R.id.btnRotateLeft);
        Button btnRotateRight = findViewById(R.id.btnRotateRight);
        Button btnEditResetRobot = findViewById(R.id.btnEditResetRobot);
        Button btnEditClearTrail = findViewById(R.id.btnEditClearTrail);
        Button btnMoveResetRobot = findViewById(R.id.btnMoveResetRobot);
        Button btnMoveClearTrail = findViewById(R.id.btnMoveClearTrail);
        btnComputePath = findViewById(R.id.btnComputePath);
        btnPlayPath = findViewById(R.id.btnPlayPath);
        btnPausePath = findViewById(R.id.btnPausePath);
        btnResetPath = findViewById(R.id.btnResetPath);
        btnNextStep = findViewById(R.id.btnNextStep);
        btnPrevStep = findViewById(R.id.btnPrevStep);
        rowPathStepControls = findViewById(R.id.rowPathStepControls);
        txtPathCost = findViewById(R.id.txtPathCost);
        txtPathProgress = findViewById(R.id.txtPathProgress);
        btnTrialReset = findViewById(R.id.btnTrialReset);
        btnTrialStart = findViewById(R.id.btnTrialStart);
        btnTrialPlayOptimal = findViewById(R.id.btnTrialPlayOptimal);
        txtTrialActions = findViewById(R.id.txtTrialActions);
        txtTrialScanned = findViewById(R.id.txtTrialScanned);
        txtTrialResult = findViewById(R.id.txtTrialResult);
        Button btnModeManual = findViewById(R.id.btnModeManual);
        Button btnModeJoystick = findViewById(R.id.btnModeJoystick);
        Button btnModeTilt = findViewById(R.id.btnModeTilt);
        Button btnModeTap = findViewById(R.id.btnModeTap);
        Button btnMoveObstacleDone = findViewById(R.id.btnMoveObstacleDone);
        Button btnMoveObstacleCancel = findViewById(R.id.btnMoveObstacleCancel);
        EditText edtArenaWidth = findViewById(R.id.edtArenaWidth);
        EditText edtArenaHeight = findViewById(R.id.edtArenaHeight);
        EditText edtRobotSize = findViewById(R.id.edtRobotSize);
        txtStatus = findViewById(R.id.txtStatus);
        txtLog = findViewById(R.id.txtLog);
        txtRobotStatus = findViewById(R.id.txtRobotStatus);
        edtSend = findViewById(R.id.edtSend);
        sectionHome = findViewById(R.id.sectionHome);
        sectionBluetooth = findViewById(R.id.sectionBluetooth);
        sectionArena = findViewById(R.id.sectionArena);
        sectionArenaMain = findViewById(R.id.sectionArenaMain);
        sectionArenaEdit = findViewById(R.id.sectionArenaEdit);
        sectionArenaMoveRobot = findViewById(R.id.sectionArenaMoveRobot);
        sectionArenaShortestPath = findViewById(R.id.sectionArenaShortestPath);
        sectionArenaTrial = findViewById(R.id.sectionArenaTrial);
        arenaCanvasContainer = findViewById(R.id.arenaCanvasContainer);
        sectionArenaEditSizes = findViewById(R.id.sectionArenaEditSizes);
        moveObstacleControls = findViewById(R.id.moveObstacleControls);
        obstaclePalette = findViewById(R.id.obstaclePalette);
        arenaView = findViewById(R.id.arenaView);
        sectionMoveManual = findViewById(R.id.sectionMoveManual);
        sectionMoveJoystick = findViewById(R.id.sectionMoveJoystick);
        txtMoveTiltHint = findViewById(R.id.txtMoveTiltHint);
        txtMoveTapHint = findViewById(R.id.txtMoveTapHint);
        joystickPad = findViewById(R.id.sectionMoveJoystick);

        btnOpenBluetooth.setOnClickListener(v -> showBluetoothSection());
        btnBackHome.setOnClickListener(v -> showHomeSection());
        btnOpenArena.setOnClickListener(v -> showArenaSection());
        btnBackHomeArena.setOnClickListener(v -> showHomeSection());
        btnArenaEdit.setOnClickListener(v -> showArenaSubsection(sectionArenaEdit));
        btnArenaMoveRobot.setOnClickListener(v -> showArenaSubsection(sectionArenaMoveRobot));
        btnArenaShortestPath.setOnClickListener(v -> showArenaSubsection(sectionArenaShortestPath));
        btnArenaTrial.setOnClickListener(v -> showArenaSubsection(sectionArenaTrial));
        btnBackArenaMainFromEdit.setOnClickListener(v -> showArenaMain());
        btnBackFromMove.setOnClickListener(v -> showArenaMain());
        btnBackArenaMainFromShortest.setOnClickListener(v -> showArenaMain());
        btnBackArenaMainFromTrial.setOnClickListener(v -> showArenaMain());
        btnArenaEditSizes.setOnClickListener(v -> showArenaEditSizes(
                edtArenaWidth, edtArenaHeight, edtRobotSize, edtSimAccel, edtSimTopSpeed, edtSimTurn
        ));
        btnBackArenaEditSizes.setOnClickListener(v -> {
            hideKeyboard();
            returnFromEditSizes();
        });
        btnApplyArenaSizes.setOnClickListener(v -> applyArenaSizes(
                edtArenaWidth, edtArenaHeight, edtRobotSize, edtSimAccel, edtSimTopSpeed, edtSimTurn
        ));
        btnArenaResetDefault.setOnClickListener(v -> confirmResetDefault());
        btnArenaClearObstacles.setOnClickListener(v -> confirmClearObstacles());
        btnModeSimplified.setOnClickListener(v -> setMovementMode(MovementMode.SIMPLIFIED));
        btnModeRealistic.setOnClickListener(v -> setMovementMode(MovementMode.REALISTIC));
        btnMoveForward.setOnClickListener(v -> moveForward(true));
        btnMoveBackward.setOnClickListener(v -> moveBackward(true));
        btnRotateLeft.setOnClickListener(v -> rotateLeft(true));
        btnRotateRight.setOnClickListener(v -> rotateRight(true));
        btnEditResetRobot.setOnClickListener(v -> resetRobotPosition());
        btnEditClearTrail.setOnClickListener(v -> arenaView.clearTrail());
        btnMoveResetRobot.setOnClickListener(v -> resetRobotPosition());
        btnMoveClearTrail.setOnClickListener(v -> arenaView.clearTrail());
        btnSaveLayout.setOnClickListener(v -> promptSaveLayout());
        btnLoadLayout.setOnClickListener(v -> promptLoadLayout());
        btnExportLayout.setOnClickListener(v -> promptExportLayout());
        btnSendLayout.setOnClickListener(v -> promptSendLayout());
        btnModeManual.setOnClickListener(v -> setMoveMode(MoveMode.MANUAL));
        btnModeJoystick.setOnClickListener(v -> setMoveMode(MoveMode.JOYSTICK));
        btnModeTilt.setOnClickListener(v -> {
            calibrateTilt();
            setMoveMode(MoveMode.TILT);
        });
        btnModeTap.setOnClickListener(v -> setMoveMode(MoveMode.TAP));
        btnComputePath.setOnClickListener(v -> computeShortestPath());
        btnPlayPath.setOnClickListener(v -> playPath());
        btnPausePath.setOnClickListener(v -> pausePath());
        btnResetPath.setOnClickListener(v -> resetPathPlayback());
        btnNextStep.setOnClickListener(v -> nextPathStep());
        btnPrevStep.setOnClickListener(v -> prevPathStep());
        btnTrialReset.setOnClickListener(v -> resetTimeTrial());
        btnTrialStart.setOnClickListener(v -> startTrialTimer());
        btnTrialPlayOptimal.setOnClickListener(v -> playTimeTrialOptimal());
        btnMoveObstacleDone.setOnClickListener(v -> {
            arenaView.confirmMoveObstacle();
            moveObstacleControls.setVisibility(View.GONE);
            arenaView.clearSelection();
        });
        btnMoveObstacleCancel.setOnClickListener(v -> {
            arenaView.cancelMoveObstacle();
            moveObstacleControls.setVisibility(View.GONE);
            arenaView.clearSelection();
        });
        setMovementMode(movementMode);

        btnMoveForward.setOnTouchListener((v, event) -> handleManualTouch(event, 1, 0));
        btnMoveBackward.setOnTouchListener((v, event) -> handleManualTouch(event, -1, 0));
        btnRotateLeft.setOnTouchListener((v, event) -> handleRotateTouch(event, true));
        btnRotateRight.setOnTouchListener((v, event) -> handleRotateTouch(event, false));

        obstaclePalette.setOnTouchListener((v, event) -> {
            if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                v.startDragAndDrop(null, new DragShadowBuilder(v), null, 0);
                return true;
            }
            return false;
        });
        joystickPad.setListener((normX, normY, active) -> handleJoystickMove(normX, normY, active));
        arenaView.setOnDragListener((v, event) -> handleArenaDrag(event));
        arenaView.setListener(new ArenaView.ArenaListener() {
            @Override
            public void onObstacleTapped(ArenaView.Obstacle obstacle) {
                showObstacleMenu(obstacle);
            }

            @Override
            public void onMoveModeChanged(boolean active) {
                moveObstacleControls.setVisibility(active ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onObstacleAdded(ArenaView.Obstacle obstacle) {
                sendObstacleMessage("ADD", obstacle);
            }

            @Override
            public void onObstacleMoved(ArenaView.Obstacle obstacle) {
                sendObstacleMessage("MOVE", obstacle);
            }

            @Override
            public void onObstacleRemoved(ArenaView.Obstacle obstacle) {
                sendObstacleMessage("DEL", obstacle);
            }

            @Override
            public void onObstacleSizeChanged(ArenaView.Obstacle obstacle) {
                sendObstacleMessage("SIZE", obstacle);
            }

            @Override
            public void onObstacleNumberChanged(int oldNumber, ArenaView.Obstacle obstacle) {
                sendLine("OBS,NUM," + oldNumber + "," + obstacle.number);
            }

            @Override
            public void onTargetAdded(ArenaView.Obstacle obstacle, int face) {
                String faceLabel = faceToLabel(face);
                sendLine("TARGET,ADD," + obstacle.number + "," + faceLabel);
            }

            @Override
            public void onTargetsCleared(ArenaView.Obstacle obstacle) {
                sendLine("TARGET,CLEAR," + obstacle.number);
            }

            @Override
            public void onTargetIdChanged(ArenaView.Obstacle obstacle) {
                int targetId = (obstacle.targetId == null) ? 0 : obstacle.targetId;
                sendLine("TARGET," + obstacle.number + "," + targetId);
            }

            @Override
            public void onCellTapped(int x, int y) {
                if (moveMode == MoveMode.TAP) {
                    moveRobotTo(x, y);
                }
            }
        });
        btnConnect.setOnClickListener(v -> ensureBtPermissionsThenChooseMode());
        btnSend.setOnClickListener(v -> sendLine(edtSend.getText().toString()));

        if (adapter == null) {
            setStatus("Bluetooth not supported on this device.");
        }
    }

    private void showHomeSection() {
        sectionHome.setVisibility(View.VISIBLE);
        sectionBluetooth.setVisibility(View.GONE);
        sectionArena.setVisibility(View.GONE);
        sectionArenaEditSizes.setVisibility(View.GONE);
    }

    private void showBluetoothSection() {
        sectionHome.setVisibility(View.GONE);
        sectionBluetooth.setVisibility(View.VISIBLE);
        sectionArena.setVisibility(View.GONE);
        sectionArenaEditSizes.setVisibility(View.GONE);
    }

    private void showArenaSection() {
        sectionHome.setVisibility(View.GONE);
        sectionBluetooth.setVisibility(View.GONE);
        sectionArena.setVisibility(View.VISIBLE);
        sectionArenaEditSizes.setVisibility(View.GONE);
        showArenaMain();
    }

    private void showArenaMain() {
        arenaView.cancelMoveObstacle();
        moveObstacleControls.setVisibility(View.GONE);
        stopTiltMode();
        stopJoystickRepeat();
        stopRotateRepeat();
        timeTrialActive = false;
        timeTrialPlayback = false;
        sectionArenaMain.setVisibility(View.VISIBLE);
        sectionArenaEdit.setVisibility(View.GONE);
        sectionArenaMoveRobot.setVisibility(View.GONE);
        sectionArenaShortestPath.setVisibility(View.GONE);
        sectionArenaTrial.setVisibility(View.GONE);
        arenaCanvasContainer.setVisibility(View.GONE);
        sectionArenaEditSizes.setVisibility(View.GONE);
    }

    private void showArenaSubsection(View subsection) {
        if (subsection != sectionArenaEdit) {
            arenaView.cancelMoveObstacle();
            moveObstacleControls.setVisibility(View.GONE);
        }
        sectionArenaMain.setVisibility(View.GONE);
        sectionArenaEdit.setVisibility(View.GONE);
        sectionArenaMoveRobot.setVisibility(View.GONE);
        sectionArenaShortestPath.setVisibility(View.GONE);
        sectionArenaTrial.setVisibility(View.GONE);
        sectionArenaEditSizes.setVisibility(View.GONE);
        subsection.setVisibility(View.VISIBLE);
        if (subsection == sectionArenaEdit || subsection == sectionArenaMoveRobot
                || subsection == sectionArenaShortestPath) {
            arenaCanvasContainer.setVisibility(View.VISIBLE);
        } else {
            arenaCanvasContainer.setVisibility(View.GONE);
        }
        if (subsection == sectionArenaEdit) {
            arenaView.setObstacleEditEnabled(true);
            arenaView.setTapMoveEnabled(false);
            timeTrialActive = false;
            btnBackFromMove.setVisibility(View.VISIBLE);
            stopRealisticSimulation();
        } else if (subsection == sectionArenaMoveRobot) {
            arenaView.setObstacleEditEnabled(false);
            setMoveMode(moveMode);
            timeTrialActive = false;
            btnBackFromMove.setVisibility(View.VISIBLE);
            if (movementMode == MovementMode.REALISTIC) {
                startRealisticSimulation();
            } else {
                arenaView.exitContinuousPose();
                stopRealisticSimulation();
            }
        } else if (subsection == sectionArenaShortestPath) {
            arenaView.setObstacleEditEnabled(false);
            arenaView.setTapMoveEnabled(false);
            stopTiltMode();
            timeTrialActive = false;
            btnBackFromMove.setVisibility(View.VISIBLE);
            stopRealisticSimulation();
        } else if (subsection == sectionArenaTrial) {
            sectionArenaMoveRobot.setVisibility(View.VISIBLE);
            arenaCanvasContainer.setVisibility(View.VISIBLE);
            arenaView.setObstacleEditEnabled(false);
            setMoveMode(moveMode);
            btnBackFromMove.setVisibility(View.GONE);
            startTimeTrial();
            if (movementMode == MovementMode.REALISTIC) {
                startRealisticSimulation();
            } else {
                stopRealisticSimulation();
            }
        } else {
            arenaView.setObstacleEditEnabled(true);
            arenaView.setTapMoveEnabled(false);
            stopTiltMode();
            timeTrialActive = false;
            btnBackFromMove.setVisibility(View.VISIBLE);
            stopRealisticSimulation();
        }
        if (subsection != sectionArenaTrial) {
            trialTimerHandler.removeCallbacksAndMessages(null);
        }
        if (subsection != sectionArenaShortestPath) {
            pathHandler.removeCallbacksAndMessages(null);
            pathPlaying = false;
            btnPausePath.setVisibility(View.GONE);
            rowPathStepControls.setVisibility(View.GONE);
            btnResetPath.setVisibility(View.GONE);
            btnPlayPath.setVisibility(View.GONE);
        }
    }

    private void showArenaEditSizes(EditText edtArenaWidth, EditText edtArenaHeight,
                                    EditText edtRobotSize, EditText edtSimAccel,
                                    EditText edtSimTopSpeed, EditText edtSimTurn) {
        sectionArena.setVisibility(View.GONE);
        sectionArenaEditSizes.setVisibility(View.VISIBLE);
        edtArenaWidth.setText(String.valueOf(arenaView.getArenaWidth()));
        edtArenaHeight.setText(String.valueOf(arenaView.getArenaHeight()));
        edtRobotSize.setText(String.valueOf(arenaView.getRobotSize()));
        edtSimAccel.setText(String.format(Locale.US, "%.2f", simAccel));
        edtSimTopSpeed.setText(String.format(Locale.US, "%.2f", simMaxSpeed));
        edtSimTurn.setText(String.format(Locale.US, "%.2f", simMaxSteer));
    }

    private void applyArenaSizes(EditText edtArenaWidth, EditText edtArenaHeight,
                                 EditText edtRobotSize, EditText edtSimAccel,
                                 EditText edtSimTopSpeed, EditText edtSimTurn) {
        hideKeyboard();
        Integer width = parsePositiveInt(edtArenaWidth.getText().toString());
        Integer height = parsePositiveInt(edtArenaHeight.getText().toString());
        Integer robotSize = parsePositiveInt(edtRobotSize.getText().toString());
        Float accel = parsePositiveFloat(edtSimAccel.getText().toString());
        Float topSpeed = parsePositiveFloat(edtSimTopSpeed.getText().toString());
        Float turn = parsePositiveFloat(edtSimTurn.getText().toString());

        if (width == null || height == null || robotSize == null) {
            setStatus("Invalid sizes. Use positive integers.");
            return;
        }

        if (width > MAX_ARENA_SIZE || height > MAX_ARENA_SIZE) {
            setStatus("Arena size max is " + MAX_ARENA_SIZE + ".");
            return;
        }

        if (robotSize > width || robotSize > height) {
            setStatus("Robot must fit inside the arena.");
            return;
        }

        arenaView.resetArena(width, height, robotSize);
        if (accel != null) simAccel = accel;
        if (topSpeed != null) simMaxSpeed = topSpeed;
        if (turn != null) simMaxSteer = Math.max(0.1f, Math.min(turn, 1.4f));
        sendLine("ARENA,SIZE," + width + "," + height);
        sendLine("ROBOT,SIZE," + robotSize);
        returnFromEditSizes();
    }

    private void returnFromEditSizes() {
        sectionArenaEditSizes.setVisibility(View.GONE);
        sectionArena.setVisibility(View.VISIBLE);
        showArenaSubsection(sectionArenaEdit);
    }

    private void setMovementMode(MovementMode mode) {
        movementMode = mode;
        updateMovementModeButtons();
        if (mode == MovementMode.REALISTIC) {
            arenaView.exitContinuousPose();
            if (sectionArenaMoveRobot.getVisibility() == View.VISIBLE) {
                startRealisticSimulation();
            }
        } else {
            stopRealisticSimulation();
            arenaView.exitContinuousPose();
        }
    }

    private void updateMovementModeButtons() {
        boolean simplified = movementMode == MovementMode.SIMPLIFIED;
        btnModeSimplified.setEnabled(!simplified);
        btnModeRealistic.setEnabled(simplified);
        String label = simplified ? "Mode: Simplified" : "Mode: Realistic";
        setStatus(label);
    }

    private boolean handleManualTouch(android.view.MotionEvent event, int throttleDir, int steerDir) {
        if (movementMode != MovementMode.REALISTIC) return false;
        if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
            simThrottle = throttleDir;
            simSteer = steerDir;
        } else if (event.getAction() == android.view.MotionEvent.ACTION_UP
                || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
            if (throttleDir != 0) simThrottle = 0;
            if (steerDir != 0) simSteer = 0;
        }
        return true;
    }

    private boolean handleRotateTouch(android.view.MotionEvent event, boolean left) {
        if (movementMode != MovementMode.REALISTIC) return false;
        if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
            if (left) {
                rotateLeft(true);
            } else {
                rotateRight(true);
            }
            startRotateRepeat(left ? -1 : 1);
            return true;
        }
        if (event.getAction() == android.view.MotionEvent.ACTION_UP
                || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
            stopRotateRepeat();
            return true;
        }
        return true;
    }

    private void startRotateRepeat(int dir) {
        rotateRepeatDir = dir;
        if (rotateRepeatActive) return;
        rotateRepeatActive = true;
        moveHandler.postDelayed(rotateRepeatRunnable, ROTATE_REPEAT_MS);
    }

    private void stopRotateRepeat() {
        rotateRepeatActive = false;
        rotateRepeatDir = 0;
        moveHandler.removeCallbacks(rotateRepeatRunnable);
    }

    private final Runnable rotateRepeatRunnable = new Runnable() {
        @Override
        public void run() {
            if (!rotateRepeatActive || movementMode != MovementMode.REALISTIC) return;
            if (!actionAnimRunning) {
                if (rotateRepeatDir < 0) {
                    rotateLeft(true);
                } else if (rotateRepeatDir > 0) {
                    rotateRight(true);
                }
            }
            moveHandler.postDelayed(this, ROTATE_REPEAT_MS);
        }
    };

    private void startRealisticSimulation() {
        if (simRunning) return;
        simRunning = true;
        simX = arenaView.getRobotX();
        simY = arenaView.getRobotY();
        simHeading = (float) (arenaView.getRobotDir() * (Math.PI / 2.0));
        simSpeed = 0f;
        simThrottle = 0f;
        simSteer = 0f;
        simHandler.post(simRunnable);
    }

    private void stopRealisticSimulation() {
        simRunning = false;
        simHandler.removeCallbacksAndMessages(null);
        simThrottle = 0f;
        simSteer = 0f;
        simSpeed = 0f;
    }

    private void stopActionAnimation() {
        actionAnimRunning = false;
        actionOnDone = null;
        pathHandler.removeCallbacks(actionAnimRunnable);
    }

    private final Runnable actionAnimRunnable = new Runnable() {
        @Override
        public void run() {
            if (!actionAnimRunning) return;
            long now = SystemClock.elapsedRealtime();
            double t = Math.min(1.0, (now - actionStartMs) / (double) actionDurationMs);
            float nx;
            float ny;
            float nh;
            if (actionArc) {
                float ang = (float) (actionArcStartAng + (actionArcEndAng - actionArcStartAng) * t);
                float radius = (float) Math.hypot(actionStartX - actionArcCx, actionStartY - actionArcCy);
                nx = actionArcCx + (float) (radius * Math.cos(ang));
                ny = actionArcCy + (float) (radius * Math.sin(ang));
                nh = (float) (actionStartHeading + (actionTargetHeading - actionStartHeading) * t);
            } else {
                nx = (float) (actionStartX + (actionTargetX - actionStartX) * t);
                ny = (float) (actionStartY + (actionTargetY - actionStartY) * t);
                nh = (float) (actionStartHeading + (actionTargetHeading - actionStartHeading) * t);
            }
            simX = nx;
            simY = ny;
            simHeading = nh;
            arenaView.setContinuousPose(nx, ny, nh);
            if (t >= 1.0) {
                simX = actionTargetX;
                simY = actionTargetY;
                simHeading = actionTargetHeading;
                arenaView.setContinuousPose(simX, simY, simHeading);
                actionAnimRunning = false;
                Runnable done = actionOnDone;
                actionOnDone = null;
                if (done != null) done.run();
                return;
            }
            pathHandler.postDelayed(this, 16);
        }
    };

    private final Runnable simRunnable = new Runnable() {
        @Override
        public void run() {
            if (!simRunning) return;
            updateSimStep(SIM_DT);
            simHandler.postDelayed(this, (long) (SIM_DT * 1000));
        }
    };

    private void updateSimStep(float dt) {
        float targetAccel = 0f;
        if (simThrottle > 0) targetAccel = simAccel;
        if (simThrottle < 0) targetAccel = -SIM_BRAKE;

        if (targetAccel == 0f) {
            if (simSpeed > 0) {
                simSpeed = Math.max(0f, simSpeed - SIM_DRAG * dt);
            } else if (simSpeed < 0) {
                simSpeed = Math.min(0f, simSpeed + SIM_DRAG * dt);
            }
        } else {
            simSpeed += targetAccel * dt;
        }
        simSpeed = Math.max(-simMaxSpeed, Math.min(simMaxSpeed, simSpeed));

        float steer = Math.max(-1f, Math.min(1f, simSteer));
        float steerAngle = steer * simMaxSteer;
        float headingRate = 0f;
        if (Math.abs(steerAngle) > 0.0001f) {
            headingRate = (float) ((simSpeed / SIM_WHEELBASE) * Math.tan(steerAngle));
        }
        float newHeading = simHeading + headingRate * dt;

        float dx = (float) (simSpeed * Math.sin(newHeading) * dt);
        float dy = (float) (simSpeed * Math.cos(newHeading) * dt);
        float newX = simX + dx;
        float newY = simY + dy;

        if (arenaView.isContinuousPoseValid(newX, newY)) {
            simX = newX;
            simY = newY;
            simHeading = newHeading;
            arenaView.setContinuousPose(simX, simY, simHeading);
            if (timeTrialActive && !timeTrialPlayback) {
                updateTrialTime();
            }
        } else {
            simSpeed = 0f;
        }
    }

    private void promptSaveLayout() {
        String[] names = getSavedLayoutNames();
        List<String> items = new ArrayList<>();
        Collections.addAll(items, names);
        items.add("New layout...");
        new AlertDialog.Builder(this)
                .setTitle("Save Layout")
                .setItems(items.toArray(new String[0]), (d, which) -> {
                    if (which == items.size() - 1) {
                        promptSaveLayoutAsNew();
                    } else {
                        String name = items.get(which);
                        confirmOverwriteLayout(name);
                    }
                })
                .show();
    }

    private void promptSaveLayoutAsNew() {
        EditText input = new EditText(this);
        input.setHint("Layout name");
        new AlertDialog.Builder(this)
                .setTitle("Save New Layout")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        setStatus("Layout name required.");
                        return;
                    }
                    saveLayoutWithName(name);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmOverwriteLayout(String name) {
        new AlertDialog.Builder(this)
                .setTitle("Overwrite Layout")
                .setMessage("Overwrite \"" + name + "\"?")
                .setPositiveButton("Overwrite", (d, w) -> saveLayoutWithName(name))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveLayoutWithName(String name) {
        JSONObject json = buildLayoutJson();
        if (json == null) {
            setStatus("Failed to build layout.");
            return;
        }
        saveLayoutToPrefs(name, json.toString());
        Toast.makeText(this, "Saved layout: " + name, Toast.LENGTH_SHORT).show();
    }

    private void promptLoadLayout() {
        String[] names = getSavedLayoutNames();
        if (names.length == 0) {
            Toast.makeText(this, "No saved layouts.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Load Layout")
                .setItems(names, (d, which) -> {
                    String name = names[which];
                    String json = loadLayoutFromPrefs(name);
                    if (json == null) {
                        setStatus("Failed to load layout.");
                        return;
                    }
                    if (applyLayoutJson(json)) {
                        Toast.makeText(this, "Loaded layout: " + name, Toast.LENGTH_SHORT).show();
                    } else {
                        setStatus("Invalid layout data.");
                    }
                })
                .show();
    }

    private void promptExportLayout() {
        EditText input = new EditText(this);
        input.setHint("Layout file name");
        new AlertDialog.Builder(this)
                .setTitle("Export Layout")
                .setView(input)
                .setPositiveButton("Export", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        setStatus("File name required.");
                        return;
                    }
                    JSONObject json = buildLayoutJson();
                    if (json == null) {
                        setStatus("Failed to build layout.");
                        return;
                    }
                    File file = exportLayoutToFile(name, json.toString());
                    if (file != null) {
                        Toast.makeText(this, "Exported to " + file.getAbsolutePath(),
                                Toast.LENGTH_LONG).show();
                    } else {
                        setStatus("Export failed.");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void promptSendLayout() {
        EditText input = new EditText(this);
        input.setHint("Layout name");
        new AlertDialog.Builder(this)
                .setTitle("Send Layout (Bluetooth)")
                .setView(input)
                .setPositiveButton("Send", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) {
                        setStatus("Layout name required.");
                        return;
                    }
                    JSONObject json = buildLayoutJson();
                    if (json == null) {
                        setStatus("Failed to build layout.");
                        return;
                    }
                    sendLayoutBluetooth(name, json.toString());
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String[] getSavedLayoutNames() {
        Map<String, ?> all = getSharedPreferences(LAYOUT_PREFS, MODE_PRIVATE).getAll();
        ArrayList<String> names = new ArrayList<>(all.keySet());
        Collections.sort(names);
        return names.toArray(new String[0]);
    }

    private void saveLayoutToPrefs(String name, String json) {
        getSharedPreferences(LAYOUT_PREFS, MODE_PRIVATE)
                .edit()
                .putString(name, json)
                .apply();
    }

    private String loadLayoutFromPrefs(String name) {
        return getSharedPreferences(LAYOUT_PREFS, MODE_PRIVATE).getString(name, null);
    }

    private File exportLayoutToFile(String name, String json) {
        try {
            String safeName = name.replaceAll("[^a-zA-Z0-9._-]", "_");
            File base = getExternalFilesDir(null);
            if (base == null) base = getFilesDir();
            File dir = new File(base, "layouts");
            if (!dir.exists() && !dir.mkdirs()) return null;
            File file = new File(dir, safeName + ".json");
            try (FileOutputStream fos = new FileOutputStream(file)) {
                fos.write(json.getBytes(StandardCharsets.UTF_8));
            }
            return file;
        } catch (IOException e) {
            return null;
        }
    }

    private void sendLayoutBluetooth(String name, String json) {
        String encoded = Base64.encodeToString(json.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        sendLine("LAYOUT,DATA," + name + "," + encoded);
    }

    private JSONObject buildLayoutJson() {
        try {
            JSONObject obj = new JSONObject();
            obj.put("arenaWidth", arenaView.getArenaWidth());
            obj.put("arenaHeight", arenaView.getArenaHeight());
            obj.put("robotSize", arenaView.getRobotSize());
            obj.put("robotX", arenaView.getRobotX());
            obj.put("robotY", arenaView.getRobotY());
            obj.put("robotDir", arenaView.getRobotDir());
            JSONArray obs = new JSONArray();
            for (ArenaView.Obstacle o : arenaView.getObstaclesSnapshot()) {
                JSONObject ob = new JSONObject();
                ob.put("number", o.number);
                ob.put("x", o.x);
                ob.put("y", o.y);
                ob.put("size", o.size);
                ob.put("targetId", o.targetId == null ? 0 : o.targetId);
                ob.put("targetN", o.targetNorth);
                ob.put("targetE", o.targetEast);
                ob.put("targetS", o.targetSouth);
                ob.put("targetW", o.targetWest);
                obs.put(ob);
            }
            obj.put("obstacles", obs);
            return obj;
        } catch (JSONException e) {
            return null;
        }
    }

    private boolean applyLayoutJson(String json) {
        try {
            return applyLayoutJson(new JSONObject(json));
        } catch (JSONException e) {
            return false;
        }
    }

    private boolean applyLayoutJson(JSONObject obj) {
        int width = obj.optInt("arenaWidth", -1);
        int height = obj.optInt("arenaHeight", -1);
        int robotSize = obj.optInt("robotSize", -1);
        int robotX = obj.optInt("robotX", 0);
        int robotY = obj.optInt("robotY", 0);
        int robotDir = obj.optInt("robotDir", 0);
        if (width <= 0 || height <= 0 || robotSize <= 0) return false;
        if (width > MAX_ARENA_SIZE || height > MAX_ARENA_SIZE) return false;
        if (robotSize > width || robotSize > height) return false;

        suppressOutbound = true;
        try {
            arenaView.resetArena(width, height, robotSize);
            JSONArray obs = obj.optJSONArray("obstacles");
            if (obs != null) {
                for (int i = 0; i < obs.length(); i++) {
                    JSONObject ob = obs.optJSONObject(i);
                    if (ob == null) continue;
                    int number = ob.optInt("number", -1);
                    int x = ob.optInt("x", -1);
                    int y = ob.optInt("y", -1);
                    int size = ob.optInt("size", 1);
                    if (number <= 0 || x < 0 || y < 0 || size <= 0) continue;
                    arenaView.addObstacleWithNumber(number, x, y, size);
                    if (ob.optBoolean("targetN", false)) arenaView.addTargetByNumber(number, "N");
                    if (ob.optBoolean("targetE", false)) arenaView.addTargetByNumber(number, "E");
                    if (ob.optBoolean("targetS", false)) arenaView.addTargetByNumber(number, "S");
                    if (ob.optBoolean("targetW", false)) arenaView.addTargetByNumber(number, "W");
                    int targetId = ob.optInt("targetId", 0);
                    if (targetId > 0) arenaView.setTargetIdByNumber(number, targetId);
                }
            }
            if (!arenaView.setRobotPose(robotX, robotY, robotDir)) {
                return false;
            }
            arenaView.clearTrail();
            return true;
        } finally {
            suppressOutbound = false;
        }
    }

    private Integer parsePositiveInt(String s) {
        try {
            int v = Integer.parseInt(s.trim());
            if (v <= 0) return null;
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private Integer parseNonNegativeInt(String s) {
        try {
            int v = Integer.parseInt(s.trim());
            if (v < 0) return null;
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private Float parsePositiveFloat(String s) {
        if (s == null) return null;
        String trimmed = s.trim();
        if (trimmed.isEmpty()) return null;
        try {
            float v = Float.parseFloat(trimmed);
            if (v <= 0f) return null;
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private int parseDir(String dir) {
        if (dir == null) return -1;
        switch (dir) {
            case "N":
                return 0;
            case "E":
                return 1;
            case "S":
                return 2;
            case "W":
                return 3;
            default:
                return -1;
        }
    }

    private void hideKeyboard() {
        View view = getCurrentFocus();
        if (view == null) return;
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private boolean handleArenaDrag(DragEvent event) {
        if (event.getAction() == DragEvent.ACTION_DROP) {
            arenaView.placeObstacleAtPixel(event.getX(), event.getY());
            return true;
        }
        return true;
    }

    private void showObstacleMenu(ArenaView.Obstacle obstacle) {
        String[] items = new String[]{"Remove obstacle", "Add target", "Remove targets", "Move obstacle", "Edit size", "Edit number", "Edit target ID"};
        new AlertDialog.Builder(this)
                .setTitle("Obstacle")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        arenaView.removeObstacle(obstacle.id);
                        arenaView.clearSelection();
                    } else if (which == 1) {
                        showTargetMenu(obstacle);
                    } else if (which == 2) {
                        arenaView.clearTargets(obstacle.id);
                        arenaView.clearSelection();
                    } else if (which == 3) {
                        arenaView.beginMoveObstacle(obstacle.id);
                    } else if (which == 4) {
                        showObstacleSizeMenu(obstacle);
                    } else if (which == 5) {
                        showObstacleNumberMenu(obstacle);
                    } else {
                        showTargetIdMenu(obstacle);
                    }
                })
                .setNegativeButton("Cancel", (d, w) -> arenaView.clearSelection())
                .show();
    }

    private void showTargetMenu(ArenaView.Obstacle obstacle) {
        String[] labels = new String[]{"North", "East", "South", "West"};
        boolean[] disabled = new boolean[]{
                obstacle.targetNorth, obstacle.targetEast, obstacle.targetSouth, obstacle.targetWest
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Add target")
                .setItems(labels, (dialog, which) -> {
                    if (disabled[which]) return;
                    arenaView.addTarget(obstacle.id, which);
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", (d, w) -> arenaView.clearSelection());

        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(d -> {
            dialog.getListView().post(() -> {
                for (int i = 0; i < labels.length; i++) {
                    if (disabled[i]) {
                        View row = dialog.getListView().getChildAt(i);
                        if (row != null) row.setEnabled(false);
                    }
                }
            });
        });
        dialog.show();
    }

    private void showObstacleSizeMenu(ArenaView.Obstacle obstacle) {
        EditText input = new EditText(this);
        input.setHint("New size");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(obstacle.size));

        new AlertDialog.Builder(this)
                .setTitle("Edit obstacle size")
                .setView(input)
                .setPositiveButton("Apply", (d, w) -> {
                    Integer size = parsePositiveInt(input.getText().toString());
                    if (size == null) {
                        setStatus("Invalid size.");
                        arenaView.clearSelection();
                        return;
                    }
                    if (!arenaView.updateObstacleSize(obstacle.id, size)) {
                        setStatus("Obstacle size does not fit.");
                    }
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", (d, w) -> arenaView.clearSelection())
                .show();
    }

    private void showObstacleNumberMenu(ArenaView.Obstacle obstacle) {
        EditText input = new EditText(this);
        input.setHint("New number");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(obstacle.number));

        new AlertDialog.Builder(this)
                .setTitle("Edit obstacle number")
                .setView(input)
                .setPositiveButton("Apply", (d, w) -> {
                    Integer number = parsePositiveInt(input.getText().toString());
                    if (number == null) {
                        setStatus("Invalid number.");
                        arenaView.clearSelection();
                        return;
                    }
                    if (!arenaView.updateObstacleNumber(obstacle.id, number)) {
                        setStatus("Obstacle number already in use.");
                    }
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", (d, w) -> arenaView.clearSelection())
                .show();
    }

    private void showTargetIdMenu(ArenaView.Obstacle obstacle) {
        EditText input = new EditText(this);
        input.setHint("Target ID (blank to clear)");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        if (obstacle.targetId != null) {
            input.setText(String.valueOf(obstacle.targetId));
        }

        new AlertDialog.Builder(this)
                .setTitle("Edit target ID")
                .setView(input)
                .setPositiveButton("Apply", (d, w) -> {
                    String raw = input.getText().toString().trim();
                    Integer targetId = raw.isEmpty() ? null : parsePositiveInt(raw);
                    if (raw.length() > 0 && targetId == null) {
                        setStatus("Invalid target ID.");
                        arenaView.clearSelection();
                        return;
                    }
                    arenaView.setTargetId(obstacle.id, targetId);
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", (d, w) -> arenaView.clearSelection())
                .show();
    }

    private void confirmResetDefault() {
        new AlertDialog.Builder(this)
                .setTitle("Reset arena")
                .setMessage("Reset arena sizes to default and clear all obstacles?")
                .setPositiveButton("Reset", (d, w) -> {
                    arenaView.resetToDefault();
                    moveObstacleControls.setVisibility(View.GONE);
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmClearObstacles() {
        new AlertDialog.Builder(this)
                .setTitle("Clear obstacles")
                .setMessage("Remove all obstacles and targets?")
                .setPositiveButton("Clear", (d, w) -> {
                    arenaView.clearObstacles();
                    moveObstacleControls.setVisibility(View.GONE);
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void sendObstacleMessage(String type, ArenaView.Obstacle obstacle) {
        String msg;
        if ("ADD".equals(type)) {
            msg = "OBS,ADD," + obstacle.number + "," + obstacle.x + "," + obstacle.y + "," + obstacle.size;
        } else if ("MOVE".equals(type)) {
            msg = "OBS,MOVE," + obstacle.number + "," + obstacle.x + "," + obstacle.y;
        } else if ("DEL".equals(type)) {
            msg = "OBS,DEL," + obstacle.number;
        } else if ("SIZE".equals(type)) {
            msg = "OBS,SIZE," + obstacle.number + "," + obstacle.size;
        } else {
            return;
        }
        sendLine(msg);
    }

    private String faceToLabel(int face) {
        switch (face) {
            case 0:
                return "N";
            case 1:
                return "E";
            case 2:
                return "S";
            case 3:
                return "W";
            default:
                return "?";
        }
    }

    private void ensureBtPermissionsThenChooseMode() {
        if (adapter == null) return;

        ArrayList<String> needed = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                    != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.BLUETOOTH_SCAN);
            }
        }

        if (!needed.isEmpty()) {
            permLauncher.launch(needed.toArray(new String[0]));
            return;
        }

        showConnectModeDialog();
    }

    private void showConnectModeDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Connect Bluetooth")
                .setItems(new String[]{"Listen for PC (recommended)", "Connect to paired device"}, (dialog, which) -> {
                    if (which == 0) {
                        startAcceptThread();
                    } else {
                        showPairedDevicesDialog();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPairedDevicesDialog() {
        if (adapter == null) return;

        if (!adapter.isEnabled()) {
            setStatus("Enable Bluetooth in tablet settings first.");
            return;
        }

        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        if (bonded == null || bonded.isEmpty()) {
            setStatus("No paired devices found. Pair with PC/AMD tool first.");
            return;
        }

        ArrayList<BluetoothDevice> devices = new ArrayList<>(bonded);
        String[] labels = new String[devices.size()];
        for (int i = 0; i < devices.size(); i++) {
            BluetoothDevice d = devices.get(i);
            String name = (d.getName() == null) ? "Unnamed" : d.getName();
            labels[i] = name + "\n" + d.getAddress();
        }

        new AlertDialog.Builder(this)
                .setTitle("Select paired device")
                .setItems(labels, (dialog, which) -> connectToDevice(devices.get(which)))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startAcceptThread() {
        disconnect();
        setStatus("Waiting for AMD tool to connect...");

        if (accepting) return;
        accepting = true;
        acceptThread = new Thread(() -> {
            while (shouldAccept && adapter != null) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                                != PackageManager.PERMISSION_GRANTED) {
                            runOnUiThread(() -> setStatus("Missing BLUETOOTH_CONNECT permission."));
                            accepting = false;
                            return;
                        }
                    }

                    if (!adapter.isEnabled()) {
                        runOnUiThread(() -> setStatus("Enable Bluetooth in tablet settings first."));
                        accepting = false;
                        return;
                    }

                    if (serverSocket == null) {
                        serverSocket = adapter.listenUsingRfcommWithServiceRecord(
                                "MDPRemoteController", SPP_UUID
                        );
                    }

                    BluetoothSocket s = serverSocket.accept();
                    if (s != null) {
                        socket = s;
                        out = socket.getOutputStream();
                        BluetoothDevice device = socket.getRemoteDevice();
                        runOnUiThread(() -> setStatus("Connected: " + device.getName()));
                        startReaderThread();
                    }
                } catch (IOException e) {
                    runOnUiThread(() -> setStatus("Listen failed: " + e.getMessage()));
                    closeServerSocket();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ignored) {
                        break;
                    }
                }
            }
            accepting = false;
        });
        acceptThread.start();
    }

    private void connectToDevice(BluetoothDevice device) {
        disconnect();
        setStatus("Connecting to " + device.getName() + "...");

        new Thread(() -> {
            if (!attemptClientConnect(device)) {
                runOnUiThread(() -> setStatus("Connect failed. Try again."));
            }
        }).start();
    }

    private boolean attemptClientConnect(BluetoothDevice device) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                        != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> setStatus("Missing BLUETOOTH_CONNECT permission."));
                    return false;
                }
            }

            BluetoothSocket s = device.createRfcommSocketToServiceRecord(SPP_UUID);
            adapter.cancelDiscovery();
            s.connect();

            socket = s;
            out = socket.getOutputStream();

            runOnUiThread(() -> setStatus("Connected: " + device.getName()));
            startReaderThread();
            return true;
        } catch (IOException e) {
            disconnect();
            return false;
        }
    }

    private void startReaderThread() {
        readerThread = new Thread(() -> {
            try {
                InputStream in = socket.getInputStream();
                byte[] buffer = new byte[1024];
                StringBuilder pending = new StringBuilder();
                int read;
                while (!Thread.currentThread().isInterrupted() && (read = in.read(buffer)) != -1) {
                    String chunk = new String(buffer, 0, read, StandardCharsets.UTF_8);
                    pending.append(chunk);

                    int newlineIndex = indexOfLineBreak(pending);
                    if (newlineIndex == -1) {
                        if (pending.length() > 0) {
                            String msg = pending.toString().trim();
                            if (!msg.isEmpty()) {
                                String finalLine = msg;
                                runOnUiThread(() -> handleIncomingLine(finalLine));
                            }
                            pending.setLength(0);
                        }
                        continue;
                    }

                    while (newlineIndex != -1) {
                        String line = extractLine(pending, newlineIndex);
                        if (!line.isEmpty()) {
                            String finalLine = line;
                            runOnUiThread(() -> handleIncomingLine(finalLine));
                        }
                        newlineIndex = indexOfLineBreak(pending);
                    }
                }
                runOnUiThread(() -> appendLog("Reader stopped: disconnected"));
                runOnUiThread(() -> setStatus("Disconnected. Waiting for reconnect..."));
            } catch (IOException e) {
                runOnUiThread(() -> appendLog("Reader stopped: " + e.getMessage()));
                runOnUiThread(() -> setStatus("Disconnected. Waiting for reconnect..."));
            } finally {
                closeClientSocket();
            }
        });
        readerThread.start();
    }

    private void sendLine(String msg) {
        if (suppressOutbound) return;
        if (out == null) {
            appendLog("TX failed: not connected");
            return;
        }

        new Thread(() -> {
            try {
                String line = msg + "\n";
                out.write(line.getBytes(StandardCharsets.UTF_8));
                out.flush();
                runOnUiThread(() -> appendLog("TX: " + msg));
            } catch (IOException e) {
                runOnUiThread(() -> appendLog("TX error: " + e.getMessage()));
            }
        }).start();
    }

    private void disconnect() {
        try {
            if (readerThread != null) readerThread.interrupt();
        } catch (Exception ignored) {}

        try {
            if (out != null) out.close();
        } catch (Exception ignored) {}

        closeClientSocket();
        closeServerSocket();
        out = null;
        readerThread = null;
    }

    private void setStatus(String s) {
        txtStatus.setText("Status: " + s);
        appendLog("STATUS: " + s);
    }

    private void handleIncomingLine(String line) {
        appendLog("RX: " + line);
        String status = parseStatusLine(line);
        if (status != null) {
            txtRobotStatus.setText(status);
        }
        handleMoveCommand(line);
        handleArenaCommand(line);
    }

    private void handleArenaCommand(String line) {
        suppressOutbound = true;
        try {
        String trimmed = line.trim();
        String upperTrim = trimmed.toUpperCase();
        if (upperTrim.startsWith("LAYOUT,")) {
            String[] parts = trimmed.split(",", 4);
            if (parts.length >= 3) {
                String action = parts[1].trim().toUpperCase();
                if ("DATA".equals(action) && parts.length == 4) {
                    String name = parts[2].trim();
                    String data = parts[3].trim();
                    try {
                        byte[] decoded = Base64.decode(data, Base64.NO_WRAP);
                        String json = new String(decoded, StandardCharsets.UTF_8);
                        saveLayoutToPrefs(name, json);
                        applyLayoutJson(json);
                        Toast.makeText(this, "Received layout: " + name, Toast.LENGTH_SHORT).show();
                    } catch (IllegalArgumentException e) {
                        setStatus("Invalid layout data.");
                    }
                } else if ("REQ".equals(action) && parts.length >= 3) {
                    String name = parts[2].trim();
                    String json = loadLayoutFromPrefs(name);
                    if (json != null) sendLayoutBluetooth(name, json);
                }
            }
            return;
        }
        if (upperTrim.startsWith("OBS,")) {
            String[] parts = trimmed.split(",");
            if (parts.length < 3) return;
            String action = parts[1].trim().toUpperCase();
            if ("ADD".equals(action) && parts.length >= 5) {
                Integer num = parsePositiveInt(parts[2]);
                Integer x = parseNonNegativeInt(parts[3]);
                Integer y = parseNonNegativeInt(parts[4]);
                Integer size = (parts.length >= 6) ? parsePositiveInt(parts[5]) : 1;
                if (num == null || x == null || y == null || size == null) return;
                arenaView.addObstacleWithNumber(num, x, y, size);
            } else if ("MOVE".equals(action) && parts.length >= 5) {
                Integer num = parsePositiveInt(parts[2]);
                Integer x = parseNonNegativeInt(parts[3]);
                Integer y = parseNonNegativeInt(parts[4]);
                if (num == null || x == null || y == null) return;
                arenaView.moveObstacleByNumber(num, x, y);
            } else if ("DEL".equals(action) && parts.length >= 3) {
                Integer num = parsePositiveInt(parts[2]);
                if (num == null) return;
                arenaView.removeObstacleByNumber(num);
            } else if ("SIZE".equals(action) && parts.length >= 4) {
                Integer num = parsePositiveInt(parts[2]);
                Integer size = parsePositiveInt(parts[3]);
                if (num == null || size == null) return;
                arenaView.updateObstacleSizeByNumber(num, size);
            } else if ("NUM".equals(action) && parts.length >= 4) {
                Integer oldNum = parsePositiveInt(parts[2]);
                Integer newNum = parsePositiveInt(parts[3]);
                if (oldNum == null || newNum == null) return;
                arenaView.updateObstacleNumberByNumber(oldNum, newNum);
            }
            return;
        }
        if (upperTrim.startsWith("TARGET,")) {
            String[] parts = trimmed.split(",");
            if (parts.length < 3) return;
            String action = parts[1].trim().toUpperCase();
            if ("ADD".equals(action) && parts.length >= 4) {
                Integer num = parsePositiveInt(parts[2]);
                if (num == null) return;
                String face = parts[3].trim().toUpperCase();
                arenaView.addTargetByNumber(num, face);
            } else if ("CLEAR".equals(action)) {
                Integer num = parsePositiveInt(parts[2]);
                if (num == null) return;
                arenaView.clearTargetsByNumber(num);
            } else {
                Integer num = parsePositiveInt(parts[1]);
                Integer targetId = parseNonNegativeInt(parts[2]);
                if (num == null) return;
                arenaView.setTargetIdByNumber(num, targetId);
            }
            return;
        }
        if (upperTrim.startsWith("ROBOT,")) {
            String[] parts = trimmed.split(",");
            if (parts.length >= 3 && "SIZE".equalsIgnoreCase(parts[1].trim())) {
                Integer size = parsePositiveInt(parts[2]);
                if (size == null) return;
                int width = arenaView.getArenaWidth();
                int height = arenaView.getArenaHeight();
                if (size > width || size > height) return;
                arenaView.resetArena(width, height, size);
                return;
            }
            if (parts.length >= 4) {
                Integer x = parseNonNegativeInt(parts[1]);
                Integer y = parseNonNegativeInt(parts[2]);
                String dirStr = parts[3].trim().toUpperCase();
                if (x == null || y == null) return;
                int dir = parseDir(dirStr);
                if (dir < 0) return;
                arenaView.setRobotPose(x, y, dir);
            }
            return;
        }
        if (upperTrim.startsWith("ARENA,SIZE,")) {
            String[] parts = trimmed.split(",");
            if (parts.length >= 4) {
                Integer width = parsePositiveInt(parts[2]);
                Integer height = parsePositiveInt(parts[3]);
                if (width == null || height == null) return;
                if (width > MAX_ARENA_SIZE || height > MAX_ARENA_SIZE) return;
                int robotSize = arenaView.getRobotSize();
                if (robotSize > width || robotSize > height) return;
                arenaView.resetArena(width, height, robotSize);
            }
        }
        } finally {
            suppressOutbound = false;
        }
    }

    private void handleMoveCommand(String line) {
        String cmd = normalizeCommand(line);
        if (cmd == null || cmd.isEmpty()) return;

        if (cmd.equals("FORWARD") || cmd.equals("MOVE_FORWARD") || cmd.equals("MOVE,FORWARD") || cmd.equals("MOVE:FORWARD")) {
            moveForward(false);
        } else if (cmd.equals("BACKWARD") || cmd.equals("MOVE_BACKWARD") || cmd.equals("MOVE,BACKWARD") || cmd.equals("MOVE:BACKWARD")) {
            moveBackward(false);
        } else if (cmd.equals("ROTATE_LEFT") || cmd.equals("TURN_LEFT") || cmd.equals("ROTATE,LEFT") || cmd.equals("TURN,LEFT")) {
            rotateLeft(false);
        } else if (cmd.equals("ROTATE_RIGHT") || cmd.equals("TURN_RIGHT") || cmd.equals("ROTATE,RIGHT") || cmd.equals("TURN,RIGHT")) {
            rotateRight(false);
        }
    }

    private void moveForward(boolean send) {
        if (arenaView.moveForward()) {
            if (send && timeTrialActive && !timeTrialPlayback) {
                onTrialAction();
            }
            if (send) {
            sendLine("MOVE,FORWARD");
            }
        }
    }

    private void moveBackward(boolean send) {
        if (arenaView.moveBackward()) {
            if (send && timeTrialActive && !timeTrialPlayback) {
                onTrialAction();
            }
            if (send) {
            sendLine("MOVE,BACKWARD");
            }
        }
    }

    private void rotateLeft(boolean send) {
        if (movementMode == MovementMode.REALISTIC) {
            if (actionAnimRunning) return;
            stopRealisticSimulation();
            simX = arenaView.getRobotX();
            simY = arenaView.getRobotY();
            simHeading = (float) (arenaView.getRobotDir() * (Math.PI / 2.0));
            playRealisticAction('L', () -> {
                if (send && timeTrialActive && !timeTrialPlayback) {
                    onTrialAction();
                }
                if (movementMode == MovementMode.REALISTIC && !pathPlaying && !timeTrialPlayback
                        && moveMode != MoveMode.TAP) {
                    startRealisticSimulation();
                }
            });
            if (send) sendLine("ROTATE,LEFT");
            return;
        }
        arenaView.rotateLeft();
        if (send && timeTrialActive && !timeTrialPlayback) {
            onTrialAction();
        }
        if (send) sendLine("ROTATE,LEFT");
    }

    private void rotateRight(boolean send) {
        if (movementMode == MovementMode.REALISTIC) {
            if (actionAnimRunning) return;
            stopRealisticSimulation();
            simX = arenaView.getRobotX();
            simY = arenaView.getRobotY();
            simHeading = (float) (arenaView.getRobotDir() * (Math.PI / 2.0));
            playRealisticAction('R', () -> {
                if (send && timeTrialActive && !timeTrialPlayback) {
                    onTrialAction();
                }
                if (movementMode == MovementMode.REALISTIC && !pathPlaying && !timeTrialPlayback
                        && moveMode != MoveMode.TAP) {
                    startRealisticSimulation();
                }
            });
            if (send) sendLine("ROTATE,RIGHT");
            return;
        }
        arenaView.rotateRight();
        if (send && timeTrialActive && !timeTrialPlayback) {
            onTrialAction();
        }
        if (send) sendLine("ROTATE,RIGHT");
    }

    private void setMoveMode(MoveMode mode) {
        moveMode = mode;
        moveSequenceActive = false;
        tapMovePlaying = false;
        moveHandler.removeCallbacksAndMessages(null);
        stopJoystickRepeat();
        stopRotateRepeat();
        sectionMoveManual.setVisibility(mode == MoveMode.MANUAL ? View.VISIBLE : View.GONE);
        sectionMoveJoystick.setVisibility(mode == MoveMode.JOYSTICK ? View.VISIBLE : View.GONE);
        txtMoveTiltHint.setVisibility(mode == MoveMode.TILT ? View.VISIBLE : View.GONE);
        txtMoveTapHint.setVisibility(mode == MoveMode.TAP ? View.VISIBLE : View.GONE);

        arenaView.setTapMoveEnabled(mode == MoveMode.TAP);
        if (mode == MoveMode.TILT) {
            startTiltMode();
        } else {
            stopTiltMode();
        }
        if (movementMode == MovementMode.REALISTIC && !simRunning && mode != MoveMode.TAP) {
            startRealisticSimulation();
        }
    }

    private void handleJoystickMove(float normX, float normY, boolean active) {
        if (moveMode != MoveMode.JOYSTICK) return;
        if (movementMode == MovementMode.REALISTIC) {
            if (!active) {
                simThrottle = 0f;
                simSteer = 0f;
                return;
            }
            simThrottle = Math.max(-1f, Math.min(1f, -normY));
            simSteer = Math.max(-1f, Math.min(1f, normX));
            return;
        }
        if (!active) {
            stopJoystickRepeat();
            return;
        }
        float threshold = 0.35f;
        if (Math.abs(normX) < threshold && Math.abs(normY) < threshold) {
            stopJoystickRepeat();
            return;
        }

        int desiredDir;
        if (Math.abs(normY) >= Math.abs(normX)) {
            desiredDir = (normY < 0) ? 0 : 2;
        } else {
            desiredDir = (normX < 0) ? 3 : 1;
        }
        startJoystickRepeat(desiredDir);
    }

    private void moveRobotTo(int targetX, int targetY) {
        if (movementMode == MovementMode.REALISTIC) {
            if (tapMovePlaying) return;
            if (!arenaView.isRobotPlacementValid(targetX, targetY)) return;
            int width = arenaView.getArenaWidth();
            int height = arenaView.getArenaHeight();
            int startState = stateIndex(arenaView.getRobotX(), arenaView.getRobotY(), arenaView.getRobotDir(), width);
            double[] dist = dijkstraDistances(startState, width, height, width * height * 4);
            int bestDir = -1;
            double best = Double.POSITIVE_INFINITY;
            for (int dir = 0; dir < 4; dir++) {
                int s = stateIndex(targetX, targetY, dir, width);
                if (dist[s] < best) {
                    best = dist[s];
                    bestDir = dir;
                }
            }
            if (bestDir < 0 || Double.isInfinite(best)) return;
            List<Character> actions = dijkstraActions(startState,
                    stateIndex(targetX, targetY, bestDir, width),
                    width, height, width * height * 4);
            if (actions == null || actions.isEmpty()) return;
            tapMoveActions = actions;
            tapMoveIndex = 0;
            tapMovePlaying = true;
            stopRealisticSimulation();
            stopActionAnimation();
            simX = arenaView.getRobotX();
            simY = arenaView.getRobotY();
            simHeading = (float) (arenaView.getRobotDir() * (Math.PI / 2.0));
            moveHandler.post(tapMoveRunnable);
            return;
        }
        if (moveSequenceActive) return;
        moveSequenceActive = true;
        moveHandler.post(() -> runMoveSequence(targetX, targetY));
    }

    private final Runnable tapMoveRunnable = new Runnable() {
        @Override
        public void run() {
            if (!tapMovePlaying) return;
            if (tapMoveIndex >= tapMoveActions.size()) {
                tapMovePlaying = false;
                if (movementMode == MovementMode.REALISTIC && moveMode != MoveMode.TAP) {
                    startRealisticSimulation();
                }
                return;
            }
            char action = tapMoveActions.get(tapMoveIndex);
            playRealisticAction(action, () -> {
                tapMoveIndex++;
                if (timeTrialActive && !timeTrialPlayback) {
                    onTrialAction();
                }
                moveHandler.post(tapMoveRunnable);
            });
        }
    };

    private void runMoveSequence(int targetX, int targetY) {
        int x = arenaView.getRobotX();
        int y = arenaView.getRobotY();
        int dir = arenaView.getRobotDir();

        if (x == targetX && y == targetY) {
            moveSequenceActive = false;
            return;
        }

        int stepDx = targetX - x;
        int stepDy = targetY - y;

        if (stepDx != 0) {
            int desiredDir = stepDx > 0 ? 1 : 3;
            dir = rotateTo(desiredDir, dir);
            boolean moved = arenaView.moveForward();
            if (moved) {
                if (timeTrialActive && !timeTrialPlayback) onTrialAction();
                sendLine("MOVE,FORWARD");
            } else {
                moveSequenceActive = false;
                return;
            }
        } else if (stepDy != 0) {
            int desiredDir = stepDy > 0 ? 0 : 2;
            dir = rotateTo(desiredDir, dir);
            boolean moved = arenaView.moveForward();
            if (moved) {
                if (timeTrialActive && !timeTrialPlayback) onTrialAction();
                sendLine("MOVE,FORWARD");
            } else {
                moveSequenceActive = false;
                return;
            }
        }

        moveHandler.postDelayed(() -> runMoveSequence(targetX, targetY), 250);
    }

    private int rotateTo(int desiredDir, int currentDir) {
        int diff = (desiredDir - currentDir + 4) % 4;
        if (diff == 0) return currentDir;
        if (diff == 1) {
            rotateRight(true);
            return (currentDir + 1) % 4;
        } else if (diff == 3) {
            rotateLeft(true);
            return (currentDir + 3) % 4;
        } else {
            rotateRight(true);
            rotateRight(true);
            return (currentDir + 2) % 4;
        }
    }

    private void startTiltMode() {
        if (sensorManager == null) {
            sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            accelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }
        if (sensorManager == null || accelSensor == null) {
            setStatus("Tilt not supported on this device.");
            return;
        }
        if (tiltListener == null) {
            tiltListener = new SensorEventListener() {
                @Override
                public void onSensorChanged(SensorEvent event) {
                    if (moveMode != MoveMode.TILT) return;
                    float ax = event.values[0];
                    float ay = event.values[1];
                    lastAx = ax;
                    lastAy = ay;

                    float dx = ax - tiltBaseX;
                    float dy = ay - tiltBaseY;

                    if (dy < 7f && dy > -7f && dx < 3f && dx > -3f) {
                        stopTiltRepeat();
                        return;
                    }

                    if (movementMode == MovementMode.REALISTIC) {
                        simThrottle = Math.max(-1f, Math.min(1f, -dy / 8f));
                        simSteer = Math.max(-1f, Math.min(1f, dx / 6f));
                        return;
                    }

                    if (Math.abs(dy) >= Math.abs(dx)) {
                        if (dy < -4f) setTiltAction(0);
                        else if (dy > 4f) setTiltAction(2);
                    } else {
                        if (dx > 4f) setTiltAction(3);
                        else if (dx < -4f) setTiltAction(1);
                    }
                }

                @Override
                public void onAccuracyChanged(Sensor sensor, int accuracy) {
                }
            };
        }
        sensorManager.registerListener(tiltListener, accelSensor, SensorManager.SENSOR_DELAY_UI);
    }

    private void stopTiltMode() {
        if (sensorManager != null && tiltListener != null) {
            sensorManager.unregisterListener(tiltListener);
        }
        stopTiltRepeat();
    }

    private void setTiltAction(int action) {
        if (tiltAction == action && tiltActive) return;
        tiltAction = action;
        if (!tiltActive) {
            tiltActive = true;
            moveHandler.post(tiltRunnable);
        }
    }

    private void stopTiltRepeat() {
        tiltActive = false;
        tiltAction = 0;
        moveHandler.removeCallbacks(tiltRunnable);
        if (movementMode == MovementMode.REALISTIC) {
            simThrottle = 0f;
            simSteer = 0f;
        }
    }

    private final Runnable tiltRunnable = new Runnable() {
        @Override
        public void run() {
            if (!tiltActive || moveMode != MoveMode.TILT) return;
            if (movementMode == MovementMode.REALISTIC) return;
            long now = System.currentTimeMillis();
            if (now - lastMoveTime >= MOVE_COOLDOWN_MS) {
                moveTowardDir(tiltAction);
                lastMoveTime = now;
            }
            moveHandler.postDelayed(this, MOVE_COOLDOWN_MS);
        }
    };

    private void calibrateTilt() {
        tiltBaseX = lastAx;
        tiltBaseY = lastAy;
    }

    private void moveTowardDir(int desiredDir) {
        int currentDir = arenaView.getRobotDir();
        rotateTo(desiredDir, currentDir);
        moveForward(true);
    }

    private void resetRobotPosition() {
        if (movementMode == MovementMode.REALISTIC) {
            if (!arenaView.resetRobotToDefault()) {
                setStatus("Cannot reset robot position.");
                return;
            }
            simX = 0f;
            simY = 0f;
            simHeading = 0f;
            simSpeed = 0f;
            simThrottle = 0f;
            simSteer = 0f;
            arenaView.setContinuousPose(simX, simY, simHeading);
            return;
        }
        if (!arenaView.resetRobotToDefault()) {
            setStatus("Cannot reset robot position.");
        }
    }

    private void startTimeTrial() {
        timeTrialActive = true;
        timeTrialPlayback = false;
        trialActionCount = 0;
        trialScanned.clear();
        trialOptimalActions.clear();
        trialOptimalSegments.clear();
        trialIndex = 0;
        trialTotalTargets = collectTargets().size();
        trialStartX = arenaView.getRobotX();
        trialStartY = arenaView.getRobotY();
        trialStartDir = arenaView.getRobotDir();
        arenaView.clearTrail();
        trialTimerRunning = false;
        sectionMoveManual.setVisibility(View.GONE);
        sectionMoveJoystick.setVisibility(View.GONE);
        txtMoveTiltHint.setVisibility(View.GONE);
        txtMoveTapHint.setVisibility(View.GONE);
        if (movementMode == MovementMode.REALISTIC) {
            trialElapsedMs = 0L;
            txtTrialActions.setText("Time: 0.0s");
        } else {
            txtTrialActions.setText("Actions: 0");
        }
        txtTrialScanned.setText("Targets scanned: 0/" + trialTotalTargets);
        txtTrialResult.setText("Result: -");
        btnTrialStart.setVisibility(View.VISIBLE);
        btnTrialPlayOptimal.setVisibility(View.GONE);
    }

    private void resetTimeTrial() {
        pathHandler.removeCallbacksAndMessages(null);
        timeTrialPlayback = false;
        arenaView.setRobotPose(trialStartX, trialStartY, trialStartDir);
        arenaView.clearTrail();
        trialActionCount = 0;
        trialScanned.clear();
        trialOptimalSegments.clear();
        trialTimerRunning = false;
        sectionMoveManual.setVisibility(View.GONE);
        sectionMoveJoystick.setVisibility(View.GONE);
        txtMoveTiltHint.setVisibility(View.GONE);
        txtMoveTapHint.setVisibility(View.GONE);
        if (movementMode == MovementMode.REALISTIC) {
            trialElapsedMs = 0L;
            txtTrialActions.setText("Time: 0.0s");
        } else {
            txtTrialActions.setText("Actions: 0");
        }
        txtTrialScanned.setText("Targets scanned: 0/" + trialTotalTargets);
        txtTrialResult.setText("Result: -");
        btnTrialStart.setVisibility(View.VISIBLE);
        btnTrialPlayOptimal.setVisibility(View.GONE);
        timeTrialActive = true;
        if (movementMode == MovementMode.REALISTIC) {
            simX = trialStartX;
            simY = trialStartY;
            simHeading = (float) (trialStartDir * (Math.PI / 2.0));
            simSpeed = 0f;
            simThrottle = 0f;
            simSteer = 0f;
            arenaView.setContinuousPose(simX, simY, simHeading);
            arenaView.clearTrail();
        }
    }

    private void startTrialTimer() {
        if (!timeTrialActive || trialTimerRunning) return;
        trialTimerRunning = true;
        btnTrialStart.setVisibility(View.GONE);
        setMoveMode(moveMode);
        if (movementMode == MovementMode.REALISTIC) {
            trialStartMs = SystemClock.elapsedRealtime();
            trialElapsedMs = 0L;
            txtTrialActions.setText("Time: 0.0s");
            trialTimerHandler.removeCallbacksAndMessages(null);
            trialTimerHandler.post(trialTimerRunnable);
        } else {
            trialActionCount = 0;
            txtTrialActions.setText("Actions: 0");
        }
        checkTrialScans();
    }

    private void onTrialAction() {
        if (!trialTimerRunning) return;
        if (movementMode == MovementMode.REALISTIC) {
            updateTrialTime();
            return;
        }
        trialActionCount++;
        txtTrialActions.setText("Actions: " + trialActionCount);
        checkTrialScans();
    }

    private void checkTrialScans() {
        if (!timeTrialActive || !trialTimerRunning) return;
        int robotX = arenaView.getRobotX();
        int robotY = arenaView.getRobotY();
        int robotDir = arenaView.getRobotDir();
        int robotSize = arenaView.getRobotSize();

        for (Target t : collectTargets()) {
            String key = t.key();
            if (trialScanned.contains(key)) continue;
            if (isScanningTarget(robotX, robotY, robotDir, robotSize, t)) {
                trialScanned.add(key);
            }
        }
        txtTrialScanned.setText("Targets scanned: " + trialScanned.size() + "/" + trialTotalTargets);
        if (trialScanned.size() == trialTotalTargets && trialTotalTargets > 0) {
            endTimeTrial();
        }
    }

    private void updateTrialTime() {
        if (!timeTrialActive || !trialTimerRunning) return;
        trialElapsedMs = SystemClock.elapsedRealtime() - trialStartMs;
        txtTrialActions.setText(String.format(Locale.US, "Time: %.1fs", trialElapsedMs / 1000.0));
        checkTrialScans();
    }

    private boolean isScanningTarget(int rx, int ry, int rDir, int rSize, Target t) {
        ArenaView.Obstacle o = t.obstacle;
        int ox = o.x;
        int oy = o.y;
        int os = o.size;
        if (t.face == 0) { // North, robot above, facing South
            if (rDir != 2) return false;
            if (ry != oy + os) return false;
            return rangesOverlap(rx, rx + rSize - 1, ox, ox + os - 1);
        } else if (t.face == 2) { // South, robot below, facing North
            if (rDir != 0) return false;
            if (ry != oy - rSize) return false;
            return rangesOverlap(rx, rx + rSize - 1, ox, ox + os - 1);
        } else if (t.face == 1) { // East, robot right, facing West
            if (rDir != 3) return false;
            if (rx != ox + os) return false;
            return rangesOverlap(ry, ry + rSize - 1, oy, oy + os - 1);
        } else { // West, robot left, facing East
            if (rDir != 1) return false;
            if (rx != ox - rSize) return false;
            return rangesOverlap(ry, ry + rSize - 1, oy, oy + os - 1);
        }
    }

    private boolean rangesOverlap(int a0, int a1, int b0, int b1) {
        return a0 <= b1 && b0 <= a1;
    }

    private void endTimeTrial() {
        if (trialScanned.size() != trialTotalTargets || trialTotalTargets == 0) return;
        timeTrialActive = false;
        timeTrialPlayback = false;
        trialTimerRunning = false;
        trialTimerHandler.removeCallbacksAndMessages(null);
        sectionMoveManual.setVisibility(View.GONE);
        sectionMoveJoystick.setVisibility(View.GONE);
        txtMoveTiltHint.setVisibility(View.GONE);
        txtMoveTapHint.setVisibility(View.GONE);
        arenaView.setRobotPose(trialStartX, trialStartY, trialStartDir);
        if (movementMode == MovementMode.REALISTIC) {
            simX = trialStartX;
            simY = trialStartY;
            simHeading = (float) (trialStartDir * (Math.PI / 2.0));
            simSpeed = 0f;
            simThrottle = 0f;
            simSteer = 0f;
            arenaView.setContinuousPose(simX, simY, simHeading);
        }
        arenaView.clearTrail();
        computeShortestPath();
        trialOptimalActions = new ArrayList<>(pathActions);
        trialOptimalSegments.clear();
        double optimalTime = computePathTimeSeconds(trialOptimalActions);

        if (trialOptimalActions.isEmpty()) {
            txtTrialResult.setText("Result: No optimal path found.");
            btnTrialPlayOptimal.setVisibility(View.GONE);
        } else {
            if (movementMode == MovementMode.REALISTIC) {
                txtTrialResult.setText(String.format(Locale.US,
                        "Result: Your %.1fs, optimal %.1fs",
                        trialElapsedMs / 1000.0, optimalTime));
            } else {
                txtTrialResult.setText("Result: Your actions " + trialActionCount + ", optimal " + trialOptimalActions.size());
            }
            btnTrialPlayOptimal.setVisibility(View.VISIBLE);
        }
        btnTrialStart.setVisibility(View.GONE);
    }

    private void playTimeTrialOptimal() {
        if (trialOptimalActions.isEmpty() || timeTrialPlayback) return;
        timeTrialPlayback = true;
        trialIndex = 0;
        btnTrialPlayOptimal.setVisibility(View.GONE);
        if (movementMode == MovementMode.REALISTIC) {
            stopRealisticSimulation();
            stopActionAnimation();
            arenaView.setRobotPose(trialStartX, trialStartY, trialStartDir);
            simX = trialStartX;
            simY = trialStartY;
            simHeading = (float) (trialStartDir * (Math.PI / 2.0));
            simSpeed = 0f;
            simThrottle = 0f;
            simSteer = 0f;
            arenaView.setContinuousPose(simX, simY, simHeading);
        }
        arenaView.clearTrail();
        pathHandler.post(trialPathRunnable);
    }

    private final Runnable trialPathRunnable = new Runnable() {
        @Override
        public void run() {
            if (!timeTrialPlayback) return;
            if (trialIndex >= trialOptimalActions.size()) {
                timeTrialPlayback = false;
                if (movementMode == MovementMode.REALISTIC) {
                    stopActionAnimation();
                }
                double optimalTime = computePathTimeSeconds(trialOptimalActions);
                if (movementMode == MovementMode.REALISTIC) {
                    double playerTime = trialElapsedMs / 1000.0;
                    if (playerTime <= optimalTime) {
                        txtTrialResult.setText(String.format(Locale.US,
                                "Result: Victory! Your %.1fs vs optimal %.1fs", playerTime, optimalTime));
                    } else {
                        txtTrialResult.setText(String.format(Locale.US,
                                "Result: Try again. Your %.1fs vs optimal %.1fs", playerTime, optimalTime));
                    }
                } else {
                    int optimalCost = trialOptimalActions.size();
                    if (trialActionCount <= optimalCost) {
                        txtTrialResult.setText("Result: Victory! Your " + trialActionCount + " vs optimal " + optimalCost);
                    } else {
                        txtTrialResult.setText("Result: Try again. Your " + trialActionCount + " vs optimal " + optimalCost);
                    }
                }
                btnTrialPlayOptimal.setVisibility(View.VISIBLE);
                return;
            }
            char action = trialOptimalActions.get(trialIndex);
            trialIndex++;
            if (movementMode == MovementMode.REALISTIC) {
                playRealisticAction(action, () -> pathHandler.post(trialPathRunnable));
            } else {
                applyAction(action);
                pathHandler.postDelayed(this, 200);
            }
        }
    };

    private void computeShortestPath() {
        pathHandler.removeCallbacksAndMessages(null);
        pathPlaying = false;
        pathActions.clear();
        btnPlayPath.setVisibility(View.GONE);
        btnPlayPath.setText("Play");
        btnPausePath.setVisibility(View.GONE);
        rowPathStepControls.setVisibility(View.GONE);
        btnResetPath.setVisibility(View.GONE);
        txtPathCost.setText("Cost: -");
        txtPathProgress.setText("Steps: -");

        List<Target> targets = collectTargets();
        if (targets.isEmpty()) {
            setStatus("No targets to scan.");
            return;
        }
        if (targets.size() > 12) {
            setStatus("Too many targets for exact shortest path.");
            return;
        }

        int width = arenaView.getArenaWidth();
        int height = arenaView.getArenaHeight();
        int totalStates = width * height * 4;
        int startState = stateIndex(arenaView.getRobotX(), arenaView.getRobotY(), arenaView.getRobotDir(), width);

        List<Integer> approachStates = new ArrayList<>();
        List<List<Integer>> targetToApproach = new ArrayList<>();
        List<List<Integer>> targetToApproachIdx = new ArrayList<>();
        for (Target t : targets) {
            List<Integer> list = buildApproachStates(t, width, height);
            if (list.isEmpty()) {
                setStatus("Target unreachable: " + t.label());
                return;
            }
            targetToApproach.add(list);
            List<Integer> idxList = new ArrayList<>();
            for (int state : list) {
                approachStates.add(state);
                idxList.add(approachStates.size() - 1);
            }
            targetToApproachIdx.add(idxList);
        }

        int m = approachStates.size();
        boolean realistic = movementMode == MovementMode.REALISTIC;
        double[] distStart;
        double[][] distFrom;
        if (realistic) {
            double[] distAll = dijkstraDistances(startState, width, height, totalStates);
            distStart = new double[m];
            for (int i = 0; i < m; i++) {
                distStart[i] = distAll[approachStates.get(i)];
            }
            distFrom = new double[m][m];
            for (int i = 0; i < m; i++) {
                double[] d = dijkstraDistances(approachStates.get(i), width, height, totalStates);
                for (int j = 0; j < m; j++) {
                    distFrom[i][j] = d[approachStates.get(j)];
                }
            }
        } else {
            int[] distAll = bfsDistances(startState, width, height, totalStates);
            distStart = new double[m];
            for (int i = 0; i < m; i++) {
                int d = distAll[approachStates.get(i)];
                distStart[i] = (d >= Integer.MAX_VALUE / 4) ? Double.POSITIVE_INFINITY : d;
            }
            distFrom = new double[m][m];
            for (int i = 0; i < m; i++) {
                int[] d = bfsDistances(approachStates.get(i), width, height, totalStates);
                for (int j = 0; j < m; j++) {
                    int v = d[approachStates.get(j)];
                    distFrom[i][j] = (v >= Integer.MAX_VALUE / 4) ? Double.POSITIVE_INFINITY : v;
                }
            }
        }

        int n = targets.size();
        int fullMask = (1 << n) - 1;
        double[][] dp = new double[1 << n][m];
        int[][] prevState = new int[1 << n][m];
        int[][] prevMask = new int[1 << n][m];
        for (int mask = 0; mask <= fullMask; mask++) {
            Arrays.fill(dp[mask], Double.POSITIVE_INFINITY);
            Arrays.fill(prevState[mask], -1);
            Arrays.fill(prevMask[mask], -1);
        }

        for (int t = 0; t < n; t++) {
            List<Integer> idxList = targetToApproachIdx.get(t);
            for (int sIndex : idxList) {
                double dist = distStart[sIndex];
                if (Double.isInfinite(dist)) continue;
                int mask = 1 << t;
                dp[mask][sIndex] = dist;
            }
        }

        for (int mask = 0; mask <= fullMask; mask++) {
            for (int s = 0; s < m; s++) {
                if (Double.isInfinite(dp[mask][s])) continue;
                for (int t = 0; t < n; t++) {
                    if ((mask & (1 << t)) != 0) continue;
                    List<Integer> idxList = targetToApproachIdx.get(t);
                    for (int s2 : idxList) {
                        double dist = distFrom[s][s2];
                        if (Double.isInfinite(dist)) continue;
                        int newMask = mask | (1 << t);
                        double newCost = dp[mask][s] + dist;
                        if (newCost < dp[newMask][s2]) {
                            dp[newMask][s2] = newCost;
                            prevState[newMask][s2] = s;
                            prevMask[newMask][s2] = mask;
                        }
                    }
                }
            }
        }

        double bestCost = Double.POSITIVE_INFINITY;
        int bestState = -1;
        for (int s = 0; s < m; s++) {
            double cost = dp[fullMask][s];
            if (cost < bestCost) {
                bestCost = cost;
                bestState = s;
            }
        }
        if (bestState == -1) {
            setStatus("No path found.");
            return;
        }

        List<Integer> seq = new ArrayList<>();
        int mask = fullMask;
        int s = bestState;
        while (s != -1) {
            seq.add(s);
            int ps = prevState[mask][s];
            int pm = prevMask[mask][s];
            s = ps;
            mask = pm;
        }
        Collections.reverse(seq);

        List<Character> actions = new ArrayList<>();
        if (!seq.isEmpty()) {
            List<Character> a = realistic
                    ? dijkstraActions(startState, approachStates.get(seq.get(0)), width, height, totalStates)
                    : bfsActions(startState, approachStates.get(seq.get(0)), width, height, totalStates);
            if (a == null) {
                setStatus("Path build failed.");
                return;
            }
            actions.addAll(a);
            for (int i = 0; i < seq.size() - 1; i++) {
                int fromState = approachStates.get(seq.get(i));
                int toState = approachStates.get(seq.get(i + 1));
                List<Character> part = realistic
                        ? dijkstraActions(fromState, toState, width, height, totalStates)
                        : bfsActions(fromState, toState, width, height, totalStates);
                if (part == null || (part.isEmpty() && fromState != toState)) {
                    setStatus("Path build failed.");
                    return;
                }
                actions.addAll(part);
            }
        }

        pathSegments.clear();
        pathActions = actions;
        if (realistic) {
            pathTotalTimeSec = computePathTimeSeconds(actions);
            txtPathCost.setText(String.format(Locale.US, "Time: %.1fs", pathTotalTimeSec));
            pathElapsedTimeSec = 0.0;
            txtPathProgress.setText(String.format(Locale.US, "Time: 0.0/%.1fs", pathTotalTimeSec));
        } else {
            txtPathCost.setText("Cost: " + actions.size() + " actions");
            txtPathProgress.setText("Steps: 0/" + actions.size());
        }
        btnPlayPath.setVisibility(actions.isEmpty() ? View.GONE : View.VISIBLE);
        btnPlayPath.setText("Play");
        btnPausePath.setVisibility(View.GONE);
        rowPathStepControls.setVisibility(View.GONE);
        btnResetPath.setVisibility(View.GONE);

        startPoseX = arenaView.getRobotX();
        startPoseY = arenaView.getRobotY();
        startPoseDir = arenaView.getRobotDir();
    }

    private void playPath() {
        if (pathActions.isEmpty() || pathPlaying) return;
        pathPlaying = true;
        pathIndex = 0;
        btnPlayPath.setVisibility(View.GONE);
        btnPausePath.setVisibility(View.VISIBLE);
        rowPathStepControls.setVisibility(View.GONE);
        btnResetPath.setVisibility(View.GONE);
        if (movementMode == MovementMode.REALISTIC) {
            pathElapsedTimeSec = 0.0;
            txtPathProgress.setText(String.format(Locale.US, "Time: 0.0/%.1fs", pathTotalTimeSec));
        } else {
            txtPathProgress.setText("Steps: 0/" + pathActions.size());
        }
        if (movementMode == MovementMode.REALISTIC) {
            stopRealisticSimulation();
            stopActionAnimation();
            simX = arenaView.getRobotX();
            simY = arenaView.getRobotY();
            simHeading = (float) (arenaView.getRobotDir() * (Math.PI / 2.0));
        }
        pathHandler.post(pathStepRunnable);
    }

    private final Runnable pathStepRunnable = new Runnable() {
        @Override
        public void run() {
            if (!pathPlaying) return;
            if (pathIndex >= pathActions.size()) {
                pathPlaying = false;
                if (movementMode == MovementMode.REALISTIC) {
                    stopActionAnimation();
                }
                btnPausePath.setVisibility(View.GONE);
                btnResetPath.setVisibility(View.VISIBLE);
                rowPathStepControls.setVisibility(View.VISIBLE);
                btnPlayPath.setVisibility(View.VISIBLE);
                btnPlayPath.setText("Play");
                return;
            }
            char action = pathActions.get(pathIndex);
            if (movementMode == MovementMode.REALISTIC) {
                playRealisticAction(action, () -> {
                    pathElapsedTimeSec += actionDurationSeconds(action);
                    pathIndex++;
                    txtPathProgress.setText(String.format(Locale.US, "Time: %.1f/%.1fs",
                            pathElapsedTimeSec, pathTotalTimeSec));
                    pathHandler.post(pathStepRunnable);
                });
            } else {
                applyAction(action);
                pathIndex++;
                txtPathProgress.setText("Steps: " + pathIndex + "/" + pathActions.size());
                pathHandler.postDelayed(this, 200);
            }
        }
    };

    private void pausePath() {
        if (!pathPlaying) return;
        pathPlaying = false;
        pathHandler.removeCallbacksAndMessages(null);
        if (movementMode == MovementMode.REALISTIC) {
            stopActionAnimation();
        }
        btnPausePath.setVisibility(View.GONE);
        btnPlayPath.setVisibility(View.VISIBLE);
        btnPlayPath.setText("Resume");
        rowPathStepControls.setVisibility(View.VISIBLE);
        btnResetPath.setVisibility(View.VISIBLE);
        if (movementMode == MovementMode.REALISTIC) {
            txtPathProgress.setText(String.format(Locale.US, "Time: %.1f/%.1fs",
                    pathElapsedTimeSec, pathTotalTimeSec));
        } else {
            txtPathProgress.setText("Steps: " + pathIndex + "/" + pathActions.size());
        }
    }

    private void resetPathPlayback() {
        pathHandler.removeCallbacksAndMessages(null);
        pathPlaying = false;
        if (movementMode == MovementMode.REALISTIC) {
            stopActionAnimation();
        }
        arenaView.setRobotPose(startPoseX, startPoseY, startPoseDir);
        if (movementMode == MovementMode.REALISTIC) {
            simX = startPoseX;
            simY = startPoseY;
            simHeading = (float) (startPoseDir * (Math.PI / 2.0));
            simSpeed = 0f;
            simThrottle = 0f;
            simSteer = 0f;
            arenaView.setContinuousPose(simX, simY, simHeading);
        }
        arenaView.clearTrail();
        if (movementMode == MovementMode.REALISTIC) {
            pathElapsedTimeSec = 0.0;
            txtPathProgress.setText(String.format(Locale.US, "Time: 0.0/%.1fs", pathTotalTimeSec));
        } else {
            txtPathProgress.setText("Steps: 0/" + pathActions.size());
        }
        btnPlayPath.setVisibility(pathActions.isEmpty() ? View.GONE : View.VISIBLE);
        btnPlayPath.setText("Play");
        btnPausePath.setVisibility(View.GONE);
        rowPathStepControls.setVisibility(View.GONE);
        btnResetPath.setVisibility(View.GONE);
        pathIndex = 0;
    }

    private void nextPathStep() {
        if (pathPlaying) return;
        if (pathActions.isEmpty()) return;
        if (pathIndex >= pathActions.size()) return;
        char action = pathActions.get(pathIndex);
        if (movementMode == MovementMode.REALISTIC) {
            // handled above
        } else {
            applyAction(action);
            pathIndex++;
            txtPathProgress.setText("Steps: " + pathIndex + "/" + pathActions.size());
        }
    }

    private void prevPathStep() {
        if (pathPlaying) return;
        if (pathActions.isEmpty()) return;
        if (pathIndex <= 0) return;
        pathIndex--;
        char action = inverseAction(pathActions.get(pathIndex));
        applyAction(action);
        txtPathProgress.setText("Steps: " + pathIndex + "/" + pathActions.size());
    }

    private void applyAction(char action) {
        switch (action) {
            case 'F':
                arenaView.moveForward();
                break;
            case 'B':
                arenaView.moveBackward();
                break;
            case 'L':
                arenaView.rotateLeft();
                break;
            case 'R':
                arenaView.rotateRight();
                break;
            default:
                break;
        }
    }

    private char inverseAction(char action) {
        switch (action) {
            case 'F':
                return 'B';
            case 'B':
                return 'F';
            case 'L':
                return 'R';
            case 'R':
                return 'L';
            default:
                return action;
        }
    }

    private double computePathTimeSeconds(List<Character> actions) {
        if (actions == null || actions.isEmpty()) return 0.0;
        if (movementMode == MovementMode.SIMPLIFIED) {
            return actions.size();
        }
        double total = 0.0;
        for (char a : actions) {
            total += actionDurationSeconds(a);
        }
        return total;
    }

    private double actionDurationSeconds(char action) {
        if (movementMode == MovementMode.SIMPLIFIED) return 1.0;
        double speed = Math.max(simMaxSpeed * 0.7f, 0.1f);
        double accelPenalty = 1.0 / Math.max(simAccel, 0.1f);
        double radiusCells = 1.0;
        // Realistic actions are timed by travel distance + accel penalty.
        if (action == 'F' || action == 'B') {
            return (1.0 / speed) + accelPenalty;
        }
        double arcLen = (Math.PI / 2.0) * radiusCells;
        return (arcLen / speed) + accelPenalty * 1.5;
    }

    private double computeSegmentTimeSeconds(List<PathSegment> segments) {
        if (segments == null || segments.isEmpty()) return 0.0;
        double speed = Math.max(simMaxSpeed * 0.7f, 0.1f);
        double R = rsTurnRadius();
        double total = 0.0;
        for (PathSegment seg : segments) {
            double dist;
            if (seg.type == 'S') {
                dist = Math.abs(seg.length);
            } else {
                dist = Math.abs(seg.length) * R;
            }
            total += dist / speed;
        }
        return total;
    }

    private double segmentDurationSeconds(PathSegment seg) {
        double speed = Math.max(simMaxSpeed * 0.7f, 0.1f);
        double R = rsTurnRadius();
        double dist = seg.type == 'S' ? Math.abs(seg.length) : Math.abs(seg.length) * R;
        return dist / speed;
    }

    private PathSegment inverseSegment(PathSegment seg) {
        return new PathSegment(seg.type, -seg.length);
    }

    private void playRealisticSegment(PathSegment seg, Runnable onDone) {
        double speed = Math.max(simMaxSpeed * 0.7f, 0.1f);
        double R = rsTurnRadius();
        float startX = simX;
        float startY = simY;
        float startHeading = simHeading;
        float targetX = startX;
        float targetY = startY;
        float targetHeading = startHeading;
        actionArc = false;

        if (seg.type == 'S') {
            double dist = seg.length;
            targetX = (float) (startX + dist * Math.sin(startHeading));
            targetY = (float) (startY + dist * Math.cos(startHeading));
        } else {
            double angle = seg.length;
            int turnDir = (seg.type == 'R') ? 1 : -1;
            if (angle < 0) {
                angle = -angle;
                turnDir *= -1;
            }
            targetHeading = (float) (startHeading + turnDir * angle);
            actionArc = true;
            float leftNx = (float) -Math.cos(startHeading);
            float leftNy = (float) Math.sin(startHeading);
            float rightNx = (float) Math.cos(startHeading);
            float rightNy = (float) -Math.sin(startHeading);
            float cx;
            float cy;
            if (turnDir > 0) {
                cx = startX + rightNx * (float) R;
                cy = startY + rightNy * (float) R;
            } else {
                cx = startX + leftNx * (float) R;
                cy = startY + leftNy * (float) R;
            }
            actionArcCx = cx;
            actionArcCy = cy;
            actionArcStartAng = (float) Math.atan2(startY - cy, startX - cx);
            actionArcEndAng = (float) (actionArcStartAng - turnDir * angle);
            targetX = (float) (cx + Math.cos(actionArcEndAng) * R);
            targetY = (float) (cy + Math.sin(actionArcEndAng) * R);
        }

        double distance = seg.type == 'S' ? Math.abs(seg.length) : Math.abs(seg.length) * R;
        actionStartMs = SystemClock.elapsedRealtime();
        actionDurationMs = Math.max(100L, Math.round((distance / speed) * 1000.0));
        actionStartX = startX;
        actionStartY = startY;
        actionStartHeading = startHeading;
        actionTargetX = targetX;
        actionTargetY = targetY;
        actionTargetHeading = targetHeading;
        actionOnDone = onDone;
        actionAnimRunning = true;
        pathHandler.removeCallbacks(actionAnimRunnable);
        pathHandler.post(actionAnimRunnable);
    }

    private void playRealisticAction(char action, Runnable onDone) {
        double duration = actionDurationSeconds(action);
        int curX = arenaView.getRobotX();
        int curY = arenaView.getRobotY();
        int curDir = arenaView.getRobotDir();
        if (action == 'F' || action == 'B') {
            int[] delta = dirToDelta(curDir);
            int dx = delta[0] * (action == 'F' ? 1 : -1);
            int dy = delta[1] * (action == 'F' ? 1 : -1);
            int targetX = curX + dx;
            int targetY = curY + dy;
            if (!arenaView.isRobotPlacementValid(targetX, targetY)) {
                if (onDone != null) onDone.run();
                return;
            }
        } else if (action == 'L' || action == 'R') {
            if (!isDiagonalTurnClear(curX, curY, curDir, action == 'L')) {
                if (onDone != null) onDone.run();
                return;
            }
        }
        // Snap to grid/cardinal before discrete realistic action playback.
        float startX = Math.round(simX);
        float startY = Math.round(simY);
        float startHeading = (float) (Math.round(simHeading / (Math.PI / 2.0)) * (Math.PI / 2.0));
        simX = startX;
        simY = startY;
        simHeading = startHeading;
        float targetX = startX;
        float targetY = startY;
        float targetHeading = startHeading;
        actionArc = false;
        if (action == 'F' || action == 'B') {
            int[] delta = dirToDelta(curDir);
            int dx = delta[0] * (action == 'F' ? 1 : -1);
            int dy = delta[1] * (action == 'F' ? 1 : -1);
            targetX = startX + dx;
            targetY = startY + dy;
        } else if (action == 'L') {
            int[] delta = dirToDelta(curDir);
            int dx = delta[0];
            int dy = delta[1];
            int nx = -dy;
            int ny = dx;
            targetX = startX + dx + nx;
            targetY = startY + dy + ny;
            targetHeading = startHeading - (float) (Math.PI / 2.0);
            // Quarter-circle to diagonal cell (no in-place turns).
            actionArc = true;
            actionArcCx = startX + nx;
            actionArcCy = startY + ny;
            actionArcStartAng = (float) Math.atan2(startY - actionArcCy, startX - actionArcCx);
            actionArcEndAng = (float) Math.atan2(targetY - actionArcCy, targetX - actionArcCx);
            if (actionArcEndAng <= actionArcStartAng) {
                actionArcEndAng += (float) (Math.PI * 2.0);
            }
        } else if (action == 'R') {
            int[] delta = dirToDelta(curDir);
            int dx = delta[0];
            int dy = delta[1];
            int nx = dy;
            int ny = -dx;
            targetX = startX + dx + nx;
            targetY = startY + dy + ny;
            targetHeading = startHeading + (float) (Math.PI / 2.0);
            // Quarter-circle to diagonal cell (no in-place turns).
            actionArc = true;
            actionArcCx = startX + nx;
            actionArcCy = startY + ny;
            actionArcStartAng = (float) Math.atan2(startY - actionArcCy, startX - actionArcCx);
            actionArcEndAng = (float) Math.atan2(targetY - actionArcCy, targetX - actionArcCx);
            if (actionArcEndAng >= actionArcStartAng) {
                actionArcEndAng -= (float) (Math.PI * 2.0);
            }
        }

        actionStartMs = SystemClock.elapsedRealtime();
        actionDurationMs = Math.max(100L, Math.round(duration * 1000.0));
        actionStartX = startX;
        actionStartY = startY;
        actionStartHeading = startHeading;
        actionTargetX = targetX;
        actionTargetY = targetY;
        actionTargetHeading = targetHeading;
        actionOnDone = onDone;
        actionAnimRunning = true;
        pathHandler.removeCallbacks(actionAnimRunnable);
        pathHandler.post(actionAnimRunnable);
    }

    private List<Target> collectTargets() {
        List<Target> targets = new ArrayList<>();
        for (ArenaView.Obstacle o : arenaView.getObstaclesSnapshot()) {
            if (o.targetNorth) targets.add(new Target(o, 0));
            if (o.targetEast) targets.add(new Target(o, 1));
            if (o.targetSouth) targets.add(new Target(o, 2));
            if (o.targetWest) targets.add(new Target(o, 3));
        }
        return targets;
    }

    private List<Integer> buildApproachStates(Target t, int width, int height) {
        List<Integer> states = new ArrayList<>();
        int r = arenaView.getRobotSize();
        int xStart;
        int yStart;
        int xEnd;
        int yEnd;
        int dir;

        if (t.face == 0) { // North, robot above facing South
            yStart = t.obstacle.y + t.obstacle.size;
            xStart = t.obstacle.x - (r - 1);
            xEnd = t.obstacle.x + t.obstacle.size - 1;
            dir = 2;
            for (int x = xStart; x <= xEnd; x++) {
                if (arenaView.isRobotPlacementValid(x, yStart)) {
                    states.add(stateIndex(x, yStart, dir, width));
                }
            }
        } else if (t.face == 2) { // South, robot below facing North
            yStart = t.obstacle.y - r;
            xStart = t.obstacle.x - (r - 1);
            xEnd = t.obstacle.x + t.obstacle.size - 1;
            dir = 0;
            for (int x = xStart; x <= xEnd; x++) {
                if (arenaView.isRobotPlacementValid(x, yStart)) {
                    states.add(stateIndex(x, yStart, dir, width));
                }
            }
        } else if (t.face == 1) { // East, robot right facing West
            xStart = t.obstacle.x + t.obstacle.size;
            yStart = t.obstacle.y - (r - 1);
            yEnd = t.obstacle.y + t.obstacle.size - 1;
            dir = 3;
            for (int y = yStart; y <= yEnd; y++) {
                if (arenaView.isRobotPlacementValid(xStart, y)) {
                    states.add(stateIndex(xStart, y, dir, width));
                }
            }
        } else { // West, robot left facing East
            xStart = t.obstacle.x - r;
            yStart = t.obstacle.y - (r - 1);
            yEnd = t.obstacle.y + t.obstacle.size - 1;
            dir = 1;
            for (int y = yStart; y <= yEnd; y++) {
                if (arenaView.isRobotPlacementValid(xStart, y)) {
                    states.add(stateIndex(xStart, y, dir, width));
                }
            }
        }
        return states;
    }

    private int[] bfsDistances(int startState, int width, int height, int totalStates) {
        int[] dist = new int[totalStates];
        Arrays.fill(dist, Integer.MAX_VALUE / 4);
        ArrayDeque<Integer> q = new ArrayDeque<>();
        dist[startState] = 0;
        q.add(startState);
        while (!q.isEmpty()) {
            int s = q.poll();
            int d = dist[s];
            int[] decoded = decodeState(s, width);
            int x = decoded[0];
            int y = decoded[1];
            int dir = decoded[2];

            int left = stateIndex(x, y, (dir + 3) % 4, width);
            if (dist[left] > d + 1) {
                dist[left] = d + 1;
                q.add(left);
            }
            int right = stateIndex(x, y, (dir + 1) % 4, width);
            if (dist[right] > d + 1) {
                dist[right] = d + 1;
                q.add(right);
            }
            int[] delta = dirToDelta(dir);
            int nx = x + delta[0];
            int ny = y + delta[1];
            if (arenaView.isRobotPlacementValid(nx, ny)) {
                int forward = stateIndex(nx, ny, dir, width);
                if (dist[forward] > d + 1) {
                    dist[forward] = d + 1;
                    q.add(forward);
                }
            }
            int bx = x - delta[0];
            int by = y - delta[1];
            if (arenaView.isRobotPlacementValid(bx, by)) {
                int back = stateIndex(bx, by, dir, width);
                if (dist[back] > d + 1) {
                    dist[back] = d + 1;
                    q.add(back);
                }
            }
        }
        return dist;
    }

    private List<Character> bfsActions(int startState, int goalState, int width, int height, int totalStates) {
        int[] dist = new int[totalStates];
        int[] prev = new int[totalStates];
        char[] prevAction = new char[totalStates];
        Arrays.fill(dist, Integer.MAX_VALUE / 4);
        Arrays.fill(prev, -1);
        ArrayDeque<Integer> q = new ArrayDeque<>();
        dist[startState] = 0;
        q.add(startState);
        while (!q.isEmpty()) {
            int s = q.poll();
            if (s == goalState) break;
            int d = dist[s];
            int[] decoded = decodeState(s, width);
            int x = decoded[0];
            int y = decoded[1];
            int dir = decoded[2];

            int left = stateIndex(x, y, (dir + 3) % 4, width);
            if (dist[left] > d + 1) {
                dist[left] = d + 1;
                prev[left] = s;
                prevAction[left] = 'L';
                q.add(left);
            }
            int right = stateIndex(x, y, (dir + 1) % 4, width);
            if (dist[right] > d + 1) {
                dist[right] = d + 1;
                prev[right] = s;
                prevAction[right] = 'R';
                q.add(right);
            }
            int[] delta = dirToDelta(dir);
            int nx = x + delta[0];
            int ny = y + delta[1];
            if (arenaView.isRobotPlacementValid(nx, ny)) {
                int forward = stateIndex(nx, ny, dir, width);
                if (dist[forward] > d + 1) {
                    dist[forward] = d + 1;
                    prev[forward] = s;
                    prevAction[forward] = 'F';
                    q.add(forward);
                }
            }
            int bx = x - delta[0];
            int by = y - delta[1];
            if (arenaView.isRobotPlacementValid(bx, by)) {
                int back = stateIndex(bx, by, dir, width);
                if (dist[back] > d + 1) {
                    dist[back] = d + 1;
                    prev[back] = s;
                    prevAction[back] = 'B';
                    q.add(back);
                }
            }
        }
        if (dist[goalState] >= Integer.MAX_VALUE / 4) return null;
        List<Character> actions = new ArrayList<>();
        int cur = goalState;
        while (cur != startState) {
            char a = prevAction[cur];
            actions.add(0, a);
            cur = prev[cur];
        }
        return actions;
    }

    private double[] dijkstraDistances(int startState, int width, int height, int totalStates) {
        double[] dist = new double[totalStates];
        Arrays.fill(dist, Double.POSITIVE_INFINITY);
        boolean[] visited = new boolean[totalStates];
        java.util.PriorityQueue<long[]> pq = new java.util.PriorityQueue<>(
                (a, b) -> Double.compare(Double.longBitsToDouble(a[0]), Double.longBitsToDouble(b[0]))
        );
        dist[startState] = 0.0;
        pq.add(new long[]{Double.doubleToLongBits(0.0), startState});
        while (!pq.isEmpty()) {
            long[] item = pq.poll();
            double d = Double.longBitsToDouble(item[0]);
            int s = (int) item[1];
            if (visited[s]) continue;
            visited[s] = true;
            if (d > dist[s]) continue;

            int[] decoded = decodeState(s, width);
            int x = decoded[0];
            int y = decoded[1];
            int dir = decoded[2];

            // Diagonal L/R transitions model realistic turning radius (no in-place turns).
            if (isDiagonalTurnClear(x, y, dir, true)) {
                int[] ldelta = turnDelta(dir, true);
                int lx = x + ldelta[0];
                int ly = y + ldelta[1];
                relaxEdge(dist, pq, s, stateIndex(lx, ly, (dir + 3) % 4, width), actionDurationSeconds('L'));
            }
            if (isDiagonalTurnClear(x, y, dir, false)) {
                int[] rdelta = turnDelta(dir, false);
                int rx = x + rdelta[0];
                int ry = y + rdelta[1];
                relaxEdge(dist, pq, s, stateIndex(rx, ry, (dir + 1) % 4, width), actionDurationSeconds('R'));
            }

            int[] delta = dirToDelta(dir);
            int nx = x + delta[0];
            int ny = y + delta[1];
            if (arenaView.isRobotPlacementValid(nx, ny)) {
                relaxEdge(dist, pq, s, stateIndex(nx, ny, dir, width), actionDurationSeconds('F'));
            }
            int bx = x - delta[0];
            int by = y - delta[1];
            if (arenaView.isRobotPlacementValid(bx, by)) {
                relaxEdge(dist, pq, s, stateIndex(bx, by, dir, width), actionDurationSeconds('B'));
            }
        }
        return dist;
    }

    private List<Character> dijkstraActions(int startState, int goalState, int width, int height, int totalStates) {
        double[] dist = new double[totalStates];
        int[] prev = new int[totalStates];
        char[] prevAction = new char[totalStates];
        Arrays.fill(dist, Double.POSITIVE_INFINITY);
        Arrays.fill(prev, -1);

        java.util.PriorityQueue<long[]> pq = new java.util.PriorityQueue<>(
                (a, b) -> Double.compare(Double.longBitsToDouble(a[0]), Double.longBitsToDouble(b[0]))
        );
        dist[startState] = 0.0;
        pq.add(new long[]{Double.doubleToLongBits(0.0), startState});

        while (!pq.isEmpty()) {
            long[] item = pq.poll();
            double d = Double.longBitsToDouble(item[0]);
            int s = (int) item[1];
            if (d > dist[s]) continue;
            if (s == goalState) break;

            int[] decoded = decodeState(s, width);
            int x = decoded[0];
            int y = decoded[1];
            int dir = decoded[2];

            // Diagonal L/R transitions model realistic turning radius (no in-place turns).
            if (isDiagonalTurnClear(x, y, dir, true)) {
                int[] ldelta2 = turnDelta(dir, true);
                int lx2 = x + ldelta2[0];
                int ly2 = y + ldelta2[1];
                relaxEdgeWithPrev(dist, prev, prevAction, pq, s,
                        stateIndex(lx2, ly2, (dir + 3) % 4, width), 'L');
            }
            if (isDiagonalTurnClear(x, y, dir, false)) {
                int[] rdelta2 = turnDelta(dir, false);
                int rx2 = x + rdelta2[0];
                int ry2 = y + rdelta2[1];
                relaxEdgeWithPrev(dist, prev, prevAction, pq, s,
                        stateIndex(rx2, ry2, (dir + 1) % 4, width), 'R');
            }

            int[] delta = dirToDelta(dir);
            int nx = x + delta[0];
            int ny = y + delta[1];
            if (arenaView.isRobotPlacementValid(nx, ny)) {
                relaxEdgeWithPrev(dist, prev, prevAction, pq, s, stateIndex(nx, ny, dir, width), 'F');
            }
            int bx = x - delta[0];
            int by = y - delta[1];
            if (arenaView.isRobotPlacementValid(bx, by)) {
                relaxEdgeWithPrev(dist, prev, prevAction, pq, s, stateIndex(bx, by, dir, width), 'B');
            }
        }

        if (Double.isInfinite(dist[goalState])) return new ArrayList<>();
        ArrayList<Character> actions = new ArrayList<>();
        int cur = goalState;
        while (cur != startState && cur != -1) {
            char a = prevAction[cur];
            actions.add(0, a);
            cur = prev[cur];
        }
        return actions;
    }

    private void relaxEdge(double[] dist, java.util.PriorityQueue<long[]> pq, int from, int to, double weight) {
        double nd = dist[from] + weight;
        if (nd < dist[to]) {
            dist[to] = nd;
            pq.add(new long[]{Double.doubleToLongBits(nd), to});
        }
    }

    private void relaxEdgeWithPrev(double[] dist, int[] prev, char[] prevAction,
                                   java.util.PriorityQueue<long[]> pq, int from, int to, char action) {
        double nd = dist[from] + actionDurationSeconds(action);
        if (nd < dist[to]) {
            dist[to] = nd;
            prev[to] = from;
            prevAction[to] = action;
            pq.add(new long[]{Double.doubleToLongBits(nd), to});
        }
    }

    private double[] toDoubleArray(int[] ints) {
        double[] out = new double[ints.length];
        for (int i = 0; i < ints.length; i++) {
            out[i] = ints[i] >= Integer.MAX_VALUE / 4 ? Double.POSITIVE_INFINITY : ints[i];
        }
        return out;
    }

    private int[] dirToDelta(int dir) {
        switch (dir) {
            case 0:
                return new int[]{0, 1};
            case 1:
                return new int[]{1, 0};
            case 2:
                return new int[]{0, -1};
            case 3:
            default:
                return new int[]{-1, 0};
        }
    }

    private int stateIndex(int x, int y, int dir, int width) {
        return ((y * width + x) * 4) + dir;
    }

    private int[] decodeState(int state, int width) {
        int cell = state / 4;
        int dir = state % 4;
        int x = cell % width;
        int y = cell / width;
        return new int[]{x, y, dir};
    }

    private int[] turnDelta(int dir, boolean left) {
        // Diagonal landing cell after a quarter-turn (no in-place turn).
        int[] delta = dirToDelta(dir);
        int dx = delta[0];
        int dy = delta[1];
        if (left) {
            return new int[]{dx - dy, dy + dx};
        }
        return new int[]{dx + dy, dy - dx};
    }

    private boolean isDiagonalTurnClear(int x, int y, int dir, boolean left) {
        // Prevent corner-cutting: diagonal target plus both adjacent orthogonals must be clear.
        int[] delta = dirToDelta(dir);
        int dx = delta[0];
        int dy = delta[1];
        int nx = left ? -dy : dy;
        int ny = left ? dx : -dx;
        int targetX = x + dx + nx;
        int targetY = y + dy + ny;
        if (!arenaView.isRobotPlacementValid(targetX, targetY)) return false;
        if (!arenaView.isRobotPlacementValid(x + dx, y + dy)) return false;
        if (!arenaView.isRobotPlacementValid(x + nx, y + ny)) return false;
        return true;
    }

    private static class Pose {
        final double x;
        final double y;
        final double theta;
        Pose(double x, double y, double theta) {
            this.x = x;
            this.y = y;
            this.theta = theta;
        }
    }

    private static class PathSegment {
        final char type;
        final double length; // L/R: angle (rad), S: distance
        PathSegment(char type, double length) {
            this.type = type;
            this.length = length;
        }
    }

    private static class PathData {
        final double length;
        final List<PathSegment> segments;
        PathData(double length, List<PathSegment> segments) {
            this.length = length;
            this.segments = segments;
        }
    }

    private Pose poseFromState(int state, int width) {
        int[] decoded = decodeState(state, width);
        int x = decoded[0];
        int y = decoded[1];
        int dir = decoded[2];
        double cx = x + arenaView.getRobotSize() / 2.0;
        double cy = y + arenaView.getRobotSize() / 2.0;
        double theta = dir * (Math.PI / 2.0);
        return new Pose(cx, cy, theta);
    }

    private PathData reedsSheppPath(Pose start, Pose goal) {
        double R = rsTurnRadius();
        if (R <= 0.01) return null;
        double dx = (goal.x - start.x) / R;
        double dy = (goal.y - start.y) / R;
        double c = Math.cos(start.theta);
        double s = Math.sin(start.theta);
        double x = c * dx + s * dy;
        double y = -s * dx + c * dy;
        double phi = mod2pi(goal.theta - start.theta);

        PathData best = null;
        for (int tf = 0; tf < 2; tf++) {
            double phi1 = tf == 0 ? phi : -phi;
            double x1 = x;
            double y1 = y;
            for (int rf = 0; rf < 2; rf++) {
                double x2 = x1;
                double y2 = rf == 0 ? y1 : -y1;
                double phi2 = rf == 0 ? phi1 : -phi1;

                best = pickBest(best, buildPath("LSL", x2, y2, phi2, tf == 1, rf == 1, R));
                best = pickBest(best, buildPath("RSR", x2, y2, phi2, tf == 1, rf == 1, R));
                best = pickBest(best, buildPath("LSR", x2, y2, phi2, tf == 1, rf == 1, R));
                best = pickBest(best, buildPath("RSL", x2, y2, phi2, tf == 1, rf == 1, R));
                best = pickBest(best, buildPath("RLR", x2, y2, phi2, tf == 1, rf == 1, R));
                best = pickBest(best, buildPath("LRL", x2, y2, phi2, tf == 1, rf == 1, R));
            }
        }
        return best;
    }

    private PathData pickBest(PathData a, PathData b) {
        if (b == null) return a;
        if (a == null) return b;
        return b.length < a.length ? b : a;
    }

    private PathData buildPath(String type, double x, double y, double phi, boolean timeflip, boolean reflect, double R) {
        double[] params = rsParams(type, x, y, phi);
        if (params == null) return null;
        double t = params[0];
        double u = params[1];
        double v = params[2];
        if (timeflip) {
            t = -t;
            u = -u;
            v = -v;
        }
        char[] chars = type.toCharArray();
        if (reflect) {
            for (int i = 0; i < chars.length; i++) {
                chars[i] = (chars[i] == 'L') ? 'R' : (chars[i] == 'R') ? 'L' : 'S';
            }
        }
        ArrayList<PathSegment> segs = new ArrayList<>();
        segs.add(new PathSegment(chars[0], chars[0] == 'S' ? t * R : t));
        segs.add(new PathSegment(chars[1], chars[1] == 'S' ? u * R : u));
        segs.add(new PathSegment(chars[2], chars[2] == 'S' ? v * R : v));

        double length = (Math.abs(t) + Math.abs(u) + Math.abs(v)) * R;
        return new PathData(length, segs);
    }

    private double[] rsParams(String type, double x, double y, double phi) {
        switch (type) {
            case "LSL":
                return rsLSL(x, y, phi);
            case "RSR":
                return rsRSR(x, y, phi);
            case "LSR":
                return rsLSR(x, y, phi);
            case "RSL":
                return rsRSL(x, y, phi);
            case "RLR":
                return rsRLR(x, y, phi);
            case "LRL":
                return rsLRL(x, y, phi);
            default:
                return null;
        }
    }

    private double[] rsLSL(double x, double y, double phi) {
        double xi = x - Math.sin(phi);
        double eta = y - 1 + Math.cos(phi);
        double u = Math.hypot(xi, eta);
        double t = mod2pi(Math.atan2(eta, xi));
        double v = mod2pi(phi - t);
        return new double[]{t, u, v};
    }

    private double[] rsRSR(double x, double y, double phi) {
        double xi = x + Math.sin(phi);
        double eta = y - 1 - Math.cos(phi);
        double u = Math.hypot(xi, eta);
        double t = mod2pi(Math.atan2(eta, xi));
        double v = mod2pi(-phi - t);
        return new double[]{t, u, v};
    }

    private double[] rsLSR(double x, double y, double phi) {
        double xi = x - Math.sin(phi);
        double eta = y + 1 - Math.cos(phi);
        double u2 = xi * xi + eta * eta - 4;
        if (u2 < 0) return null;
        double u = Math.sqrt(u2);
        double t = mod2pi(Math.atan2(eta, xi) - Math.atan2(2, u));
        double v = mod2pi(t - phi);
        return new double[]{t, u, v};
    }

    private double[] rsRSL(double x, double y, double phi) {
        double xi = x + Math.sin(phi);
        double eta = y + 1 + Math.cos(phi);
        double u2 = xi * xi + eta * eta - 4;
        if (u2 < 0) return null;
        double u = Math.sqrt(u2);
        double t = mod2pi(Math.atan2(eta, xi) + Math.atan2(2, u));
        double v = mod2pi(-phi - t);
        return new double[]{t, u, v};
    }

    private double[] rsRLR(double x, double y, double phi) {
        double xi = x - Math.sin(phi);
        double eta = y - 1 + Math.cos(phi);
        double rho = 0.25 * (xi * xi + eta * eta);
        if (rho > 1) return null;
        double u = Math.acos(rho);
        double t = mod2pi(Math.atan2(eta, xi) + Math.atan2(1, u));
        double v = mod2pi(t - phi + u);
        return new double[]{t, u, v};
    }

    private double[] rsLRL(double x, double y, double phi) {
        double xi = x + Math.sin(phi);
        double eta = y - 1 - Math.cos(phi);
        double rho = 0.25 * (xi * xi + eta * eta);
        if (rho > 1) return null;
        double u = Math.acos(rho);
        double t = mod2pi(Math.atan2(eta, xi) + Math.atan2(1, u));
        double v = mod2pi(phi - t + u);
        return new double[]{t, u, v};
    }

    private double mod2pi(double ang) {
        double a = ang % (2 * Math.PI);
        if (a < 0) a += 2 * Math.PI;
        return a;
    }

    private static class Target {
        final ArenaView.Obstacle obstacle;
        final int face;

        Target(ArenaView.Obstacle obstacle, int face) {
            this.obstacle = obstacle;
            this.face = face;
        }

        String label() {
            String faceLabel = (face == 0) ? "N" : (face == 1) ? "E" : (face == 2) ? "S" : "W";
            return obstacle.number + faceLabel;
        }

        String key() {
            return label();
        }
    }

    private void startJoystickRepeat(int desiredDir) {
        joystickAction = desiredDir;
        if (joystickActive) return;
        joystickActive = true;
        moveHandler.post(joystickRunnable);
    }

    private void stopJoystickRepeat() {
        joystickActive = false;
        joystickAction = 0;
        moveHandler.removeCallbacks(joystickRunnable);
    }

    private final Runnable joystickRunnable = new Runnable() {
        @Override
        public void run() {
            if (!joystickActive || moveMode != MoveMode.JOYSTICK) return;
            long now = System.currentTimeMillis();
            if (now - lastMoveTime >= MOVE_COOLDOWN_MS) {
                moveTowardDir(joystickAction);
                lastMoveTime = now;
            }
            moveHandler.postDelayed(this, MOVE_COOLDOWN_MS);
        }
    };

    private String normalizeCommand(String line) {
        String cleaned = line.trim();
        int space = cleaned.indexOf(' ');
        if (space > 0) cleaned = cleaned.substring(0, space);
        cleaned = cleaned.replace('\t', ' ');
        cleaned = cleaned.replaceAll("\\s+", "");
        return cleaned.toUpperCase();
    }

    private String parseStatusLine(String line) {
        String[] prefixes = {
                "MSG,",
                "status=",
                "STATUS,",
                "STATUS:",
                "ROBOTSTATUS,",
                "ROBOT_STATUS,",
                "Robot Status:"
        };

        for (String prefix : prefixes) {
            if (line.startsWith(prefix)) {
                String msg = line.substring(prefix.length()).trim();
                if (msg.startsWith("[") && msg.endsWith("]") && msg.length() > 1) {
                    msg = msg.substring(1, msg.length() - 1).trim();
                }
                return msg.isEmpty() ? null : msg;
            }
        }
        return null;
    }

    private void appendLog(String s) {
        txtLog.append(s + "\n");
    }

    private void closeClientSocket() {
        try {
            if (socket != null) socket.close();
        } catch (Exception ignored) {}
        socket = null;
    }

    private void closeServerSocket() {
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (Exception ignored) {}
        serverSocket = null;
    }

    private int indexOfLineBreak(StringBuilder sb) {
        for (int i = 0; i < sb.length(); i++) {
            char c = sb.charAt(i);
            if (c == '\n' || c == '\r') return i;
        }
        return -1;
    }

    private String extractLine(StringBuilder sb, int breakIndex) {
        String line = sb.substring(0, breakIndex).trim();
        int deleteUpto = breakIndex + 1;
        while (deleteUpto < sb.length()) {
            char c = sb.charAt(deleteUpto);
            if (c != '\n' && c != '\r') break;
            deleteUpto++;
        }
        sb.delete(0, deleteUpto);
        return line;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        shouldAccept = false;
        stopTiltMode();
        disconnect();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopTiltMode();
        stopJoystickRepeat();
        pathHandler.removeCallbacksAndMessages(null);
        pathPlaying = false;
    }
}
