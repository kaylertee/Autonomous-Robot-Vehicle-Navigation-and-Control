package com.example.mdpremotecontroller;

import android.Manifest;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.DragEvent;
import android.view.View;
import android.view.View.DragShadowBuilder;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Collections;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    // Standard UUID for Bluetooth Classic Serial Port Profile (SPP)
    private static final UUID SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int MAX_ARENA_SIZE = 64;
    private static final long MOVE_COOLDOWN_MS = 250;

    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private BluetoothServerSocket serverSocket;
    private OutputStream out;
    private Thread readerThread;
    private Thread acceptThread;
    private volatile boolean shouldAccept = true;
    private volatile boolean accepting = false;
    private boolean suppressOutbound = false;

    private TextView txtStatus, txtLog, txtRobotStatus;
    private EditText edtSend;
    private View sectionHome, sectionBluetooth, sectionArena;
    private View sectionArenaMain, sectionArenaEdit, sectionArenaMoveRobot;
    private View sectionArenaShortestPath, sectionArenaTrial;
    private View arenaCanvasContainer;
    private View sectionArenaEditSizes;
    private View moveObstacleControls;
    private FrameLayout obstaclePalette;
    private ArenaView arenaView;
    private View sectionMoveManual;
    private View sectionMoveJoystick;
    private TextView txtMoveTiltHint;
    private TextView txtMoveTapHint;
    private JoystickView joystickPad;

    private enum MoveMode { MANUAL, JOYSTICK, TILT, TAP }
    private MoveMode moveMode = MoveMode.MANUAL;
    private long lastMoveTime = 0L;
    private final Handler moveHandler = new Handler(Looper.getMainLooper());
    private boolean moveSequenceActive = false;
    private boolean joystickActive = false;
    private int joystickAction = 0;

    private SensorManager sensorManager;
    private Sensor accelSensor;
    private SensorEventListener tiltListener;
    private int tiltAction = 0;
    private boolean tiltActive = false;
    private float tiltBaseX = 0f;
    private float tiltBaseY = 0f;
    private float lastAx = 0f;
    private float lastAy = 0f;

    private Button btnComputePath;
    private Button btnPlayPath;
    private Button btnPausePath;
    private Button btnResetPath;
    private Button btnNextStep;
    private Button btnPrevStep;
    private View rowPathStepControls;
    private TextView txtPathCost;
    private TextView txtPathProgress;
    private final Handler pathHandler = new Handler(Looper.getMainLooper());
    private List<Character> pathActions = new ArrayList<>();
    private boolean pathPlaying = false;
    private int pathIndex = 0;
    private int startPoseX;
    private int startPoseY;
    private int startPoseDir;

    private Button btnTrialReset;
    private Button btnEndAttempt;
    private Button btnTrialPlayOptimal;
    private TextView txtTrialActions;
    private TextView txtTrialScanned;
    private TextView txtTrialResult;
    private boolean timeTrialActive = false;
    private boolean timeTrialPlayback = false;
    private int trialActionCount = 0;
    private int trialTotalTargets = 0;
    private java.util.HashSet<String> trialScanned = new java.util.HashSet<>();
    private List<Character> trialOptimalActions = new ArrayList<>();
    private int trialIndex = 0;
    private int trialStartX;
    private int trialStartY;
    private int trialStartDir;
    private Button btnBackFromMove;

    private final ActivityResultLauncher<String[]> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                boolean ok = true;
                for (Boolean granted : result.values()) {
                    if (granted == null || !granted) ok = false;
                }
                if (!ok) {
                    setStatus("Permissions denied. Cannot use Bluetooth.");
                } else {
                    showConnectModeDialog();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adapter = BluetoothAdapter.getDefaultAdapter();

        Button btnConnect = findViewById(R.id.btnConnect);
        Button btnSend = findViewById(R.id.btnSend);
        Button btnOpenBluetooth = findViewById(R.id.btnOpenBluetooth);
        Button btnBackHome = findViewById(R.id.btnBackHome);
        Button btnOpenArena = findViewById(R.id.btnOpenArena);
        Button btnBackHomeArena = findViewById(R.id.btnBackHomeArena);
        Button btnArenaEdit = findViewById(R.id.btnArenaEdit);
        Button btnArenaMoveRobot = findViewById(R.id.btnArenaMoveRobot);
        Button btnArenaShortestPath = findViewById(R.id.btnArenaShortestPath);
        Button btnArenaTrial = findViewById(R.id.btnArenaTrial);
        Button btnBackArenaMainFromEdit = findViewById(R.id.btnBackArenaMainFromEdit);
        btnBackFromMove = findViewById(R.id.btnBackArenaMainFromMove);
        Button btnBackArenaMainFromShortest = findViewById(R.id.btnBackArenaMainFromShortest);
        Button btnBackArenaMainFromTrial = findViewById(R.id.btnBackArenaMainFromTrial);
        Button btnArenaEditSizes = findViewById(R.id.btnArenaEditSizes);
        Button btnBackArenaEditSizes = findViewById(R.id.btnBackArenaEditSizes);
        Button btnApplyArenaSizes = findViewById(R.id.btnApplyArenaSizes);
        Button btnArenaResetDefault = findViewById(R.id.btnArenaResetDefault);
        Button btnArenaClearObstacles = findViewById(R.id.btnArenaClearObstacles);
        Button btnMoveForward = findViewById(R.id.btnMoveForward);
        Button btnMoveBackward = findViewById(R.id.btnMoveBackward);
        Button btnRotateLeft = findViewById(R.id.btnRotateLeft);
        Button btnRotateRight = findViewById(R.id.btnRotateRight);
        btnComputePath = findViewById(R.id.btnComputePath);
        btnPlayPath = findViewById(R.id.btnPlayPath);
        btnPausePath = findViewById(R.id.btnPausePath);
        btnResetPath = findViewById(R.id.btnResetPath);
        btnNextStep = findViewById(R.id.btnNextStep);
        btnPrevStep = findViewById(R.id.btnPrevStep);
        rowPathStepControls = findViewById(R.id.rowPathStepControls);
        txtPathCost = findViewById(R.id.txtPathCost);
        txtPathProgress = findViewById(R.id.txtPathProgress);
        btnTrialReset = findViewById(R.id.btnTrialReset);
        btnEndAttempt = findViewById(R.id.btnEndAttempt);
        btnTrialPlayOptimal = findViewById(R.id.btnTrialPlayOptimal);
        txtTrialActions = findViewById(R.id.txtTrialActions);
        txtTrialScanned = findViewById(R.id.txtTrialScanned);
        txtTrialResult = findViewById(R.id.txtTrialResult);
        Button btnModeManual = findViewById(R.id.btnModeManual);
        Button btnModeJoystick = findViewById(R.id.btnModeJoystick);
        Button btnModeTilt = findViewById(R.id.btnModeTilt);
        Button btnModeTap = findViewById(R.id.btnModeTap);
        Button btnMoveObstacleDone = findViewById(R.id.btnMoveObstacleDone);
        Button btnMoveObstacleCancel = findViewById(R.id.btnMoveObstacleCancel);
        EditText edtArenaWidth = findViewById(R.id.edtArenaWidth);
        EditText edtArenaHeight = findViewById(R.id.edtArenaHeight);
        EditText edtRobotSize = findViewById(R.id.edtRobotSize);
        txtStatus = findViewById(R.id.txtStatus);
        txtLog = findViewById(R.id.txtLog);
        txtRobotStatus = findViewById(R.id.txtRobotStatus);
        edtSend = findViewById(R.id.edtSend);
        sectionHome = findViewById(R.id.sectionHome);
        sectionBluetooth = findViewById(R.id.sectionBluetooth);
        sectionArena = findViewById(R.id.sectionArena);
        sectionArenaMain = findViewById(R.id.sectionArenaMain);
        sectionArenaEdit = findViewById(R.id.sectionArenaEdit);
        sectionArenaMoveRobot = findViewById(R.id.sectionArenaMoveRobot);
        sectionArenaShortestPath = findViewById(R.id.sectionArenaShortestPath);
        sectionArenaTrial = findViewById(R.id.sectionArenaTrial);
        arenaCanvasContainer = findViewById(R.id.arenaCanvasContainer);
        sectionArenaEditSizes = findViewById(R.id.sectionArenaEditSizes);
        moveObstacleControls = findViewById(R.id.moveObstacleControls);
        obstaclePalette = findViewById(R.id.obstaclePalette);
        arenaView = findViewById(R.id.arenaView);
        sectionMoveManual = findViewById(R.id.sectionMoveManual);
        sectionMoveJoystick = findViewById(R.id.sectionMoveJoystick);
        txtMoveTiltHint = findViewById(R.id.txtMoveTiltHint);
        txtMoveTapHint = findViewById(R.id.txtMoveTapHint);
        joystickPad = findViewById(R.id.sectionMoveJoystick);

        btnOpenBluetooth.setOnClickListener(v -> showBluetoothSection());
        btnBackHome.setOnClickListener(v -> showHomeSection());
        btnOpenArena.setOnClickListener(v -> showArenaSection());
        btnBackHomeArena.setOnClickListener(v -> showHomeSection());
        btnArenaEdit.setOnClickListener(v -> showArenaSubsection(sectionArenaEdit));
        btnArenaMoveRobot.setOnClickListener(v -> showArenaSubsection(sectionArenaMoveRobot));
        btnArenaShortestPath.setOnClickListener(v -> showArenaSubsection(sectionArenaShortestPath));
        btnArenaTrial.setOnClickListener(v -> showArenaSubsection(sectionArenaTrial));
        btnBackArenaMainFromEdit.setOnClickListener(v -> showArenaMain());
        btnBackFromMove.setOnClickListener(v -> showArenaMain());
        btnBackArenaMainFromShortest.setOnClickListener(v -> showArenaMain());
        btnBackArenaMainFromTrial.setOnClickListener(v -> showArenaMain());
        btnArenaEditSizes.setOnClickListener(v -> showArenaEditSizes(edtArenaWidth, edtArenaHeight, edtRobotSize));
        btnBackArenaEditSizes.setOnClickListener(v -> {
            hideKeyboard();
            returnFromEditSizes();
        });
        btnApplyArenaSizes.setOnClickListener(v -> applyArenaSizes(
                edtArenaWidth, edtArenaHeight, edtRobotSize
        ));
        btnArenaResetDefault.setOnClickListener(v -> confirmResetDefault());
        btnArenaClearObstacles.setOnClickListener(v -> confirmClearObstacles());
        btnMoveForward.setOnClickListener(v -> moveForward(true));
        btnMoveBackward.setOnClickListener(v -> moveBackward(true));
        btnRotateLeft.setOnClickListener(v -> rotateLeft(true));
        btnRotateRight.setOnClickListener(v -> rotateRight(true));
        btnModeManual.setOnClickListener(v -> setMoveMode(MoveMode.MANUAL));
        btnModeJoystick.setOnClickListener(v -> setMoveMode(MoveMode.JOYSTICK));
        btnModeTilt.setOnClickListener(v -> {
            calibrateTilt();
            setMoveMode(MoveMode.TILT);
        });
        btnModeTap.setOnClickListener(v -> setMoveMode(MoveMode.TAP));
        btnComputePath.setOnClickListener(v -> computeShortestPath());
        btnPlayPath.setOnClickListener(v -> playPath());
        btnPausePath.setOnClickListener(v -> pausePath());
        btnResetPath.setOnClickListener(v -> resetPathPlayback());
        btnNextStep.setOnClickListener(v -> nextPathStep());
        btnPrevStep.setOnClickListener(v -> prevPathStep());
        btnTrialReset.setOnClickListener(v -> resetTimeTrial());
        btnEndAttempt.setOnClickListener(v -> endTimeTrial());
        btnTrialPlayOptimal.setOnClickListener(v -> playTimeTrialOptimal());
        btnMoveObstacleDone.setOnClickListener(v -> {
            arenaView.confirmMoveObstacle();
            moveObstacleControls.setVisibility(View.GONE);
            arenaView.clearSelection();
        });
        btnMoveObstacleCancel.setOnClickListener(v -> {
            arenaView.cancelMoveObstacle();
            moveObstacleControls.setVisibility(View.GONE);
            arenaView.clearSelection();
        });

        obstaclePalette.setOnTouchListener((v, event) -> {
            if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                v.startDragAndDrop(null, new DragShadowBuilder(v), null, 0);
                return true;
            }
            return false;
        });
        joystickPad.setListener((normX, normY, active) -> handleJoystickMove(normX, normY, active));
        arenaView.setOnDragListener((v, event) -> handleArenaDrag(event));
        arenaView.setListener(new ArenaView.ArenaListener() {
            @Override
            public void onObstacleTapped(ArenaView.Obstacle obstacle) {
                showObstacleMenu(obstacle);
            }

            @Override
            public void onMoveModeChanged(boolean active) {
                moveObstacleControls.setVisibility(active ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onObstacleAdded(ArenaView.Obstacle obstacle) {
                sendObstacleMessage("ADD", obstacle);
            }

            @Override
            public void onObstacleMoved(ArenaView.Obstacle obstacle) {
                sendObstacleMessage("MOVE", obstacle);
            }

            @Override
            public void onObstacleRemoved(ArenaView.Obstacle obstacle) {
                sendObstacleMessage("DEL", obstacle);
            }

            @Override
            public void onObstacleSizeChanged(ArenaView.Obstacle obstacle) {
                sendObstacleMessage("SIZE", obstacle);
            }

            @Override
            public void onObstacleNumberChanged(int oldNumber, ArenaView.Obstacle obstacle) {
                sendLine("OBS,NUM," + oldNumber + "," + obstacle.number);
            }

            @Override
            public void onTargetAdded(ArenaView.Obstacle obstacle, int face) {
                String faceLabel = faceToLabel(face);
                sendLine("TARGET,ADD," + obstacle.number + "," + faceLabel);
            }

            @Override
            public void onTargetsCleared(ArenaView.Obstacle obstacle) {
                sendLine("TARGET,CLEAR," + obstacle.number);
            }

            @Override
            public void onTargetIdChanged(ArenaView.Obstacle obstacle) {
                int targetId = (obstacle.targetId == null) ? 0 : obstacle.targetId;
                sendLine("TARGET," + obstacle.number + "," + targetId);
            }

            @Override
            public void onCellTapped(int x, int y) {
                if (moveMode == MoveMode.TAP) {
                    moveRobotTo(x, y);
                }
            }
        });
        btnConnect.setOnClickListener(v -> ensureBtPermissionsThenChooseMode());
        btnSend.setOnClickListener(v -> sendLine(edtSend.getText().toString()));

        if (adapter == null) {
            setStatus("Bluetooth not supported on this device.");
        }
    }

    private void showHomeSection() {
        sectionHome.setVisibility(View.VISIBLE);
        sectionBluetooth.setVisibility(View.GONE);
        sectionArena.setVisibility(View.GONE);
        sectionArenaEditSizes.setVisibility(View.GONE);
    }

    private void showBluetoothSection() {
        sectionHome.setVisibility(View.GONE);
        sectionBluetooth.setVisibility(View.VISIBLE);
        sectionArena.setVisibility(View.GONE);
        sectionArenaEditSizes.setVisibility(View.GONE);
    }

    private void showArenaSection() {
        sectionHome.setVisibility(View.GONE);
        sectionBluetooth.setVisibility(View.GONE);
        sectionArena.setVisibility(View.VISIBLE);
        sectionArenaEditSizes.setVisibility(View.GONE);
        showArenaMain();
    }

    private void showArenaMain() {
        arenaView.cancelMoveObstacle();
        moveObstacleControls.setVisibility(View.GONE);
        stopTiltMode();
        stopJoystickRepeat();
        timeTrialActive = false;
        timeTrialPlayback = false;
        sectionArenaMain.setVisibility(View.VISIBLE);
        sectionArenaEdit.setVisibility(View.GONE);
        sectionArenaMoveRobot.setVisibility(View.GONE);
        sectionArenaShortestPath.setVisibility(View.GONE);
        sectionArenaTrial.setVisibility(View.GONE);
        arenaCanvasContainer.setVisibility(View.GONE);
        sectionArenaEditSizes.setVisibility(View.GONE);
    }

    private void showArenaSubsection(View subsection) {
        if (subsection != sectionArenaEdit) {
            arenaView.cancelMoveObstacle();
            moveObstacleControls.setVisibility(View.GONE);
        }
        sectionArenaMain.setVisibility(View.GONE);
        sectionArenaEdit.setVisibility(View.GONE);
        sectionArenaMoveRobot.setVisibility(View.GONE);
        sectionArenaShortestPath.setVisibility(View.GONE);
        sectionArenaTrial.setVisibility(View.GONE);
        sectionArenaEditSizes.setVisibility(View.GONE);
        subsection.setVisibility(View.VISIBLE);
        if (subsection == sectionArenaEdit || subsection == sectionArenaMoveRobot
                || subsection == sectionArenaShortestPath) {
            arenaCanvasContainer.setVisibility(View.VISIBLE);
        } else {
            arenaCanvasContainer.setVisibility(View.GONE);
        }
        if (subsection == sectionArenaEdit) {
            arenaView.setObstacleEditEnabled(true);
            arenaView.setTapMoveEnabled(false);
            timeTrialActive = false;
            btnBackFromMove.setVisibility(View.VISIBLE);
        } else if (subsection == sectionArenaMoveRobot) {
            arenaView.setObstacleEditEnabled(false);
            setMoveMode(moveMode);
            timeTrialActive = false;
            btnBackFromMove.setVisibility(View.VISIBLE);
        } else if (subsection == sectionArenaShortestPath) {
            arenaView.setObstacleEditEnabled(false);
            arenaView.setTapMoveEnabled(false);
            stopTiltMode();
            timeTrialActive = false;
            btnBackFromMove.setVisibility(View.VISIBLE);
        } else if (subsection == sectionArenaTrial) {
            sectionArenaMoveRobot.setVisibility(View.VISIBLE);
            arenaCanvasContainer.setVisibility(View.VISIBLE);
            arenaView.setObstacleEditEnabled(false);
            setMoveMode(moveMode);
            btnBackFromMove.setVisibility(View.GONE);
            startTimeTrial();
        } else {
            arenaView.setObstacleEditEnabled(true);
            arenaView.setTapMoveEnabled(false);
            stopTiltMode();
            timeTrialActive = false;
            btnBackFromMove.setVisibility(View.VISIBLE);
        }
        if (subsection != sectionArenaShortestPath) {
            pathHandler.removeCallbacksAndMessages(null);
            pathPlaying = false;
            btnPausePath.setVisibility(View.GONE);
            rowPathStepControls.setVisibility(View.GONE);
            btnResetPath.setVisibility(View.GONE);
            btnPlayPath.setVisibility(View.GONE);
        }
    }

    private void showArenaEditSizes(EditText edtArenaWidth, EditText edtArenaHeight,
                                    EditText edtRobotSize) {
        sectionArena.setVisibility(View.GONE);
        sectionArenaEditSizes.setVisibility(View.VISIBLE);
        edtArenaWidth.setText(String.valueOf(arenaView.getArenaWidth()));
        edtArenaHeight.setText(String.valueOf(arenaView.getArenaHeight()));
        edtRobotSize.setText(String.valueOf(arenaView.getRobotSize()));
    }

    private void applyArenaSizes(EditText edtArenaWidth, EditText edtArenaHeight,
                                 EditText edtRobotSize) {
        hideKeyboard();
        Integer width = parsePositiveInt(edtArenaWidth.getText().toString());
        Integer height = parsePositiveInt(edtArenaHeight.getText().toString());
        Integer robotSize = parsePositiveInt(edtRobotSize.getText().toString());

        if (width == null || height == null || robotSize == null) {
            setStatus("Invalid sizes. Use positive integers.");
            return;
        }

        if (width > MAX_ARENA_SIZE || height > MAX_ARENA_SIZE) {
            setStatus("Arena size max is " + MAX_ARENA_SIZE + ".");
            return;
        }

        if (robotSize > width || robotSize > height) {
            setStatus("Robot must fit inside the arena.");
            return;
        }

        arenaView.resetArena(width, height, robotSize);
        sendLine("ARENA,SIZE," + width + "," + height);
        sendLine("ROBOT,SIZE," + robotSize);
        returnFromEditSizes();
    }

    private void returnFromEditSizes() {
        sectionArenaEditSizes.setVisibility(View.GONE);
        sectionArena.setVisibility(View.VISIBLE);
        showArenaSubsection(sectionArenaEdit);
    }

    private Integer parsePositiveInt(String s) {
        try {
            int v = Integer.parseInt(s.trim());
            if (v <= 0) return null;
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private Integer parseNonNegativeInt(String s) {
        try {
            int v = Integer.parseInt(s.trim());
            if (v < 0) return null;
            return v;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private int parseDir(String dir) {
        if (dir == null) return -1;
        switch (dir) {
            case "N":
                return 0;
            case "E":
                return 1;
            case "S":
                return 2;
            case "W":
                return 3;
            default:
                return -1;
        }
    }

    private void hideKeyboard() {
        View view = getCurrentFocus();
        if (view == null) return;
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private boolean handleArenaDrag(DragEvent event) {
        if (event.getAction() == DragEvent.ACTION_DROP) {
            arenaView.placeObstacleAtPixel(event.getX(), event.getY());
            return true;
        }
        return true;
    }

    private void showObstacleMenu(ArenaView.Obstacle obstacle) {
        String[] items = new String[]{"Remove obstacle", "Add target", "Remove targets", "Move obstacle", "Edit size", "Edit number", "Edit target ID"};
        new AlertDialog.Builder(this)
                .setTitle("Obstacle")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        arenaView.removeObstacle(obstacle.id);
                        arenaView.clearSelection();
                    } else if (which == 1) {
                        showTargetMenu(obstacle);
                    } else if (which == 2) {
                        arenaView.clearTargets(obstacle.id);
                        arenaView.clearSelection();
                    } else if (which == 3) {
                        arenaView.beginMoveObstacle(obstacle.id);
                    } else if (which == 4) {
                        showObstacleSizeMenu(obstacle);
                    } else if (which == 5) {
                        showObstacleNumberMenu(obstacle);
                    } else {
                        showTargetIdMenu(obstacle);
                    }
                })
                .setNegativeButton("Cancel", (d, w) -> arenaView.clearSelection())
                .show();
    }

    private void showTargetMenu(ArenaView.Obstacle obstacle) {
        String[] labels = new String[]{"North", "East", "South", "West"};
        boolean[] disabled = new boolean[]{
                obstacle.targetNorth, obstacle.targetEast, obstacle.targetSouth, obstacle.targetWest
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Add target")
                .setItems(labels, (dialog, which) -> {
                    if (disabled[which]) return;
                    arenaView.addTarget(obstacle.id, which);
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", (d, w) -> arenaView.clearSelection());

        AlertDialog dialog = builder.create();
        dialog.setOnShowListener(d -> {
            dialog.getListView().post(() -> {
                for (int i = 0; i < labels.length; i++) {
                    if (disabled[i]) {
                        View row = dialog.getListView().getChildAt(i);
                        if (row != null) row.setEnabled(false);
                    }
                }
            });
        });
        dialog.show();
    }

    private void showObstacleSizeMenu(ArenaView.Obstacle obstacle) {
        EditText input = new EditText(this);
        input.setHint("New size");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(obstacle.size));

        new AlertDialog.Builder(this)
                .setTitle("Edit obstacle size")
                .setView(input)
                .setPositiveButton("Apply", (d, w) -> {
                    Integer size = parsePositiveInt(input.getText().toString());
                    if (size == null) {
                        setStatus("Invalid size.");
                        arenaView.clearSelection();
                        return;
                    }
                    if (!arenaView.updateObstacleSize(obstacle.id, size)) {
                        setStatus("Obstacle size does not fit.");
                    }
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", (d, w) -> arenaView.clearSelection())
                .show();
    }

    private void showObstacleNumberMenu(ArenaView.Obstacle obstacle) {
        EditText input = new EditText(this);
        input.setHint("New number");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(obstacle.number));

        new AlertDialog.Builder(this)
                .setTitle("Edit obstacle number")
                .setView(input)
                .setPositiveButton("Apply", (d, w) -> {
                    Integer number = parsePositiveInt(input.getText().toString());
                    if (number == null) {
                        setStatus("Invalid number.");
                        arenaView.clearSelection();
                        return;
                    }
                    if (!arenaView.updateObstacleNumber(obstacle.id, number)) {
                        setStatus("Obstacle number already in use.");
                    }
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", (d, w) -> arenaView.clearSelection())
                .show();
    }

    private void showTargetIdMenu(ArenaView.Obstacle obstacle) {
        EditText input = new EditText(this);
        input.setHint("Target ID (blank to clear)");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        if (obstacle.targetId != null) {
            input.setText(String.valueOf(obstacle.targetId));
        }

        new AlertDialog.Builder(this)
                .setTitle("Edit target ID")
                .setView(input)
                .setPositiveButton("Apply", (d, w) -> {
                    String raw = input.getText().toString().trim();
                    Integer targetId = raw.isEmpty() ? null : parsePositiveInt(raw);
                    if (raw.length() > 0 && targetId == null) {
                        setStatus("Invalid target ID.");
                        arenaView.clearSelection();
                        return;
                    }
                    arenaView.setTargetId(obstacle.id, targetId);
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", (d, w) -> arenaView.clearSelection())
                .show();
    }

    private void confirmResetDefault() {
        new AlertDialog.Builder(this)
                .setTitle("Reset arena")
                .setMessage("Reset arena sizes to default and clear all obstacles?")
                .setPositiveButton("Reset", (d, w) -> {
                    arenaView.resetToDefault();
                    moveObstacleControls.setVisibility(View.GONE);
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmClearObstacles() {
        new AlertDialog.Builder(this)
                .setTitle("Clear obstacles")
                .setMessage("Remove all obstacles and targets?")
                .setPositiveButton("Clear", (d, w) -> {
                    arenaView.clearObstacles();
                    moveObstacleControls.setVisibility(View.GONE);
                    arenaView.clearSelection();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void sendObstacleMessage(String type, ArenaView.Obstacle obstacle) {
        String msg;
        if ("ADD".equals(type)) {
            msg = "OBS,ADD," + obstacle.number + "," + obstacle.x + "," + obstacle.y + "," + obstacle.size;
        } else if ("MOVE".equals(type)) {
            msg = "OBS,MOVE," + obstacle.number + "," + obstacle.x + "," + obstacle.y;
        } else if ("DEL".equals(type)) {
            msg = "OBS,DEL," + obstacle.number;
        } else if ("SIZE".equals(type)) {
            msg = "OBS,SIZE," + obstacle.number + "," + obstacle.size;
        } else {
            return;
        }
        sendLine(msg);
    }

    private String faceToLabel(int face) {
        switch (face) {
            case 0:
                return "N";
            case 1:
                return "E";
            case 2:
                return "S";
            case 3:
                return "W";
            default:
                return "?";
        }
    }

    private void ensureBtPermissionsThenChooseMode() {
        if (adapter == null) return;

        ArrayList<String> needed = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                    != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.BLUETOOTH_SCAN);
            }
        }

        if (!needed.isEmpty()) {
            permLauncher.launch(needed.toArray(new String[0]));
            return;
        }

        showConnectModeDialog();
    }

    private void showConnectModeDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Connect Bluetooth")
                .setItems(new String[]{"Listen for PC (recommended)", "Connect to paired device"}, (dialog, which) -> {
                    if (which == 0) {
                        startAcceptThread();
                    } else {
                        showPairedDevicesDialog();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPairedDevicesDialog() {
        if (adapter == null) return;

        if (!adapter.isEnabled()) {
            setStatus("Enable Bluetooth in tablet settings first.");
            return;
        }

        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        if (bonded == null || bonded.isEmpty()) {
            setStatus("No paired devices found. Pair with PC/AMD tool first.");
            return;
        }

        ArrayList<BluetoothDevice> devices = new ArrayList<>(bonded);
        String[] labels = new String[devices.size()];
        for (int i = 0; i < devices.size(); i++) {
            BluetoothDevice d = devices.get(i);
            String name = (d.getName() == null) ? "Unnamed" : d.getName();
            labels[i] = name + "\n" + d.getAddress();
        }

        new AlertDialog.Builder(this)
                .setTitle("Select paired device")
                .setItems(labels, (dialog, which) -> connectToDevice(devices.get(which)))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startAcceptThread() {
        disconnect();
        setStatus("Waiting for AMD tool to connect...");

        if (accepting) return;
        accepting = true;
        acceptThread = new Thread(() -> {
            while (shouldAccept && adapter != null) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                                != PackageManager.PERMISSION_GRANTED) {
                            runOnUiThread(() -> setStatus("Missing BLUETOOTH_CONNECT permission."));
                            accepting = false;
                            return;
                        }
                    }

                    if (!adapter.isEnabled()) {
                        runOnUiThread(() -> setStatus("Enable Bluetooth in tablet settings first."));
                        accepting = false;
                        return;
                    }

                    if (serverSocket == null) {
                        serverSocket = adapter.listenUsingRfcommWithServiceRecord(
                                "MDPRemoteController", SPP_UUID
                        );
                    }

                    BluetoothSocket s = serverSocket.accept();
                    if (s != null) {
                        socket = s;
                        out = socket.getOutputStream();
                        BluetoothDevice device = socket.getRemoteDevice();
                        runOnUiThread(() -> setStatus("Connected: " + device.getName()));
                        startReaderThread();
                    }
                } catch (IOException e) {
                    runOnUiThread(() -> setStatus("Listen failed: " + e.getMessage()));
                    closeServerSocket();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ignored) {
                        break;
                    }
                }
            }
            accepting = false;
        });
        acceptThread.start();
    }

    private void connectToDevice(BluetoothDevice device) {
        disconnect();
        setStatus("Connecting to " + device.getName() + "...");

        new Thread(() -> {
            if (!attemptClientConnect(device)) {
                runOnUiThread(() -> setStatus("Connect failed. Try again."));
            }
        }).start();
    }

    private boolean attemptClientConnect(BluetoothDevice device) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                        != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> setStatus("Missing BLUETOOTH_CONNECT permission."));
                    return false;
                }
            }

            BluetoothSocket s = device.createRfcommSocketToServiceRecord(SPP_UUID);
            adapter.cancelDiscovery();
            s.connect();

            socket = s;
            out = socket.getOutputStream();

            runOnUiThread(() -> setStatus("Connected: " + device.getName()));
            startReaderThread();
            return true;
        } catch (IOException e) {
            disconnect();
            return false;
        }
    }

    private void startReaderThread() {
        readerThread = new Thread(() -> {
            try {
                InputStream in = socket.getInputStream();
                byte[] buffer = new byte[1024];
                StringBuilder pending = new StringBuilder();
                int read;
                while (!Thread.currentThread().isInterrupted() && (read = in.read(buffer)) != -1) {
                    String chunk = new String(buffer, 0, read, StandardCharsets.UTF_8);
                    pending.append(chunk);

                    int newlineIndex = indexOfLineBreak(pending);
                    if (newlineIndex == -1) {
                        if (pending.length() > 0) {
                            String msg = pending.toString().trim();
                            if (!msg.isEmpty()) {
                                String finalLine = msg;
                                runOnUiThread(() -> handleIncomingLine(finalLine));
                            }
                            pending.setLength(0);
                        }
                        continue;
                    }

                    while (newlineIndex != -1) {
                        String line = extractLine(pending, newlineIndex);
                        if (!line.isEmpty()) {
                            String finalLine = line;
                            runOnUiThread(() -> handleIncomingLine(finalLine));
                        }
                        newlineIndex = indexOfLineBreak(pending);
                    }
                }
                runOnUiThread(() -> appendLog("Reader stopped: disconnected"));
                runOnUiThread(() -> setStatus("Disconnected. Waiting for reconnect..."));
            } catch (IOException e) {
                runOnUiThread(() -> appendLog("Reader stopped: " + e.getMessage()));
                runOnUiThread(() -> setStatus("Disconnected. Waiting for reconnect..."));
            } finally {
                closeClientSocket();
            }
        });
        readerThread.start();
    }

    private void sendLine(String msg) {
        if (suppressOutbound) return;
        if (out == null) {
            appendLog("TX failed: not connected");
            return;
        }

        new Thread(() -> {
            try {
                String line = msg + "\n";
                out.write(line.getBytes(StandardCharsets.UTF_8));
                out.flush();
                runOnUiThread(() -> appendLog("TX: " + msg));
            } catch (IOException e) {
                runOnUiThread(() -> appendLog("TX error: " + e.getMessage()));
            }
        }).start();
    }

    private void disconnect() {
        try {
            if (readerThread != null) readerThread.interrupt();
        } catch (Exception ignored) {}

        try {
            if (out != null) out.close();
        } catch (Exception ignored) {}

        closeClientSocket();
        closeServerSocket();
        out = null;
        readerThread = null;
    }

    private void setStatus(String s) {
        txtStatus.setText("Status: " + s);
        appendLog("STATUS: " + s);
    }

    private void handleIncomingLine(String line) {
        appendLog("RX: " + line);
        String status = parseStatusLine(line);
        if (status != null) {
            txtRobotStatus.setText(status);
        }
        handleMoveCommand(line);
        handleArenaCommand(line);
    }

    private void handleArenaCommand(String line) {
        suppressOutbound = true;
        try {
        String trimmed = line.trim();
        if (trimmed.startsWith("OBS,")) {
            String[] parts = trimmed.split(",");
            if (parts.length < 3) return;
            String action = parts[1].trim().toUpperCase();
            if ("ADD".equals(action) && parts.length >= 6) {
                Integer num = parsePositiveInt(parts[2]);
                Integer x = parseNonNegativeInt(parts[3]);
                Integer y = parseNonNegativeInt(parts[4]);
                Integer size = parsePositiveInt(parts[5]);
                if (num == null || x == null || y == null || size == null) return;
                arenaView.addObstacleWithNumber(num, x, y, size);
            } else if ("MOVE".equals(action) && parts.length >= 5) {
                Integer num = parsePositiveInt(parts[2]);
                Integer x = parseNonNegativeInt(parts[3]);
                Integer y = parseNonNegativeInt(parts[4]);
                if (num == null || x == null || y == null) return;
                arenaView.moveObstacleByNumber(num, x, y);
            } else if ("DEL".equals(action) && parts.length >= 3) {
                Integer num = parsePositiveInt(parts[2]);
                if (num == null) return;
                arenaView.removeObstacleByNumber(num);
            } else if ("SIZE".equals(action) && parts.length >= 4) {
                Integer num = parsePositiveInt(parts[2]);
                Integer size = parsePositiveInt(parts[3]);
                if (num == null || size == null) return;
                arenaView.updateObstacleSizeByNumber(num, size);
            } else if ("NUM".equals(action) && parts.length >= 4) {
                Integer oldNum = parsePositiveInt(parts[2]);
                Integer newNum = parsePositiveInt(parts[3]);
                if (oldNum == null || newNum == null) return;
                arenaView.updateObstacleNumberByNumber(oldNum, newNum);
            }
            return;
        }
        if (trimmed.startsWith("TARGET,")) {
            String[] parts = trimmed.split(",");
            if (parts.length < 3) return;
            String action = parts[1].trim().toUpperCase();
            if ("ADD".equals(action) && parts.length >= 4) {
                Integer num = parsePositiveInt(parts[2]);
                if (num == null) return;
                String face = parts[3].trim().toUpperCase();
                arenaView.addTargetByNumber(num, face);
            } else if ("CLEAR".equals(action)) {
                Integer num = parsePositiveInt(parts[2]);
                if (num == null) return;
                arenaView.clearTargetsByNumber(num);
            } else {
                Integer num = parsePositiveInt(parts[1]);
                Integer targetId = parseNonNegativeInt(parts[2]);
                if (num == null) return;
                arenaView.setTargetIdByNumber(num, targetId);
            }
            return;
        }
        if (trimmed.startsWith("ROBOT,")) {
            String[] parts = trimmed.split(",");
            if (parts.length >= 3 && "SIZE".equalsIgnoreCase(parts[1].trim())) {
                Integer size = parsePositiveInt(parts[2]);
                if (size == null) return;
                int width = arenaView.getArenaWidth();
                int height = arenaView.getArenaHeight();
                if (size > width || size > height) return;
                arenaView.resetArena(width, height, size);
                return;
            }
            if (parts.length >= 4) {
                Integer x = parseNonNegativeInt(parts[1]);
                Integer y = parseNonNegativeInt(parts[2]);
                String dirStr = parts[3].trim().toUpperCase();
                if (x == null || y == null) return;
                int dir = parseDir(dirStr);
                if (dir < 0) return;
                arenaView.setRobotPose(x, y, dir);
            }
            return;
        }
        if (trimmed.startsWith("ARENA,SIZE,")) {
            String[] parts = trimmed.split(",");
            if (parts.length >= 4) {
                Integer width = parsePositiveInt(parts[2]);
                Integer height = parsePositiveInt(parts[3]);
                if (width == null || height == null) return;
                if (width > MAX_ARENA_SIZE || height > MAX_ARENA_SIZE) return;
                int robotSize = arenaView.getRobotSize();
                if (robotSize > width || robotSize > height) return;
                arenaView.resetArena(width, height, robotSize);
            }
        }
        } finally {
            suppressOutbound = false;
        }
    }

    private void handleMoveCommand(String line) {
        String cmd = normalizeCommand(line);
        if (cmd == null || cmd.isEmpty()) return;

        if (cmd.equals("FORWARD") || cmd.equals("MOVE_FORWARD") || cmd.equals("MOVE,FORWARD") || cmd.equals("MOVE:FORWARD")) {
            moveForward(false);
        } else if (cmd.equals("BACKWARD") || cmd.equals("MOVE_BACKWARD") || cmd.equals("MOVE,BACKWARD") || cmd.equals("MOVE:BACKWARD")) {
            moveBackward(false);
        } else if (cmd.equals("ROTATE_LEFT") || cmd.equals("TURN_LEFT") || cmd.equals("ROTATE,LEFT") || cmd.equals("TURN,LEFT")) {
            rotateLeft(false);
        } else if (cmd.equals("ROTATE_RIGHT") || cmd.equals("TURN_RIGHT") || cmd.equals("ROTATE,RIGHT") || cmd.equals("TURN,RIGHT")) {
            rotateRight(false);
        }
    }

    private void moveForward(boolean send) {
        if (arenaView.moveForward()) {
            if (send && timeTrialActive && !timeTrialPlayback) {
                onTrialAction();
            }
            if (send) {
            sendLine("MOVE,FORWARD");
            }
        }
    }

    private void moveBackward(boolean send) {
        if (arenaView.moveBackward()) {
            if (send && timeTrialActive && !timeTrialPlayback) {
                onTrialAction();
            }
            if (send) {
            sendLine("MOVE,BACKWARD");
            }
        }
    }

    private void rotateLeft(boolean send) {
        arenaView.rotateLeft();
        if (send && timeTrialActive && !timeTrialPlayback) {
            onTrialAction();
        }
        if (send) sendLine("ROTATE,LEFT");
    }

    private void rotateRight(boolean send) {
        arenaView.rotateRight();
        if (send && timeTrialActive && !timeTrialPlayback) {
            onTrialAction();
        }
        if (send) sendLine("ROTATE,RIGHT");
    }

    private void setMoveMode(MoveMode mode) {
        moveMode = mode;
        moveSequenceActive = false;
        moveHandler.removeCallbacksAndMessages(null);
        stopJoystickRepeat();
        sectionMoveManual.setVisibility(mode == MoveMode.MANUAL ? View.VISIBLE : View.GONE);
        sectionMoveJoystick.setVisibility(mode == MoveMode.JOYSTICK ? View.VISIBLE : View.GONE);
        txtMoveTiltHint.setVisibility(mode == MoveMode.TILT ? View.VISIBLE : View.GONE);
        txtMoveTapHint.setVisibility(mode == MoveMode.TAP ? View.VISIBLE : View.GONE);

        arenaView.setTapMoveEnabled(mode == MoveMode.TAP);
        if (mode == MoveMode.TILT) {
            startTiltMode();
        } else {
            stopTiltMode();
        }
    }

    private void handleJoystickMove(float normX, float normY, boolean active) {
        if (moveMode != MoveMode.JOYSTICK) return;
        if (!active) {
            stopJoystickRepeat();
            return;
        }
        float threshold = 0.35f;
        if (Math.abs(normX) < threshold && Math.abs(normY) < threshold) {
            stopJoystickRepeat();
            return;
        }

        int desiredDir;
        if (Math.abs(normY) >= Math.abs(normX)) {
            desiredDir = (normY < 0) ? 0 : 2;
        } else {
            desiredDir = (normX < 0) ? 3 : 1;
        }
        startJoystickRepeat(desiredDir);
    }

    private void moveRobotTo(int targetX, int targetY) {
        if (moveSequenceActive) return;
        moveSequenceActive = true;
        moveHandler.post(() -> runMoveSequence(targetX, targetY));
    }

    private void runMoveSequence(int targetX, int targetY) {
        int x = arenaView.getRobotX();
        int y = arenaView.getRobotY();
        int dir = arenaView.getRobotDir();

        if (x == targetX && y == targetY) {
            moveSequenceActive = false;
            return;
        }

        int stepDx = targetX - x;
        int stepDy = targetY - y;

        if (stepDx != 0) {
            int desiredDir = stepDx > 0 ? 1 : 3;
            dir = rotateTo(desiredDir, dir);
            boolean moved = arenaView.moveForward();
            if (moved) {
                if (timeTrialActive && !timeTrialPlayback) onTrialAction();
                sendLine("MOVE,FORWARD");
            } else {
                moveSequenceActive = false;
                return;
            }
        } else if (stepDy != 0) {
            int desiredDir = stepDy > 0 ? 0 : 2;
            dir = rotateTo(desiredDir, dir);
            boolean moved = arenaView.moveForward();
            if (moved) {
                if (timeTrialActive && !timeTrialPlayback) onTrialAction();
                sendLine("MOVE,FORWARD");
            } else {
                moveSequenceActive = false;
                return;
            }
        }

        moveHandler.postDelayed(() -> runMoveSequence(targetX, targetY), 250);
    }

    private int rotateTo(int desiredDir, int currentDir) {
        int diff = (desiredDir - currentDir + 4) % 4;
        if (diff == 0) return currentDir;
        if (diff == 1) {
            rotateRight(true);
            return (currentDir + 1) % 4;
        } else if (diff == 3) {
            rotateLeft(true);
            return (currentDir + 3) % 4;
        } else {
            rotateRight(true);
            rotateRight(true);
            return (currentDir + 2) % 4;
        }
    }

    private void startTiltMode() {
        if (sensorManager == null) {
            sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            accelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }
        if (sensorManager == null || accelSensor == null) {
            setStatus("Tilt not supported on this device.");
            return;
        }
        if (tiltListener == null) {
            tiltListener = new SensorEventListener() {
                @Override
                public void onSensorChanged(SensorEvent event) {
                    if (moveMode != MoveMode.TILT) return;
                    float ax = event.values[0];
                    float ay = event.values[1];
                    lastAx = ax;
                    lastAy = ay;

                    float dx = ax - tiltBaseX;
                    float dy = ay - tiltBaseY;

                    if (dy < 7f && dy > -7f && dx < 3f && dx > -3f) {
                        stopTiltRepeat();
                        return;
                    }

                    if (Math.abs(dy) >= Math.abs(dx)) {
                        if (dy < -4f) setTiltAction(0);
                        else if (dy > 4f) setTiltAction(2);
                    } else {
                        if (dx > 4f) setTiltAction(3);
                        else if (dx < -4f) setTiltAction(1);
                    }
                }

                @Override
                public void onAccuracyChanged(Sensor sensor, int accuracy) {
                }
            };
        }
        sensorManager.registerListener(tiltListener, accelSensor, SensorManager.SENSOR_DELAY_UI);
    }

    private void stopTiltMode() {
        if (sensorManager != null && tiltListener != null) {
            sensorManager.unregisterListener(tiltListener);
        }
        stopTiltRepeat();
    }

    private void setTiltAction(int action) {
        if (tiltAction == action && tiltActive) return;
        tiltAction = action;
        if (!tiltActive) {
            tiltActive = true;
            moveHandler.post(tiltRunnable);
        }
    }

    private void stopTiltRepeat() {
        tiltActive = false;
        tiltAction = 0;
        moveHandler.removeCallbacks(tiltRunnable);
    }

    private final Runnable tiltRunnable = new Runnable() {
        @Override
        public void run() {
            if (!tiltActive || moveMode != MoveMode.TILT) return;
            long now = System.currentTimeMillis();
            if (now - lastMoveTime >= MOVE_COOLDOWN_MS) {
                moveTowardDir(tiltAction);
                lastMoveTime = now;
            }
            moveHandler.postDelayed(this, MOVE_COOLDOWN_MS);
        }
    };

    private void calibrateTilt() {
        tiltBaseX = lastAx;
        tiltBaseY = lastAy;
    }

    private void moveTowardDir(int desiredDir) {
        int currentDir = arenaView.getRobotDir();
        rotateTo(desiredDir, currentDir);
        moveForward(true);
    }

    private void startTimeTrial() {
        timeTrialActive = true;
        timeTrialPlayback = false;
        trialActionCount = 0;
        trialScanned.clear();
        trialOptimalActions.clear();
        trialIndex = 0;
        trialTotalTargets = collectTargets().size();
        trialStartX = arenaView.getRobotX();
        trialStartY = arenaView.getRobotY();
        trialStartDir = arenaView.getRobotDir();
        txtTrialActions.setText("Actions: 0");
        txtTrialScanned.setText("Targets scanned: 0/" + trialTotalTargets);
        txtTrialResult.setText("Result: -");
        btnEndAttempt.setVisibility(View.GONE);
        btnTrialPlayOptimal.setVisibility(View.GONE);
    }

    private void resetTimeTrial() {
        pathHandler.removeCallbacksAndMessages(null);
        timeTrialPlayback = false;
        arenaView.setRobotPose(trialStartX, trialStartY, trialStartDir);
        trialActionCount = 0;
        trialScanned.clear();
        txtTrialActions.setText("Actions: 0");
        txtTrialScanned.setText("Targets scanned: 0/" + trialTotalTargets);
        txtTrialResult.setText("Result: -");
        btnEndAttempt.setVisibility(View.GONE);
        btnTrialPlayOptimal.setVisibility(View.GONE);
        timeTrialActive = true;
    }

    private void onTrialAction() {
        trialActionCount++;
        txtTrialActions.setText("Actions: " + trialActionCount);
        checkTrialScans();
    }

    private void checkTrialScans() {
        if (!timeTrialActive) return;
        int robotX = arenaView.getRobotX();
        int robotY = arenaView.getRobotY();
        int robotDir = arenaView.getRobotDir();
        int robotSize = arenaView.getRobotSize();

        for (Target t : collectTargets()) {
            String key = t.key();
            if (trialScanned.contains(key)) continue;
            if (isScanningTarget(robotX, robotY, robotDir, robotSize, t)) {
                trialScanned.add(key);
            }
        }
        txtTrialScanned.setText("Targets scanned: " + trialScanned.size() + "/" + trialTotalTargets);
        if (trialScanned.size() == trialTotalTargets && trialTotalTargets > 0) {
            btnEndAttempt.setVisibility(View.VISIBLE);
        }
    }

    private boolean isScanningTarget(int rx, int ry, int rDir, int rSize, Target t) {
        ArenaView.Obstacle o = t.obstacle;
        int ox = o.x;
        int oy = o.y;
        int os = o.size;
        if (t.face == 0) { // North, robot above, facing South
            if (rDir != 2) return false;
            if (ry != oy + os) return false;
            return rangesOverlap(rx, rx + rSize - 1, ox, ox + os - 1);
        } else if (t.face == 2) { // South, robot below, facing North
            if (rDir != 0) return false;
            if (ry != oy - rSize) return false;
            return rangesOverlap(rx, rx + rSize - 1, ox, ox + os - 1);
        } else if (t.face == 1) { // East, robot right, facing West
            if (rDir != 3) return false;
            if (rx != ox + os) return false;
            return rangesOverlap(ry, ry + rSize - 1, oy, oy + os - 1);
        } else { // West, robot left, facing East
            if (rDir != 1) return false;
            if (rx != ox - rSize) return false;
            return rangesOverlap(ry, ry + rSize - 1, oy, oy + os - 1);
        }
    }

    private boolean rangesOverlap(int a0, int a1, int b0, int b1) {
        return a0 <= b1 && b0 <= a1;
    }

    private void endTimeTrial() {
        if (trialScanned.size() != trialTotalTargets || trialTotalTargets == 0) return;
        timeTrialActive = false;
        timeTrialPlayback = false;

        arenaView.setRobotPose(trialStartX, trialStartY, trialStartDir);
        computeShortestPath();
        trialOptimalActions = new ArrayList<>(pathActions);
        int optimalCost = trialOptimalActions.size();

        if (trialOptimalActions.isEmpty()) {
            txtTrialResult.setText("Result: No optimal path found.");
            btnTrialPlayOptimal.setVisibility(View.GONE);
        } else {
            txtTrialResult.setText("Result: Your actions " + trialActionCount + ", optimal " + optimalCost);
            btnTrialPlayOptimal.setVisibility(View.VISIBLE);
        }
        btnEndAttempt.setVisibility(View.GONE);
    }

    private void playTimeTrialOptimal() {
        if (trialOptimalActions.isEmpty() || timeTrialPlayback) return;
        timeTrialPlayback = true;
        trialIndex = 0;
        btnTrialPlayOptimal.setVisibility(View.GONE);
        pathHandler.post(trialPathRunnable);
    }

    private final Runnable trialPathRunnable = new Runnable() {
        @Override
        public void run() {
            if (!timeTrialPlayback) return;
            if (trialIndex >= trialOptimalActions.size()) {
                timeTrialPlayback = false;
                int optimalCost = trialOptimalActions.size();
                if (trialActionCount <= optimalCost) {
                    txtTrialResult.setText("Result: Victory! Your " + trialActionCount + " vs optimal " + optimalCost);
                } else {
                    txtTrialResult.setText("Result: Try again. Your " + trialActionCount + " vs optimal " + optimalCost);
                }
                btnTrialPlayOptimal.setVisibility(View.VISIBLE);
                return;
            }
            applyAction(trialOptimalActions.get(trialIndex));
            trialIndex++;
            pathHandler.postDelayed(this, 200);
        }
    };

    private void computeShortestPath() {
        pathHandler.removeCallbacksAndMessages(null);
        pathPlaying = false;
        pathActions.clear();
        btnPlayPath.setVisibility(View.GONE);
        btnPlayPath.setText("Play");
        btnPausePath.setVisibility(View.GONE);
        rowPathStepControls.setVisibility(View.GONE);
        btnResetPath.setVisibility(View.GONE);
        txtPathCost.setText("Cost: -");
        txtPathProgress.setText("Steps: -");

        List<Target> targets = collectTargets();
        if (targets.isEmpty()) {
            setStatus("No targets to scan.");
            return;
        }
        if (targets.size() > 12) {
            setStatus("Too many targets for exact shortest path.");
            return;
        }

        int width = arenaView.getArenaWidth();
        int height = arenaView.getArenaHeight();
        int totalStates = width * height * 4;
        int startState = stateIndex(arenaView.getRobotX(), arenaView.getRobotY(), arenaView.getRobotDir(), width);

        List<Integer> approachStates = new ArrayList<>();
        List<List<Integer>> targetToApproach = new ArrayList<>();
        List<List<Integer>> targetToApproachIdx = new ArrayList<>();
        for (Target t : targets) {
            List<Integer> list = buildApproachStates(t, width, height);
            if (list.isEmpty()) {
                setStatus("Target unreachable: " + t.label());
                return;
            }
            targetToApproach.add(list);
            List<Integer> idxList = new ArrayList<>();
            for (int state : list) {
                approachStates.add(state);
                idxList.add(approachStates.size() - 1);
            }
            targetToApproachIdx.add(idxList);
        }

        int m = approachStates.size();
        int[] distStart = bfsDistances(startState, width, height, totalStates);
        int[][] distFrom = new int[m][];
        for (int i = 0; i < m; i++) {
            distFrom[i] = bfsDistances(approachStates.get(i), width, height, totalStates);
        }

        int n = targets.size();
        int fullMask = (1 << n) - 1;
        int[][] dp = new int[1 << n][m];
        int[][] prevState = new int[1 << n][m];
        int[][] prevMask = new int[1 << n][m];
        for (int mask = 0; mask <= fullMask; mask++) {
            Arrays.fill(dp[mask], Integer.MAX_VALUE / 4);
            Arrays.fill(prevState[mask], -1);
            Arrays.fill(prevMask[mask], -1);
        }

        for (int t = 0; t < n; t++) {
            List<Integer> idxList = targetToApproachIdx.get(t);
            for (int sIndex : idxList) {
                int dist = distStart[approachStates.get(sIndex)];
                if (dist >= Integer.MAX_VALUE / 4) continue;
                int mask = 1 << t;
                dp[mask][sIndex] = dist;
            }
        }

        for (int mask = 0; mask <= fullMask; mask++) {
            for (int s = 0; s < m; s++) {
                if (dp[mask][s] >= Integer.MAX_VALUE / 4) continue;
                for (int t = 0; t < n; t++) {
                    if ((mask & (1 << t)) != 0) continue;
                    List<Integer> idxList = targetToApproachIdx.get(t);
                    for (int s2 : idxList) {
                        int dist = distFrom[s][approachStates.get(s2)];
                        if (dist >= Integer.MAX_VALUE / 4) continue;
                        int newMask = mask | (1 << t);
                        int newCost = dp[mask][s] + dist;
                        if (newCost < dp[newMask][s2]) {
                            dp[newMask][s2] = newCost;
                            prevState[newMask][s2] = s;
                            prevMask[newMask][s2] = mask;
                        }
                    }
                }
            }
        }

        int bestCost = Integer.MAX_VALUE / 4;
        int bestState = -1;
        for (int s = 0; s < m; s++) {
            int cost = dp[fullMask][s];
            if (cost < bestCost) {
                bestCost = cost;
                bestState = s;
            }
        }
        if (bestState == -1) {
            setStatus("No path found.");
            return;
        }

        List<Integer> seq = new ArrayList<>();
        int mask = fullMask;
        int s = bestState;
        while (s != -1) {
            seq.add(s);
            int ps = prevState[mask][s];
            int pm = prevMask[mask][s];
            s = ps;
            mask = pm;
        }
        Collections.reverse(seq);

        List<Character> actions = new ArrayList<>();
        if (!seq.isEmpty()) {
            List<Character> a = bfsActions(startState, approachStates.get(seq.get(0)), width, height, totalStates);
            if (a == null) {
                setStatus("Path build failed.");
                return;
            }
            actions.addAll(a);
            for (int i = 0; i < seq.size() - 1; i++) {
                int fromState = approachStates.get(seq.get(i));
                int toState = approachStates.get(seq.get(i + 1));
                List<Character> part = bfsActions(fromState, toState, width, height, totalStates);
                if (part == null) {
                    setStatus("Path build failed.");
                    return;
                }
                actions.addAll(part);
            }
        }

        pathActions = actions;
        txtPathCost.setText("Cost: " + actions.size() + " actions");
        txtPathProgress.setText("Steps: 0/" + actions.size());
        btnPlayPath.setVisibility(actions.isEmpty() ? View.GONE : View.VISIBLE);
        btnPlayPath.setText("Play");
        btnPausePath.setVisibility(View.GONE);
        rowPathStepControls.setVisibility(View.GONE);
        btnResetPath.setVisibility(View.GONE);

        startPoseX = arenaView.getRobotX();
        startPoseY = arenaView.getRobotY();
        startPoseDir = arenaView.getRobotDir();
    }

    private void playPath() {
        if (pathActions.isEmpty() || pathPlaying) return;
        pathPlaying = true;
        pathIndex = 0;
        btnPlayPath.setVisibility(View.GONE);
        btnPausePath.setVisibility(View.VISIBLE);
        rowPathStepControls.setVisibility(View.GONE);
        btnResetPath.setVisibility(View.GONE);
        txtPathProgress.setText("Steps: 0/" + pathActions.size());
        pathHandler.post(pathStepRunnable);
    }

    private final Runnable pathStepRunnable = new Runnable() {
        @Override
        public void run() {
            if (!pathPlaying) return;
            if (pathIndex >= pathActions.size()) {
                pathPlaying = false;
                btnPausePath.setVisibility(View.GONE);
                btnResetPath.setVisibility(View.VISIBLE);
                rowPathStepControls.setVisibility(View.VISIBLE);
                btnPlayPath.setVisibility(View.VISIBLE);
                btnPlayPath.setText("Play");
                return;
            }
            char action = pathActions.get(pathIndex);
            applyAction(action);
            pathIndex++;
            txtPathProgress.setText("Steps: " + pathIndex + "/" + pathActions.size());
            pathHandler.postDelayed(this, 200);
        }
    };

    private void pausePath() {
        if (!pathPlaying) return;
        pathPlaying = false;
        pathHandler.removeCallbacksAndMessages(null);
        btnPausePath.setVisibility(View.GONE);
        btnPlayPath.setVisibility(View.VISIBLE);
        btnPlayPath.setText("Resume");
        rowPathStepControls.setVisibility(View.VISIBLE);
        btnResetPath.setVisibility(View.VISIBLE);
        txtPathProgress.setText("Steps: " + pathIndex + "/" + pathActions.size());
    }

    private void resetPathPlayback() {
        pathHandler.removeCallbacksAndMessages(null);
        pathPlaying = false;
        arenaView.setRobotPose(startPoseX, startPoseY, startPoseDir);
        txtPathProgress.setText("Steps: 0/" + pathActions.size());
        btnPlayPath.setVisibility(pathActions.isEmpty() ? View.GONE : View.VISIBLE);
        btnPlayPath.setText("Play");
        btnPausePath.setVisibility(View.GONE);
        rowPathStepControls.setVisibility(View.GONE);
        btnResetPath.setVisibility(View.GONE);
        pathIndex = 0;
    }

    private void nextPathStep() {
        if (pathPlaying || pathActions.isEmpty()) return;
        if (pathIndex >= pathActions.size()) return;
        applyAction(pathActions.get(pathIndex));
        pathIndex++;
        txtPathProgress.setText("Steps: " + pathIndex + "/" + pathActions.size());
    }

    private void prevPathStep() {
        if (pathPlaying || pathActions.isEmpty()) return;
        if (pathIndex <= 0) return;
        pathIndex--;
        applyAction(inverseAction(pathActions.get(pathIndex)));
        txtPathProgress.setText("Steps: " + pathIndex + "/" + pathActions.size());
    }

    private void applyAction(char action) {
        switch (action) {
            case 'F':
                arenaView.moveForward();
                break;
            case 'B':
                arenaView.moveBackward();
                break;
            case 'L':
                arenaView.rotateLeft();
                break;
            case 'R':
                arenaView.rotateRight();
                break;
            default:
                break;
        }
    }

    private char inverseAction(char action) {
        switch (action) {
            case 'F':
                return 'B';
            case 'B':
                return 'F';
            case 'L':
                return 'R';
            case 'R':
                return 'L';
            default:
                return action;
        }
    }

    private List<Target> collectTargets() {
        List<Target> targets = new ArrayList<>();
        for (ArenaView.Obstacle o : arenaView.getObstaclesSnapshot()) {
            if (o.targetNorth) targets.add(new Target(o, 0));
            if (o.targetEast) targets.add(new Target(o, 1));
            if (o.targetSouth) targets.add(new Target(o, 2));
            if (o.targetWest) targets.add(new Target(o, 3));
        }
        return targets;
    }

    private List<Integer> buildApproachStates(Target t, int width, int height) {
        List<Integer> states = new ArrayList<>();
        int r = arenaView.getRobotSize();
        int xStart;
        int yStart;
        int xEnd;
        int yEnd;
        int dir;

        if (t.face == 0) { // North, robot above facing South
            yStart = t.obstacle.y + t.obstacle.size;
            xStart = t.obstacle.x - (r - 1);
            xEnd = t.obstacle.x + t.obstacle.size - 1;
            dir = 2;
            for (int x = xStart; x <= xEnd; x++) {
                if (arenaView.isRobotPlacementValid(x, yStart)) {
                    states.add(stateIndex(x, yStart, dir, width));
                }
            }
        } else if (t.face == 2) { // South, robot below facing North
            yStart = t.obstacle.y - r;
            xStart = t.obstacle.x - (r - 1);
            xEnd = t.obstacle.x + t.obstacle.size - 1;
            dir = 0;
            for (int x = xStart; x <= xEnd; x++) {
                if (arenaView.isRobotPlacementValid(x, yStart)) {
                    states.add(stateIndex(x, yStart, dir, width));
                }
            }
        } else if (t.face == 1) { // East, robot right facing West
            xStart = t.obstacle.x + t.obstacle.size;
            yStart = t.obstacle.y - (r - 1);
            yEnd = t.obstacle.y + t.obstacle.size - 1;
            dir = 3;
            for (int y = yStart; y <= yEnd; y++) {
                if (arenaView.isRobotPlacementValid(xStart, y)) {
                    states.add(stateIndex(xStart, y, dir, width));
                }
            }
        } else { // West, robot left facing East
            xStart = t.obstacle.x - r;
            yStart = t.obstacle.y - (r - 1);
            yEnd = t.obstacle.y + t.obstacle.size - 1;
            dir = 1;
            for (int y = yStart; y <= yEnd; y++) {
                if (arenaView.isRobotPlacementValid(xStart, y)) {
                    states.add(stateIndex(xStart, y, dir, width));
                }
            }
        }
        return states;
    }

    private int[] bfsDistances(int startState, int width, int height, int totalStates) {
        int[] dist = new int[totalStates];
        Arrays.fill(dist, Integer.MAX_VALUE / 4);
        ArrayDeque<Integer> q = new ArrayDeque<>();
        dist[startState] = 0;
        q.add(startState);
        while (!q.isEmpty()) {
            int s = q.poll();
            int d = dist[s];
            int[] decoded = decodeState(s, width);
            int x = decoded[0];
            int y = decoded[1];
            int dir = decoded[2];

            int left = stateIndex(x, y, (dir + 3) % 4, width);
            if (dist[left] > d + 1) {
                dist[left] = d + 1;
                q.add(left);
            }
            int right = stateIndex(x, y, (dir + 1) % 4, width);
            if (dist[right] > d + 1) {
                dist[right] = d + 1;
                q.add(right);
            }
            int[] delta = dirToDelta(dir);
            int nx = x + delta[0];
            int ny = y + delta[1];
            if (arenaView.isRobotPlacementValid(nx, ny)) {
                int forward = stateIndex(nx, ny, dir, width);
                if (dist[forward] > d + 1) {
                    dist[forward] = d + 1;
                    q.add(forward);
                }
            }
            int bx = x - delta[0];
            int by = y - delta[1];
            if (arenaView.isRobotPlacementValid(bx, by)) {
                int back = stateIndex(bx, by, dir, width);
                if (dist[back] > d + 1) {
                    dist[back] = d + 1;
                    q.add(back);
                }
            }
        }
        return dist;
    }

    private List<Character> bfsActions(int startState, int goalState, int width, int height, int totalStates) {
        int[] dist = new int[totalStates];
        int[] prev = new int[totalStates];
        char[] prevAction = new char[totalStates];
        Arrays.fill(dist, Integer.MAX_VALUE / 4);
        Arrays.fill(prev, -1);
        ArrayDeque<Integer> q = new ArrayDeque<>();
        dist[startState] = 0;
        q.add(startState);
        while (!q.isEmpty()) {
            int s = q.poll();
            if (s == goalState) break;
            int d = dist[s];
            int[] decoded = decodeState(s, width);
            int x = decoded[0];
            int y = decoded[1];
            int dir = decoded[2];

            int left = stateIndex(x, y, (dir + 3) % 4, width);
            if (dist[left] > d + 1) {
                dist[left] = d + 1;
                prev[left] = s;
                prevAction[left] = 'L';
                q.add(left);
            }
            int right = stateIndex(x, y, (dir + 1) % 4, width);
            if (dist[right] > d + 1) {
                dist[right] = d + 1;
                prev[right] = s;
                prevAction[right] = 'R';
                q.add(right);
            }
            int[] delta = dirToDelta(dir);
            int nx = x + delta[0];
            int ny = y + delta[1];
            if (arenaView.isRobotPlacementValid(nx, ny)) {
                int forward = stateIndex(nx, ny, dir, width);
                if (dist[forward] > d + 1) {
                    dist[forward] = d + 1;
                    prev[forward] = s;
                    prevAction[forward] = 'F';
                    q.add(forward);
                }
            }
            int bx = x - delta[0];
            int by = y - delta[1];
            if (arenaView.isRobotPlacementValid(bx, by)) {
                int back = stateIndex(bx, by, dir, width);
                if (dist[back] > d + 1) {
                    dist[back] = d + 1;
                    prev[back] = s;
                    prevAction[back] = 'B';
                    q.add(back);
                }
            }
        }
        if (dist[goalState] >= Integer.MAX_VALUE / 4) return null;
        List<Character> actions = new ArrayList<>();
        int cur = goalState;
        while (cur != startState) {
            char a = prevAction[cur];
            actions.add(0, a);
            cur = prev[cur];
        }
        return actions;
    }

    private int[] dirToDelta(int dir) {
        switch (dir) {
            case 0:
                return new int[]{0, 1};
            case 1:
                return new int[]{1, 0};
            case 2:
                return new int[]{0, -1};
            case 3:
            default:
                return new int[]{-1, 0};
        }
    }

    private int stateIndex(int x, int y, int dir, int width) {
        return ((y * width + x) * 4) + dir;
    }

    private int[] decodeState(int state, int width) {
        int cell = state / 4;
        int dir = state % 4;
        int x = cell % width;
        int y = cell / width;
        return new int[]{x, y, dir};
    }

    private static class Target {
        final ArenaView.Obstacle obstacle;
        final int face;

        Target(ArenaView.Obstacle obstacle, int face) {
            this.obstacle = obstacle;
            this.face = face;
        }

        String label() {
            String faceLabel = (face == 0) ? "N" : (face == 1) ? "E" : (face == 2) ? "S" : "W";
            return obstacle.number + faceLabel;
        }

        String key() {
            return label();
        }
    }

    private void startJoystickRepeat(int desiredDir) {
        joystickAction = desiredDir;
        if (joystickActive) return;
        joystickActive = true;
        moveHandler.post(joystickRunnable);
    }

    private void stopJoystickRepeat() {
        joystickActive = false;
        joystickAction = 0;
        moveHandler.removeCallbacks(joystickRunnable);
    }

    private final Runnable joystickRunnable = new Runnable() {
        @Override
        public void run() {
            if (!joystickActive || moveMode != MoveMode.JOYSTICK) return;
            long now = System.currentTimeMillis();
            if (now - lastMoveTime >= MOVE_COOLDOWN_MS) {
                moveTowardDir(joystickAction);
                lastMoveTime = now;
            }
            moveHandler.postDelayed(this, MOVE_COOLDOWN_MS);
        }
    };

    private String normalizeCommand(String line) {
        String cleaned = line.trim();
        int space = cleaned.indexOf(' ');
        if (space > 0) cleaned = cleaned.substring(0, space);
        cleaned = cleaned.replace('\t', ' ');
        cleaned = cleaned.replaceAll("\\s+", "");
        return cleaned.toUpperCase();
    }

    private String parseStatusLine(String line) {
        String[] prefixes = {
                "MSG,",
                "status=",
                "STATUS,",
                "STATUS:",
                "ROBOTSTATUS,",
                "ROBOT_STATUS,",
                "Robot Status:"
        };

        for (String prefix : prefixes) {
            if (line.startsWith(prefix)) {
                String msg = line.substring(prefix.length()).trim();
                if (msg.startsWith("[") && msg.endsWith("]") && msg.length() > 1) {
                    msg = msg.substring(1, msg.length() - 1).trim();
                }
                return msg.isEmpty() ? null : msg;
            }
        }
        return null;
    }

    private void appendLog(String s) {
        txtLog.append(s + "\n");
    }

    private void closeClientSocket() {
        try {
            if (socket != null) socket.close();
        } catch (Exception ignored) {}
        socket = null;
    }

    private void closeServerSocket() {
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (Exception ignored) {}
        serverSocket = null;
    }

    private int indexOfLineBreak(StringBuilder sb) {
        for (int i = 0; i < sb.length(); i++) {
            char c = sb.charAt(i);
            if (c == '\n' || c == '\r') return i;
        }
        return -1;
    }

    private String extractLine(StringBuilder sb, int breakIndex) {
        String line = sb.substring(0, breakIndex).trim();
        int deleteUpto = breakIndex + 1;
        while (deleteUpto < sb.length()) {
            char c = sb.charAt(deleteUpto);
            if (c != '\n' && c != '\r') break;
            deleteUpto++;
        }
        sb.delete(0, deleteUpto);
        return line;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        shouldAccept = false;
        stopTiltMode();
        disconnect();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopTiltMode();
        stopJoystickRepeat();
        pathHandler.removeCallbacksAndMessages(null);
        pathPlaying = false;
    }
}
